--
-- PostgreSQL database dump
--

\restrict G8lvMuo7bsbO7UxdPmokVzcrODJihajwyBusZMvFQIbbdmEtqJZ1UOyZ2H0eRdv

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = off;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET escape_string_warning = off;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "public";


--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."app_role" AS ENUM (
    'admin',
    'host',
    'guest',
    'team'
);


--
-- Name: rsvp_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."rsvp_status" AS ENUM (
    'pending',
    'yes',
    'no',
    'maybe',
    'waitlist'
);


--
-- Name: apply_team_invite(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."apply_team_invite"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  inv public.team_invites%ROWTYPE;
  signup_phone text;
BEGIN
  signup_phone := nullif(regexp_replace(coalesce(NEW.raw_user_meta_data->>'phone', NEW.phone, ''), '\D', '', 'g'), '');
  IF signup_phone IS NULL OR length(signup_phone) < 7 THEN
    RETURN NEW;
  END IF;
  SELECT * INTO inv FROM public.team_invites
   WHERE phone_normalized = signup_phone AND accepted_at IS NULL
   ORDER BY created_at DESC LIMIT 1;
  IF FOUND THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, inv.role)
      ON CONFLICT DO NOTHING;
    UPDATE public.team_invites SET accepted_at = now() WHERE id = inv.id;
  END IF;
  RETURN NEW;
END $$;


--
-- Name: archive_deleted_row(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."archive_deleted_row"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_phone text;
  v_name text;
BEGIN
  IF v_uid IS NOT NULL THEN
    SELECT
      nullif(regexp_replace(coalesce(phone, ''), '\D', '', 'g'), ''),
      coalesce(raw_user_meta_data->>'display_name', raw_user_meta_data->>'full_name')
    INTO v_phone, v_name
    FROM auth.users WHERE id = v_uid;
  END IF;

  INSERT INTO public.deleted_rows_archive
    (table_name, row_id, row_data, deleted_by, deleted_by_phone, deleted_by_name)
  VALUES
    (TG_TABLE_NAME, coalesce((to_jsonb(OLD)->>'id'), ''), to_jsonb(OLD),
     v_uid, v_phone, v_name);

  RETURN OLD;
END;
$$;


--
-- Name: audit_row_change(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."audit_row_change"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_phone text;
  v_name text;
  v_target_id text;
  v_meta jsonb;
  v_ip text;
  v_ua text;
BEGIN
  IF v_uid IS NOT NULL THEN
    SELECT
      nullif(regexp_replace(coalesce(phone, ''), '\D', '', 'g'), ''),
      coalesce(raw_user_meta_data->>'display_name', raw_user_meta_data->>'full_name')
    INTO v_phone, v_name
    FROM auth.users WHERE id = v_uid;
  END IF;

  BEGIN
    v_ip := current_setting('request.headers', true)::jsonb ->> 'x-forwarded-for';
    v_ua := current_setting('request.headers', true)::jsonb ->> 'user-agent';
  EXCEPTION WHEN OTHERS THEN
    v_ip := NULL; v_ua := NULL;
  END;

  IF TG_OP = 'DELETE' THEN
    v_target_id := (to_jsonb(OLD)->>'id');
    v_meta := jsonb_build_object('old', to_jsonb(OLD));
  ELSIF TG_OP = 'UPDATE' THEN
    v_target_id := (to_jsonb(NEW)->>'id');
    v_meta := jsonb_build_object('old', to_jsonb(OLD), 'new', to_jsonb(NEW));
  ELSE
    v_target_id := (to_jsonb(NEW)->>'id');
    v_meta := jsonb_build_object('new', to_jsonb(NEW));
  END IF;

  INSERT INTO public.audit_log
    (user_id, phone_normalized, display_name, action, target_type, target_id, ip, user_agent, metadata, success)
  VALUES
    (v_uid, v_phone, v_name, TG_OP || ' ' || TG_TABLE_NAME, TG_TABLE_NAME, v_target_id, v_ip, v_ua, v_meta, true);

  RETURN COALESCE(NEW, OLD);
END;
$$;


--
-- Name: claim_admin(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."claim_admin"() RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;
  IF EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    RETURN false;
  END IF;
  INSERT INTO public.user_roles (user_id, role) VALUES (auth.uid(), 'admin')
    ON CONFLICT DO NOTHING;
  RETURN true;
END $$;


--
-- Name: delete_email("text", bigint); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."delete_email"("queue_name" "text", "message_id" bigint) RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'pgmq'
    AS $$
BEGIN
  RETURN pgmq.delete(queue_name, message_id);
EXCEPTION WHEN undefined_table THEN
  RETURN FALSE;
END;
$$;


--
-- Name: detect_duplicate_invitations(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."detect_duplicate_invitations"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  new_phone_tail text;
  new_name_norm text;
BEGIN
  -- Email exact match
  IF NEW.guest_email_normalized IS NOT NULL AND NEW.guest_email_normalized <> '' THEN
    INSERT INTO public.duplicate_flags (event_id, invitation_a, invitation_b, match_type)
    SELECT NEW.event_id, LEAST(NEW.id, i.id), GREATEST(NEW.id, i.id), 'email'
    FROM public.invitations i
    WHERE i.event_id = NEW.event_id AND i.id <> NEW.id
      AND i.guest_email_normalized = NEW.guest_email_normalized
    ON CONFLICT DO NOTHING;
  END IF;

  -- Phone match by last 10 digits (handles +1 country code differences)
  IF NEW.guest_phone_normalized IS NOT NULL AND length(NEW.guest_phone_normalized) >= 7 THEN
    new_phone_tail := right(NEW.guest_phone_normalized, 10);
    INSERT INTO public.duplicate_flags (event_id, invitation_a, invitation_b, match_type)
    SELECT NEW.event_id, LEAST(NEW.id, i.id), GREATEST(NEW.id, i.id), 'phone'
    FROM public.invitations i
    WHERE i.event_id = NEW.event_id AND i.id <> NEW.id
      AND i.guest_phone_normalized IS NOT NULL
      AND length(i.guest_phone_normalized) >= 7
      AND right(i.guest_phone_normalized, 10) = new_phone_tail
    ON CONFLICT DO NOTHING;
  END IF;

  -- Fuzzy name match (trigram similarity >= 0.6)
  new_name_norm := public.normalize_name_for_match(NEW.guest_name);
  IF length(new_name_norm) >= 4 THEN
    INSERT INTO public.duplicate_flags (event_id, invitation_a, invitation_b, match_type)
    SELECT NEW.event_id, LEAST(NEW.id, i.id), GREATEST(NEW.id, i.id), 'name'
    FROM public.invitations i
    WHERE i.event_id = NEW.event_id AND i.id <> NEW.id
      AND length(public.normalize_name_for_match(i.guest_name)) >= 4
      AND similarity(public.normalize_name_for_match(i.guest_name), new_name_norm) >= 0.6
    ON CONFLICT DO NOTHING;
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: enqueue_email("text", "jsonb"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."enqueue_email"("queue_name" "text", "payload" "jsonb") RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'pgmq'
    AS $$
BEGIN
  RETURN pgmq.send(queue_name, payload);
EXCEPTION WHEN undefined_table THEN
  PERFORM pgmq.create(queue_name);
  RETURN pgmq.send(queue_name, payload);
END;
$$;


--
-- Name: ensure_committee_team_role(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."ensure_committee_team_role"() RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  is_comm boolean;
  my_digits text;
  inv public.team_invites%ROWTYPE;
  granted boolean := false;
  inviter_match boolean;
BEGIN
  IF auth.uid() IS NULL THEN RETURN false; END IF;

  -- 1) Committee membership via invitations.is_committee
  SELECT public.is_current_user_committee() INTO is_comm;
  IF is_comm THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (auth.uid(), 'team')
    ON CONFLICT DO NOTHING;
    granted := true;
  END IF;

  -- Phone digits for this user (used by 2 and 3)
  SELECT nullif(regexp_replace(coalesce(phone, ''), '\D', '', 'g'), '')
    INTO my_digits
    FROM auth.users WHERE id = auth.uid();

  -- 2) Pending team_invites for this user's phone (retroactive)
  IF my_digits IS NOT NULL AND length(my_digits) >= 7 THEN
    FOR inv IN
      SELECT * FROM public.team_invites
       WHERE accepted_at IS NULL
         AND (phone_normalized = my_digits
              OR right(coalesce(phone_normalized, ''), 10) = right(my_digits, 10))
    LOOP
      INSERT INTO public.user_roles (user_id, role)
      VALUES (auth.uid(), inv.role)
      ON CONFLICT DO NOTHING;
      UPDATE public.team_invites SET accepted_at = now() WHERE id = inv.id;
      granted := true;
    END LOOP;
  END IF;

  -- 3) Active entry in inviters (subcommittee/committee list) by phone
  IF my_digits IS NOT NULL AND length(my_digits) >= 7 THEN
    SELECT EXISTS (
      SELECT 1 FROM public.inviters i
      WHERE i.active = true
        AND nullif(regexp_replace(coalesce(i.phone, ''), '\D', '', 'g'), '') IS NOT NULL
        AND (
          regexp_replace(coalesce(i.phone, ''), '\D', '', 'g') = my_digits
          OR right(regexp_replace(coalesce(i.phone, ''), '\D', '', 'g'), 10) = right(my_digits, 10)
        )
    ) INTO inviter_match;
    IF inviter_match THEN
      INSERT INTO public.user_roles (user_id, role)
      VALUES (auth.uid(), 'team')
      ON CONFLICT DO NOTHING;
      granted := true;
    END IF;
  END IF;

  RETURN granted;
END;
$$;


--
-- Name: get_auth_user_id_by_phone("text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."get_auth_user_id_by_phone"("_phone" "text") RETURNS "uuid"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT id FROM auth.users WHERE phone = _phone LIMIT 1;
$$;


--
-- Name: get_auth_user_id_by_phone_digits("text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."get_auth_user_id_by_phone_digits"("_digits" "text") RETURNS "uuid"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT id FROM auth.users
  WHERE regexp_replace(coalesce(phone, ''), '\D', '', 'g') = _digits
     OR right(regexp_replace(coalesce(phone, ''), '\D', '', 'g'), 10) = right(_digits, 10)
  ORDER BY created_at ASC
  LIMIT 1;
$$;


--
-- Name: get_my_chat_unread(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."get_my_chat_unread"() RETURNS "jsonb"
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  me uuid := auth.uid();
  team_sentinel uuid := '00000000-0000-0000-0000-000000000001';
  team_count int := 0;
  cats jsonb := '[]'::jsonb;
  is_team_member boolean;
BEGIN
  IF me IS NULL THEN
    RETURN jsonb_build_object('team', 0, 'categories', '[]'::jsonb, 'total', 0);
  END IF;

  is_team_member := has_role(me, 'team'::app_role) OR has_role(me, 'admin'::app_role);

  IF is_team_member THEN
    SELECT count(*) INTO team_count
    FROM team_messages tm
    LEFT JOIN chat_last_seen ls
      ON ls.user_id = me AND ls.chat_kind = 'team' AND ls.chat_id = team_sentinel
    WHERE tm.user_id <> me
      AND tm.created_at > COALESCE(ls.last_seen_at, 'epoch'::timestamptz);
  END IF;

  WITH sub AS (
    SELECT cm.category_id, count(*) AS cnt
    FROM category_messages cm
    JOIN category_assignments ca
      ON ca.category_id = cm.category_id AND ca.user_id = me
    LEFT JOIN chat_last_seen ls
      ON ls.user_id = me AND ls.chat_kind = 'category' AND ls.chat_id = cm.category_id
    WHERE cm.user_id <> me
      AND cm.created_at > COALESCE(ls.last_seen_at, 'epoch'::timestamptz)
    GROUP BY cm.category_id
  )
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'category_id', c.id,
    'name', c.name,
    'count', sub.cnt
  ) ORDER BY c.name), '[]'::jsonb) INTO cats
  FROM sub
  JOIN categories c ON c.id = sub.category_id;

  RETURN jsonb_build_object(
    'team', team_count,
    'categories', cats,
    'total', team_count + COALESCE(
      (SELECT sum((e->>'count')::int) FROM jsonb_array_elements(cats) e), 0
    )
  );
END;
$$;


--
-- Name: get_public_inviters(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."get_public_inviters"() RETURNS TABLE("id" "uuid", "name" "text")
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  WITH committee_names AS (
    SELECT i.id, btrim(i.name) AS name
    FROM public.inviters i
    WHERE i.active = true
      AND nullif(btrim(i.name), '') IS NOT NULL
    UNION ALL
    SELECT ti.id, btrim(ti.name) AS name
    FROM public.team_invites ti
    WHERE ti.role = 'team'::public.app_role
      AND nullif(btrim(ti.name), '') IS NOT NULL
    UNION ALL
    SELECT inv.id, btrim(inv.guest_name) AS name
    FROM public.invitations inv
    WHERE inv.is_committee = true
      AND nullif(btrim(inv.guest_name), '') IS NOT NULL
  ), deduped AS (
    SELECT id, name,
      row_number() OVER (PARTITION BY lower(name) ORDER BY name, id) AS rn
    FROM committee_names
  )
  SELECT id, name
  FROM deduped
  WHERE rn = 1
  ORDER BY name;
$$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."handle_new_user"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)));
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'host') ON CONFLICT DO NOTHING;
  RETURN NEW;
END; $$;


--
-- Name: has_role("uuid", "public"."app_role"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."has_role"("_user_id" "uuid", "_role" "public"."app_role") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;


--
-- Name: is_current_user_committee(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."is_current_user_committee"() RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  WITH me AS (
    SELECT nullif(regexp_replace(coalesce(phone, ''), '\D', '', 'g'), '') AS digits
    FROM auth.users WHERE id = auth.uid()
  )
  SELECT EXISTS (
    SELECT 1 FROM public.invitations i, me
    WHERE i.is_committee = true
      AND me.digits IS NOT NULL
      AND (
        i.guest_phone_normalized = me.digits
        OR right(coalesce(i.guest_phone_normalized, ''), 10) = right(me.digits, 10)
      )
  );
$$;


--
-- Name: move_to_dlq("text", "text", bigint, "jsonb"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."move_to_dlq"("source_queue" "text", "dlq_name" "text", "message_id" bigint, "payload" "jsonb") RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'pgmq'
    AS $$
DECLARE new_id BIGINT;
BEGIN
  SELECT pgmq.send(dlq_name, payload) INTO new_id;
  PERFORM pgmq.delete(source_queue, message_id);
  RETURN new_id;
EXCEPTION WHEN undefined_table THEN
  BEGIN
    PERFORM pgmq.create(dlq_name);
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END;
  SELECT pgmq.send(dlq_name, payload) INTO new_id;
  BEGIN
    PERFORM pgmq.delete(source_queue, message_id);
  EXCEPTION WHEN undefined_table THEN
    NULL;
  END;
  RETURN new_id;
END;
$$;


--
-- Name: normalize_name_for_match("text"); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."normalize_name_for_match"("_name" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    SET "search_path" TO 'public'
    AS $$
  SELECT lower(regexp_replace(coalesce(_name, ''), '[^a-zA-Z]', '', 'g'));
$$;


--
-- Name: read_email_batch("text", integer, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."read_email_batch"("queue_name" "text", "batch_size" integer, "vt" integer) RETURNS TABLE("msg_id" bigint, "read_ct" integer, "message" "jsonb")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'pgmq'
    AS $$
BEGIN
  RETURN QUERY SELECT r.msg_id, r.read_ct, r.message FROM pgmq.read(queue_name, vt, batch_size) r;
EXCEPTION WHEN undefined_table THEN
  PERFORM pgmq.create(queue_name);
  RETURN;
END;
$$;


--
-- Name: set_cuisine_preorders_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."set_cuisine_preorders_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public'
    AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


--
-- Name: set_team_invite_phone_normalized(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."set_team_invite_phone_normalized"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public'
    AS $$
BEGIN
  NEW.phone_normalized := nullif(regexp_replace(coalesce(NEW.phone, ''), '\D', '', 'g'), '');
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."audit_log" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "phone_normalized" "text",
    "display_name" "text",
    "action" "text" NOT NULL,
    "target_type" "text",
    "target_id" "text",
    "ip" "text",
    "user_agent" "text",
    "metadata" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "success" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."categories" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "sort_order" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "description" "text"
);


--
-- Name: category_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."category_assignments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "category_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "volunteer_name" "text",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: category_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."category_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "category_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "body" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."category_messages" REPLICA IDENTITY FULL;


--
-- Name: chat_last_seen; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."chat_last_seen" (
    "user_id" "uuid" NOT NULL,
    "chat_kind" "text" NOT NULL,
    "chat_id" "uuid" NOT NULL,
    "last_seen_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "chat_last_seen_chat_kind_check" CHECK (("chat_kind" = ANY (ARRAY['team'::"text", 'category'::"text", 'guest'::"text"])))
);


--
-- Name: cuisine_preorders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."cuisine_preorders" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "phone" "text" NOT NULL,
    "selections" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "invitation_id" "uuid",
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: deleted_rows_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."deleted_rows_archive" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "table_name" "text" NOT NULL,
    "row_id" "text" NOT NULL,
    "row_data" "jsonb" NOT NULL,
    "deleted_by" "uuid",
    "deleted_by_phone" "text",
    "deleted_by_name" "text",
    "deleted_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: donations_summary; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."donations_summary" (
    "id" boolean DEFAULT true NOT NULL,
    "total_amount" numeric DEFAULT 0 NOT NULL,
    "notes" "text",
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "donations_summary_singleton" CHECK (("id" = true))
);


--
-- Name: duplicate_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."duplicate_flags" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "event_id" "uuid" NOT NULL,
    "invitation_a" "uuid" NOT NULL,
    "invitation_b" "uuid" NOT NULL,
    "match_type" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: duplicate_flag_pairs; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW "public"."duplicate_flag_pairs" WITH ("security_invoker"='on') AS
 SELECT LEAST("invitation_a", "invitation_b") AS "invitation_a",
    GREATEST("invitation_a", "invitation_b") AS "invitation_b",
    "event_id",
    "array_agg"(DISTINCT "match_type" ORDER BY "match_type") AS "match_types",
    "min"("created_at") AS "created_at"
   FROM "public"."duplicate_flags"
  GROUP BY LEAST("invitation_a", "invitation_b"), GREATEST("invitation_a", "invitation_b"), "event_id";


--
-- Name: email_send_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."email_send_log" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "message_id" "text",
    "template_name" "text" NOT NULL,
    "recipient_email" "text" NOT NULL,
    "status" "text" NOT NULL,
    "error_message" "text",
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "email_send_log_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'sent'::"text", 'suppressed'::"text", 'failed'::"text", 'bounced'::"text", 'complained'::"text", 'dlq'::"text"])))
);


--
-- Name: email_send_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."email_send_state" (
    "id" integer DEFAULT 1 NOT NULL,
    "retry_after_until" timestamp with time zone,
    "batch_size" integer DEFAULT 10 NOT NULL,
    "send_delay_ms" integer DEFAULT 200 NOT NULL,
    "auth_email_ttl_minutes" integer DEFAULT 15 NOT NULL,
    "transactional_email_ttl_minutes" integer DEFAULT 60 NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "email_send_state_id_check" CHECK (("id" = 1))
);


--
-- Name: email_unsubscribe_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."email_unsubscribe_tokens" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "token" "text" NOT NULL,
    "email" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "used_at" timestamp with time zone
);


--
-- Name: entertainment_submissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."entertainment_submissions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "name" "text" NOT NULL,
    "email" "text",
    "phone" "text",
    "talent" "text",
    "notes" "text",
    "video_path" "text" NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."events" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "description" "text",
    "starts_at" timestamp with time zone NOT NULL,
    "ends_at" timestamp with time zone,
    "location" "text",
    "virtual_link" "text",
    "cover_image_url" "text",
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: guest_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."guest_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "invitation_id" "uuid" NOT NULL,
    "sender" "text" NOT NULL,
    "user_id" "uuid",
    "body" "text" NOT NULL,
    "read_by_admin" boolean DEFAULT false NOT NULL,
    "read_by_guest" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "guest_messages_sender_check" CHECK (("sender" = ANY (ARRAY['guest'::"text", 'admin'::"text"])))
);


--
-- Name: invitation_content; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."invitation_content" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "singleton" boolean DEFAULT true NOT NULL,
    "hero_eyebrow" "text" DEFAULT 'You''re Cordially Invited To'::"text" NOT NULL,
    "hero_title" "text" DEFAULT 'A Taste of'::"text" NOT NULL,
    "hero_title_emphasis" "text" DEFAULT 'Special'::"text" NOT NULL,
    "hero_title_suffix" "text" DEFAULT 'Conventions'::"text" NOT NULL,
    "hero_tagline" "text" DEFAULT 'An event and an evening to remember.'::"text" NOT NULL,
    "hero_intro" "text" DEFAULT 'You are cordially invited to join us for a very special evening of association, cultural enrichment, gift exchanges, meeting new friends, and making wonderful memories — this side of paradise. See the video below for details.'::"text" NOT NULL,
    "video_url" "text",
    "itinerary" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "datetime_heading" "text" DEFAULT 'Sunday, August 30, 2026 · 4:00 PM – 9:30 PM'::"text" NOT NULL,
    "datetime_body" "text" DEFAULT 'Join us from 4:00 PM to 9:30 PM for a full evening together.'::"text" NOT NULL,
    "location_name" "text" DEFAULT 'Eagle''s Landing'::"text" NOT NULL,
    "location_subtitle" "text" DEFAULT 'La Platte, Nebraska'::"text" NOT NULL,
    "location_body" "text" DEFAULT 'GPS coordinates and map will appear here once confirmed.'::"text" NOT NULL,
    "dress_body" "text" DEFAULT 'This is an international event, so international attire is encouraged. Is there a culture you love to dress in? Please do — it''ll make the evening more fun and beautiful for everyone.'::"text" NOT NULL,
    "gifts_body" "text" DEFAULT 'In the spirit of the special and international conventions, friends bring gifts to exchange. See the video below — it''ll walk you through exactly how it works.'::"text" NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."invitations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "event_id" "uuid" NOT NULL,
    "host_id" "uuid" NOT NULL,
    "guest_name" "text" NOT NULL,
    "guest_email" "text",
    "guest_phone" "text",
    "guest_email_normalized" "text" GENERATED ALWAYS AS ("lower"(TRIM(BOTH FROM "guest_email"))) STORED,
    "guest_phone_normalized" "text" GENERATED ALWAYS AS ("regexp_replace"(COALESCE("guest_phone", ''::"text"), '[^0-9]'::"text", ''::"text", 'g'::"text")) STORED,
    "notes" "text",
    "rsvp_token" "text" DEFAULT "encode"("extensions"."gen_random_bytes"(18), 'base64'::"text") NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "invite_sent_at" timestamp with time zone,
    "is_committee" boolean DEFAULT false NOT NULL
);


--
-- Name: inviters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."inviters" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "quota" integer DEFAULT 40 NOT NULL,
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "host_id" "uuid",
    "email" "text",
    "phone" "text",
    "requested_quota" integer,
    "quota_request_note" "text",
    "quota_requested_at" timestamp with time zone
);


--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."menu_items" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "restaurant_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "price" numeric(10,2) DEFAULT 0 NOT NULL,
    "category" "text",
    "dietary_flags" "text"[] DEFAULT '{}'::"text"[],
    "available" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."orders" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "invitation_id" "uuid" NOT NULL,
    "restaurant_id" "uuid" NOT NULL,
    "items" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "total" numeric(10,2) DEFAULT 0 NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."profiles" (
    "id" "uuid" NOT NULL,
    "email" "text",
    "display_name" "text",
    "avatar_url" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: restaurants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."restaurants" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "cuisine" "text",
    "image_url" "text",
    "active" boolean DEFAULT true NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: rsvps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."rsvps" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "invitation_id" "uuid" NOT NULL,
    "status" "public"."rsvp_status" DEFAULT 'pending'::"public"."rsvp_status" NOT NULL,
    "party_size" integer DEFAULT 1 NOT NULL,
    "dietary_notes" "text",
    "message" "text",
    "responded_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "invited_by" "text",
    "attendance_mode" "text" DEFAULT 'in_person'::"text" NOT NULL,
    "ordering_food" boolean,
    CONSTRAINT "rsvps_attendance_mode_check" CHECK (("attendance_mode" = ANY (ARRAY['in_person'::"text", 'zoom'::"text"])))
);


--
-- Name: suppressed_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."suppressed_emails" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "email" "text" NOT NULL,
    "reason" "text" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "suppressed_emails_reason_check" CHECK (("reason" = ANY (ARRAY['unsubscribe'::"text", 'bounce'::"text", 'complaint'::"text"])))
);


--
-- Name: team_invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."team_invites" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "email" "text",
    "email_normalized" "text" GENERATED ALWAYS AS ("lower"(TRIM(BOTH FROM "email"))) STORED,
    "role" "public"."app_role" DEFAULT 'team'::"public"."app_role" NOT NULL,
    "invited_by" "uuid" NOT NULL,
    "accepted_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "name" "text",
    "phone" "text",
    "phone_normalized" "text"
);


--
-- Name: team_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."team_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "body" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "team_messages_body_check" CHECK ((("length"("body") >= 1) AND ("length"("body") <= 4000)))
);

ALTER TABLE ONLY "public"."team_messages" REPLICA IDENTITY FULL;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."user_roles" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "public"."app_role" NOT NULL
);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."audit_log" ("id", "user_id", "phone_normalized", "display_name", "action", "target_type", "target_id", "ip", "user_agent", "metadata", "success", "created_at") FROM stdin;
4705fd98-197b-4772-b962-aa6d293596de	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-15 23:58:23.846512+00
5f8d5de6-c9de-4de3-8e78-26cab2a26d2f	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-15 23:59:59.276142+00
f4c66e45-e52a-4b2d-9ebe-932e6ecbbfa1	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-16 02:34:54.22374+00
6d052447-05d9-4e11-82ee-31793311a7c4	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-16 02:37:36.937932+00
b2229a3a-1818-4347-aa20-a02b04d23bfa	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-16 03:54:59.40434+00
a9a84404-d647-4170-8285-3becb652f736	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-16 05:18:46.146166+00
928a1871-079d-4baf-9ba4-4363446a73d2	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-16 05:34:29.266093+00
a49a9763-1797-4fdc-94cb-b36a3ce5b8f5	\N	\N	\N	DELETE cuisine_preorders	cuisine_preorders	2bbaf321-9185-440e-83ce-55b61c2dee5e	\N	\N	{"old": {"id": "2bbaf321-9185-440e-83ce-55b61c2dee5e", "name": "Kenda Andersen", "phone": "(402) 296-9922", "created_at": "2026-06-03T13:00:42.219319+00:00", "selections": [{"qty": 1, "country": "Jakarta, Indonesia"}], "updated_at": "2026-06-03T13:00:42.219319+00:00", "invitation_id": null}}	t	2026-06-16 06:04:07.414752+00
db455e78-9637-4a85-80e7-86ae92e1f08e	\N	\N	\N	DELETE cuisine_preorders	cuisine_preorders	2bbaf321-9185-440e-83ce-55b61c2dee5e	\N	\N	{"old": {"id": "2bbaf321-9185-440e-83ce-55b61c2dee5e", "name": "Kenda Andersen", "phone": "(402) 296-9922", "created_at": "2026-06-03T13:00:42.219319+00:00", "selections": [{"qty": 1, "country": "Jakarta, Indonesia"}], "updated_at": "2026-06-03T13:00:42.219319+00:00", "invitation_id": null}}	t	2026-06-16 06:04:07.414752+00
d8e16384-eeff-4767-9224-057c8920a374	\N	\N	\N	DELETE cuisine_preorders	cuisine_preorders	da9ab028-32d2-4474-9cb6-e1b72708047d	\N	\N	{"old": {"id": "da9ab028-32d2-4474-9cb6-e1b72708047d", "name": "S. Carmen De La Cruz", "phone": "4022912856", "created_at": "2026-06-06T02:14:15.251328+00:00", "selections": [{"qty": 1, "country": "Mozambique"}], "updated_at": "2026-06-06T02:14:15.251328+00:00", "invitation_id": null}}	t	2026-06-16 06:04:07.414752+00
9ce90cfd-04ac-4394-b45d-ff96304a20cb	\N	\N	\N	DELETE cuisine_preorders	cuisine_preorders	da9ab028-32d2-4474-9cb6-e1b72708047d	\N	\N	{"old": {"id": "da9ab028-32d2-4474-9cb6-e1b72708047d", "name": "S. Carmen De La Cruz", "phone": "4022912856", "created_at": "2026-06-06T02:14:15.251328+00:00", "selections": [{"qty": 1, "country": "Mozambique"}], "updated_at": "2026-06-06T02:14:15.251328+00:00", "invitation_id": null}}	t	2026-06-16 06:04:07.414752+00
933bc1e7-da1d-4958-94dd-38f3df49ad07	\N	\N	\N	DELETE cuisine_preorders	cuisine_preorders	feb248d0-42b2-4846-8516-92c9b8ebdaaf	\N	\N	{"old": {"id": "feb248d0-42b2-4846-8516-92c9b8ebdaaf", "name": "MsDixie Frahm", "phone": "4029795214", "created_at": "2026-06-08T14:17:10.354914+00:00", "selections": [{"qty": 1, "country": "Indonesia"}], "updated_at": "2026-06-08T14:17:10.354914+00:00", "invitation_id": null}}	t	2026-06-16 06:04:07.414752+00
e5e927cb-eac1-4113-bf2f-b17674ce4530	\N	\N	\N	DELETE cuisine_preorders	cuisine_preorders	feb248d0-42b2-4846-8516-92c9b8ebdaaf	\N	\N	{"old": {"id": "feb248d0-42b2-4846-8516-92c9b8ebdaaf", "name": "MsDixie Frahm", "phone": "4029795214", "created_at": "2026-06-08T14:17:10.354914+00:00", "selections": [{"qty": 1, "country": "Indonesia"}], "updated_at": "2026-06-08T14:17:10.354914+00:00", "invitation_id": null}}	t	2026-06-16 06:04:07.414752+00
17ab4e70-3099-4454-98ba-3cb3514f816d	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-16 07:18:13.587831+00
593f45cb-dcec-47ad-aa0f-c2b7cd69c4f5	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	fa170011-f8a5-41cb-b96d-b80da4be8c6f	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "fa170011-f8a5-41cb-b96d-b80da4be8c6f", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.23677+00:00", "guest_name": "NE Sofia Barios", "rsvp_token": "pr2GFJlBMxSLh7JNM9dskhb0", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}}	t	2026-06-16 07:18:31.057158+00
c4cd7d44-f2af-4279-af11-0ece507bc164	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	fa170011-f8a5-41cb-b96d-b80da4be8c6f	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "fa170011-f8a5-41cb-b96d-b80da4be8c6f", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.23677+00:00", "guest_name": "NE Sofia Barios", "rsvp_token": "pr2GFJlBMxSLh7JNM9dskhb0", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}}	t	2026-06-16 07:18:31.057158+00
852308c3-acc2-47ec-99fd-96e860d10e9b	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE inviters	inviters	44f416cf-155c-444e-bd32-8d1e15b91449	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "44f416cf-155c-444e-bd32-8d1e15b91449", "name": "Sarah Campbell", "email": null, "phone": "(402) 802-4026", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-02T02:16:18.957855+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-16 07:23:20.463238+00
2634952d-0c30-4012-9ac9-2435ffb133f9	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE inviters	inviters	44f416cf-155c-444e-bd32-8d1e15b91449	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "44f416cf-155c-444e-bd32-8d1e15b91449", "name": "Sarah Campbell", "email": null, "phone": "(402) 802-4026", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-02T02:16:18.957855+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-16 07:23:20.463238+00
cbe74854-1f60-491f-8b2e-db8a269bf3f9	\N	\N	\N	DELETE inviters	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	\N	\N	{"old": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": "14029795214", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 23:17:01.060887+00
16937da3-1661-4a38-9d1d-4dbfba33ce1a	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE inviters	inviters	046d10b2-31d3-46be-96d5-e09362a9c035	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "046d10b2-31d3-46be-96d5-e09362a9c035", "name": "Saul Morro", "email": null, "phone": "+1531-484-5553", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-06T01:52:48.327389+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-16 07:27:36.276726+00
fa04b283-b548-491d-87c7-3af19a0bd321	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE inviters	inviters	046d10b2-31d3-46be-96d5-e09362a9c035	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "046d10b2-31d3-46be-96d5-e09362a9c035", "name": "Saul Morro", "email": null, "phone": "+1531-484-5553", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-06T01:52:48.327389+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-16 07:27:36.276726+00
99ee337a-3c75-482b-884a-ddb0bfd3f1e2	\N	\N	\N	UPDATE invitations	invitations	1c1b1447-01a5-4821-90d8-282037142a8e	2a06:98c0:3600::103	\N	{"new": {"id": "1c1b1447-01a5-4821-90d8-282037142a8e", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T11:10:17.436667+00:00", "guest_name": "Shadna Jaisaree", "rsvp_token": "pf23AUwNPRxphBTUDbeU8Xs2", "guest_email": null, "guest_phone": "6479079782", "is_committee": false, "invite_sent_at": "2026-06-06T02:03:34.202+00:00", "guest_email_normalized": null, "guest_phone_normalized": "6479079782"}, "old": {"id": "1c1b1447-01a5-4821-90d8-282037142a8e", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T11:10:17.436667+00:00", "guest_name": "Shadna Jaisaree", "rsvp_token": "pf23AUwNPRxphBTUDbeU8Xs2", "guest_email": null, "guest_phone": "6479079782", "is_committee": false, "invite_sent_at": "2026-06-06T02:03:34.202+00:00", "guest_email_normalized": null, "guest_phone_normalized": "6479079782"}}	t	2026-06-16 20:10:02.331535+00
9f7a5cb7-3f81-45f1-9168-d52b67b816df	\N	\N	\N	UPDATE invitations	invitations	1c1b1447-01a5-4821-90d8-282037142a8e	2a06:98c0:3600::103	\N	{"new": {"id": "1c1b1447-01a5-4821-90d8-282037142a8e", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T11:10:17.436667+00:00", "guest_name": "Shadna Jaisaree", "rsvp_token": "pf23AUwNPRxphBTUDbeU8Xs2", "guest_email": null, "guest_phone": "6479079782", "is_committee": false, "invite_sent_at": "2026-06-06T02:03:34.202+00:00", "guest_email_normalized": null, "guest_phone_normalized": "6479079782"}, "old": {"id": "1c1b1447-01a5-4821-90d8-282037142a8e", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T11:10:17.436667+00:00", "guest_name": "Shadna Jaisaree", "rsvp_token": "pf23AUwNPRxphBTUDbeU8Xs2", "guest_email": null, "guest_phone": "6479079782", "is_committee": false, "invite_sent_at": "2026-06-06T02:03:34.202+00:00", "guest_email_normalized": null, "guest_phone_normalized": "6479079782"}}	t	2026-06-16 20:10:02.331535+00
2cec7309-7abd-4c4b-8ef4-f3c46fce05e1	\N	\N	\N	UPDATE rsvps	rsvps	9f4db587-0f48-4f1c-8d0d-689140eb5a70	2a06:98c0:3600::103	\N	{"new": {"id": "9f4db587-0f48-4f1c-8d0d-689140eb5a70", "status": "yes", "message": null, "created_at": "2026-06-04T11:10:18.267805+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-16T20:10:02.454+00:00", "dietary_notes": null, "invitation_id": "1c1b1447-01a5-4821-90d8-282037142a8e", "ordering_food": null, "attendance_mode": "zoom"}, "old": {"id": "9f4db587-0f48-4f1c-8d0d-689140eb5a70", "status": "yes", "message": null, "created_at": "2026-06-04T11:10:18.267805+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-06T02:30:02.186+00:00", "dietary_notes": null, "invitation_id": "1c1b1447-01a5-4821-90d8-282037142a8e", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-16 20:10:02.506467+00
3c609e91-bb87-4e47-b710-40ac97de571a	\N	\N	\N	UPDATE rsvps	rsvps	9f4db587-0f48-4f1c-8d0d-689140eb5a70	2a06:98c0:3600::103	\N	{"new": {"id": "9f4db587-0f48-4f1c-8d0d-689140eb5a70", "status": "yes", "message": null, "created_at": "2026-06-04T11:10:18.267805+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-16T20:10:02.454+00:00", "dietary_notes": null, "invitation_id": "1c1b1447-01a5-4821-90d8-282037142a8e", "ordering_food": null, "attendance_mode": "zoom"}, "old": {"id": "9f4db587-0f48-4f1c-8d0d-689140eb5a70", "status": "yes", "message": null, "created_at": "2026-06-04T11:10:18.267805+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-06T02:30:02.186+00:00", "dietary_notes": null, "invitation_id": "1c1b1447-01a5-4821-90d8-282037142a8e", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-16 20:10:02.506467+00
1cb29996-36fd-437c-ba3e-e7ede4e8216b	\N	\N	\N	INSERT user_roles	user_roles	8eff1899-43d4-4a13-acbc-7ddf1acb7e49	\N	\N	{"new": {"id": "8eff1899-43d4-4a13-acbc-7ddf1acb7e49", "role": "host", "user_id": "5cbf8604-d2a3-42fe-8cc1-26df7f538019"}}	t	2026-06-16 21:24:52.68237+00
c3ec5102-a599-4431-878e-382fb4b65e4c	\N	\N	\N	INSERT invitations	invitations	d6cb152b-d5c2-4207-aa31-66ea08655620	2a06:98c0:3600::103	\N	{"new": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}}	t	2026-06-16 21:24:53.31544+00
bc139d84-73a8-4e05-8d6e-451e421cce1b	\N	\N	\N	INSERT invitations	invitations	d6cb152b-d5c2-4207-aa31-66ea08655620	2a06:98c0:3600::103	\N	{"new": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}}	t	2026-06-16 21:24:53.31544+00
3884b394-d85c-42dd-bceb-b4be018d3ac2	\N	\N	\N	UPDATE invitations	invitations	d6cb152b-d5c2-4207-aa31-66ea08655620	2a06:98c0:3600::103	\N	{"new": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}, "old": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}}	t	2026-06-16 21:24:53.737742+00
74749cd7-8ccf-4c63-b2d6-4e3cc5ed8ea5	\N	\N	\N	UPDATE invitations	invitations	d6cb152b-d5c2-4207-aa31-66ea08655620	2a06:98c0:3600::103	\N	{"new": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}, "old": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}}	t	2026-06-16 21:24:53.737742+00
ca49a4e1-6fa9-4da4-92ea-5da72bb02f43	\N	\N	\N	INSERT rsvps	rsvps	853e950b-79cb-4ced-b20b-a075a75268e0	2a06:98c0:3600::103	\N	{"new": {"id": "853e950b-79cb-4ced-b20b-a075a75268e0", "status": "yes", "message": null, "created_at": "2026-06-16T21:24:53.86066+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-16T21:24:53.796+00:00", "dietary_notes": null, "invitation_id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "ordering_food": false, "attendance_mode": "in_person"}}	t	2026-06-16 21:24:53.86066+00
9d2c94f3-4e69-4251-85f4-bc90a2d537e9	\N	\N	\N	INSERT rsvps	rsvps	853e950b-79cb-4ced-b20b-a075a75268e0	2a06:98c0:3600::103	\N	{"new": {"id": "853e950b-79cb-4ced-b20b-a075a75268e0", "status": "yes", "message": null, "created_at": "2026-06-16T21:24:53.86066+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-16T21:24:53.796+00:00", "dietary_notes": null, "invitation_id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "ordering_food": false, "attendance_mode": "in_person"}}	t	2026-06-16 21:24:53.86066+00
84790dd5-6a28-49ce-93af-80a8174983e6	\N	13146406836	Futo	auth.login.failure	auth	\N	98.13.96.127	Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1	{"reason": "phone_not_on_list"}	f	2026-06-16 21:37:18.411945+00
76c8dfc9-7802-4ca0-a182-d1078f8c0117	\N	13146406836	Futo	auth.login.failure	auth	\N	98.13.96.127	Mozilla/5.0 (iPhone; CPU iPhone OS 18_1_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.1.1 Mobile/15E148 Safari/604.1	{"reason": "phone_not_on_list"}	f	2026-06-16 21:37:25.516848+00
ae8cb650-1fa4-4a00-9d03-ee53d02ff950	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT category_assignments	category_assignments	29b39652-f1e6-484a-80b6-769c0fe4d8c5	209.79.168.68	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "29b39652-f1e6-484a-80b6-769c0fe4d8c5", "notes": null, "user_id": "c9b87cf9-b5b2-486f-a343-6fd8b3a94f05", "created_at": "2026-06-17T01:59:01.918162+00:00", "category_id": "167c811c-f486-479c-b09f-f9faae8a0843", "volunteer_name": null}}	t	2026-06-17 01:59:01.918162+00
5a3b0e6b-fda8-493d-868a-92df87308e3f	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:16:02.420591+00
58bca93b-10c5-45c5-96ae-fe115251b19f	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:16:29.561899+00
e366bdb1-63cd-4e49-8ae7-759972388c27	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:18:34.739492+00
70368a0d-2c28-444a-b0e9-0f39c5ffab28	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:18:53.314022+00
7e27fa38-44a5-4915-8fa4-d575c12d9f78	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:22:18.460216+00
2da3449f-3333-4579-93a2-b802823cdaa3	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:23:17.750593+00
546aed1d-c4ef-4fd4-acfd-e719934750c7	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:23:31.889593+00
d3aad553-5781-4f1e-9543-3374e5ffc2ac	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:24:08.867978+00
085e31d6-98e3-4818-bab2-be39e786f60b	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:36:12.699207+00
1393704d-86e4-4b3f-84b6-e4263f59e95a	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:36:27.906055+00
a49f9f7c-476a-47d1-8e02-c1470c506b7f	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:36:49.028444+00
f026423d-88f8-41ea-b61e-9bfd85e15aa5	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:39:54.570355+00
76eef9fb-5317-492b-8d18-20b3fff85203	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:40:02.442635+00
e8d750f2-e262-49b4-9cd5-403fd664ad2f	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-17 04:40:13.45972+00
232c8c28-a270-4ed3-990e-95f5ffe44215	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:42:59.121429+00
b4bc14e1-46d6-4176-b233-3c9bcadbbd38	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT rsvps	rsvps	4692d274-e153-46ce-979f-2681ea011302	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "4692d274-e153-46ce-979f-2681ea011302", "status": "no", "message": null, "created_at": "2026-06-17T04:44:26.487573+00:00", "invited_by": null, "party_size": 1, "responded_at": "2026-06-17T04:44:24.765+00:00", "dietary_notes": null, "invitation_id": "58fd842a-ab6f-43d2-8bd2-a553bebdef49", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-17 04:44:26.487573+00
1b6dc98f-123e-4a8a-88e5-5964a9cd80dd	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT rsvps	rsvps	4692d274-e153-46ce-979f-2681ea011302	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "4692d274-e153-46ce-979f-2681ea011302", "status": "no", "message": null, "created_at": "2026-06-17T04:44:26.487573+00:00", "invited_by": null, "party_size": 1, "responded_at": "2026-06-17T04:44:24.765+00:00", "dietary_notes": null, "invitation_id": "58fd842a-ab6f-43d2-8bd2-a553bebdef49", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-17 04:44:26.487573+00
b4fd2dae-b796-47af-97c2-02f4c80c87ab	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	30c03368-3866-473a-873a-cbce8511850c	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "30c03368-3866-473a-873a-cbce8511850c", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T09:13:32.472886+00:00", "guest_name": "Norma Stanley", "rsvp_token": "Mq4U35BAoxx+K1rt4/XOXRSN", "guest_email": null, "guest_phone": "(402) 804-5835", "is_committee": false, "invite_sent_at": "2026-06-04T09:13:47.485+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028045835"}, "old": {"id": "30c03368-3866-473a-873a-cbce8511850c", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T09:13:32.472886+00:00", "guest_name": "NE Norma Stanley", "rsvp_token": "Mq4U35BAoxx+K1rt4/XOXRSN", "guest_email": null, "guest_phone": "(402) 804-5835", "is_committee": false, "invite_sent_at": "2026-06-04T09:13:47.485+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028045835"}}	t	2026-06-17 04:44:53.01478+00
7c294664-ee3b-40ee-bdff-15ff22326226	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	30c03368-3866-473a-873a-cbce8511850c	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "30c03368-3866-473a-873a-cbce8511850c", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T09:13:32.472886+00:00", "guest_name": "Norma Stanley", "rsvp_token": "Mq4U35BAoxx+K1rt4/XOXRSN", "guest_email": null, "guest_phone": "(402) 804-5835", "is_committee": false, "invite_sent_at": "2026-06-04T09:13:47.485+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028045835"}, "old": {"id": "30c03368-3866-473a-873a-cbce8511850c", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T09:13:32.472886+00:00", "guest_name": "NE Norma Stanley", "rsvp_token": "Mq4U35BAoxx+K1rt4/XOXRSN", "guest_email": null, "guest_phone": "(402) 804-5835", "is_committee": false, "invite_sent_at": "2026-06-04T09:13:47.485+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028045835"}}	t	2026-06-17 04:44:53.01478+00
1d614b3f-d577-4f2e-87d6-be0bd78be72c	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	c2da937c-44f2-48d5-a7a2-2e950fafccb4	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "c2da937c-44f2-48d5-a7a2-2e950fafccb4", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:30:04.605245+00:00", "guest_name": "Alma Hauz", "rsvp_token": "bBo0tfwXNQIFJMoB/TozKoQy", "guest_email": null, "guest_phone": "(402) 968-4098", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029684098"}, "old": {"id": "c2da937c-44f2-48d5-a7a2-2e950fafccb4", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:30:04.605245+00:00", "guest_name": "NE Alma Hauz", "rsvp_token": "bBo0tfwXNQIFJMoB/TozKoQy", "guest_email": null, "guest_phone": "(402) 968-4098", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029684098"}}	t	2026-06-17 04:45:11.517983+00
8dda52e8-98f1-4e53-adfe-9d66aeac288c	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	c2da937c-44f2-48d5-a7a2-2e950fafccb4	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "c2da937c-44f2-48d5-a7a2-2e950fafccb4", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:30:04.605245+00:00", "guest_name": "Alma Hauz", "rsvp_token": "bBo0tfwXNQIFJMoB/TozKoQy", "guest_email": null, "guest_phone": "(402) 968-4098", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029684098"}, "old": {"id": "c2da937c-44f2-48d5-a7a2-2e950fafccb4", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:30:04.605245+00:00", "guest_name": "NE Alma Hauz", "rsvp_token": "bBo0tfwXNQIFJMoB/TozKoQy", "guest_email": null, "guest_phone": "(402) 968-4098", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029684098"}}	t	2026-06-17 04:45:11.517983+00
2477a3fb-453e-4991-bb64-dfc2c38ff868	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	899c9fe5-6c60-4e8a-85b0-767b0420d790	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "899c9fe5-6c60-4e8a-85b0-767b0420d790", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T09:13:32.832059+00:00", "guest_name": "Norma Biomagnitism", "rsvp_token": "Jqh3qmpH2ET9186c3sqbbz6A", "guest_email": null, "guest_phone": "(402) 601-9619", "is_committee": false, "invite_sent_at": "2026-06-04T09:13:43.956+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026019619"}, "old": {"id": "899c9fe5-6c60-4e8a-85b0-767b0420d790", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T09:13:32.832059+00:00", "guest_name": "NE Norma Biomagnitism", "rsvp_token": "Jqh3qmpH2ET9186c3sqbbz6A", "guest_email": null, "guest_phone": "(402) 601-9619", "is_committee": false, "invite_sent_at": "2026-06-04T09:13:43.956+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026019619"}}	t	2026-06-17 04:45:31.864347+00
aebdbfcb-bbb8-414a-b6cf-48fe3ef2c5f0	\N	\N	\N	UPDATE inviters	inviters	bcb466aa-60e0-4ae0-b03d-ca25f4a2226e	\N	\N	{"new": {"id": "bcb466aa-60e0-4ae0-b03d-ca25f4a2226e", "name": "Kenda Andersen", "email": null, "phone": "(402) 296-9922", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T04:48:22.485042+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "bcb466aa-60e0-4ae0-b03d-ca25f4a2226e", "name": "Kenda Andersen", "email": null, "phone": "(402) 296-9922", "quota": 40, "active": true, "host_id": null, "created_at": "2026-06-17T04:48:22.485042+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 04:50:26.134093+00
69904247-755b-4ca0-a20e-8aae38c01c75	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	899c9fe5-6c60-4e8a-85b0-767b0420d790	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "899c9fe5-6c60-4e8a-85b0-767b0420d790", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T09:13:32.832059+00:00", "guest_name": "Norma Biomagnitism", "rsvp_token": "Jqh3qmpH2ET9186c3sqbbz6A", "guest_email": null, "guest_phone": "(402) 601-9619", "is_committee": false, "invite_sent_at": "2026-06-04T09:13:43.956+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026019619"}, "old": {"id": "899c9fe5-6c60-4e8a-85b0-767b0420d790", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-04T09:13:32.832059+00:00", "guest_name": "NE Norma Biomagnitism", "rsvp_token": "Jqh3qmpH2ET9186c3sqbbz6A", "guest_email": null, "guest_phone": "(402) 601-9619", "is_committee": false, "invite_sent_at": "2026-06-04T09:13:43.956+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026019619"}}	t	2026-06-17 04:45:31.864347+00
e4c01914-2a36-4f9e-be1c-87556c8b5d76	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	6c5d709a-3ab1-41a1-a0fe-2c75d526edfa	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "6c5d709a-3ab1-41a1-a0fe-2c75d526edfa", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.461234+00:00", "guest_name": "Sofia Barios", "rsvp_token": "k0iXzXEVGIE+z00JcTDFWUgM", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}, "old": {"id": "6c5d709a-3ab1-41a1-a0fe-2c75d526edfa", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.461234+00:00", "guest_name": "NE Sofia Barios", "rsvp_token": "k0iXzXEVGIE+z00JcTDFWUgM", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}}	t	2026-06-17 04:45:55.59872+00
295aaab4-5621-4854-b331-05a5597857ee	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	6c5d709a-3ab1-41a1-a0fe-2c75d526edfa	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "6c5d709a-3ab1-41a1-a0fe-2c75d526edfa", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.461234+00:00", "guest_name": "Sofia Barios", "rsvp_token": "k0iXzXEVGIE+z00JcTDFWUgM", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}, "old": {"id": "6c5d709a-3ab1-41a1-a0fe-2c75d526edfa", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.461234+00:00", "guest_name": "NE Sofia Barios", "rsvp_token": "k0iXzXEVGIE+z00JcTDFWUgM", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}}	t	2026-06-17 04:45:55.59872+00
4d17c8c0-ef5b-42ab-a0e6-5eebe87d40f7	\N	\N	\N	UPDATE invitations	invitations	4b7436b1-ef27-4a96-8e4c-afa80fb1c768	\N	\N	{"new": {"id": "4b7436b1-ef27-4a96-8e4c-afa80fb1c768", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T12:59:42.937268+00:00", "guest_name": "Kenda Andersen", "rsvp_token": "n4pt3rY2nrD++/uXBQWZOpRT", "guest_email": null, "guest_phone": "(402) 296-9922", "is_committee": true, "invite_sent_at": "2026-06-03T13:44:57.505+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4022969922"}, "old": {"id": "4b7436b1-ef27-4a96-8e4c-afa80fb1c768", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T12:59:42.937268+00:00", "guest_name": "Kenda Andersen", "rsvp_token": "n4pt3rY2nrD++/uXBQWZOpRT", "guest_email": null, "guest_phone": "(402) 296-9922", "is_committee": false, "invite_sent_at": "2026-06-03T13:44:57.505+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4022969922"}}	t	2026-06-17 04:48:22.485042+00
bc2b8f9e-1c7a-4730-8286-4a758b61fe44	\N	\N	\N	UPDATE invitations	invitations	4b7436b1-ef27-4a96-8e4c-afa80fb1c768	\N	\N	{"new": {"id": "4b7436b1-ef27-4a96-8e4c-afa80fb1c768", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T12:59:42.937268+00:00", "guest_name": "Kenda Andersen", "rsvp_token": "n4pt3rY2nrD++/uXBQWZOpRT", "guest_email": null, "guest_phone": "(402) 296-9922", "is_committee": true, "invite_sent_at": "2026-06-03T13:44:57.505+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4022969922"}, "old": {"id": "4b7436b1-ef27-4a96-8e4c-afa80fb1c768", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T12:59:42.937268+00:00", "guest_name": "Kenda Andersen", "rsvp_token": "n4pt3rY2nrD++/uXBQWZOpRT", "guest_email": null, "guest_phone": "(402) 296-9922", "is_committee": false, "invite_sent_at": "2026-06-03T13:44:57.505+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4022969922"}}	t	2026-06-17 04:48:22.485042+00
921cccbb-9ace-4362-99a4-8357816b41f1	\N	\N	\N	INSERT inviters	inviters	bcb466aa-60e0-4ae0-b03d-ca25f4a2226e	\N	\N	{"new": {"id": "bcb466aa-60e0-4ae0-b03d-ca25f4a2226e", "name": "Kenda Andersen", "email": null, "phone": "(402) 296-9922", "quota": 40, "active": true, "host_id": null, "created_at": "2026-06-17T04:48:22.485042+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 04:48:22.485042+00
9c4eca4e-e1ac-4fee-ace8-2d7b2e29ac6c	\N	\N	\N	INSERT inviters	inviters	bcb466aa-60e0-4ae0-b03d-ca25f4a2226e	\N	\N	{"new": {"id": "bcb466aa-60e0-4ae0-b03d-ca25f4a2226e", "name": "Kenda Andersen", "email": null, "phone": "(402) 296-9922", "quota": 40, "active": true, "host_id": null, "created_at": "2026-06-17T04:48:22.485042+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 04:48:22.485042+00
4331f607-a557-46e5-86ee-d37a7e6ec3b3	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:48:32.338523+00
3e67f1a3-fb68-45c3-98af-eb51707891b9	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:48:42.413144+00
381b53be-59cd-429e-860b-a17f244bfbb2	\N	\N	\N	DELETE inviters	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	\N	\N	{"old": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": "14029795214", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 23:17:01.060887+00
664bac5f-4aeb-45d9-9344-d99518eed3e5	\N	\N	\N	UPDATE inviters	inviters	bcb466aa-60e0-4ae0-b03d-ca25f4a2226e	\N	\N	{"new": {"id": "bcb466aa-60e0-4ae0-b03d-ca25f4a2226e", "name": "Kenda Andersen", "email": null, "phone": "(402) 296-9922", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T04:48:22.485042+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "bcb466aa-60e0-4ae0-b03d-ca25f4a2226e", "name": "Kenda Andersen", "email": null, "phone": "(402) 296-9922", "quota": 40, "active": true, "host_id": null, "created_at": "2026-06-17T04:48:22.485042+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 04:50:26.134093+00
26d85cf7-c6be-42a6-a172-a33b0427f75c	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:50:39.489034+00
4bda3c33-d055-46b4-83ed-5ffc9a60711c	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:52:27.502159+00
ccb8f5f2-283d-401a-b8ff-d9960680d8a1	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:53:29.073923+00
15bcd1a3-7dc3-4fdd-ad13-fe559d69b6ec	\N	18082787562	Kari Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-17 04:55:32.605146+00
391a5d1a-6a37-4d6c-ba52-66648a35d022	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-17 04:55:47.02274+00
1437f787-2d9a-4ac6-b7c2-3391f4691654	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-17 06:23:34.186367+00
e92795f5-ff2f-4579-beae-672f63552cae	\N	\N	\N	INSERT user_roles	user_roles	db47ab9d-ae99-4877-b3cc-8347430b3aca	\N	\N	{"new": {"id": "db47ab9d-ae99-4877-b3cc-8347430b3aca", "role": "host", "user_id": "7ddc9cef-5e30-4246-ae91-0c633f550119"}}	t	2026-06-17 13:17:05.957755+00
6acd2e50-a85e-4f36-83d9-5ad4a07ca9a0	\N	\N	\N	INSERT invitations	invitations	909f367e-52e9-4a8c-bea7-e0f1dafca821	2a06:98c0:3600::103	\N	{"new": {"id": "909f367e-52e9-4a8c-bea7-e0f1dafca821", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T13:17:06.382621+00:00", "guest_name": "Maxine Damazio", "rsvp_token": "bF/dbGRNWfYNbDP9/WFjfn1L", "guest_email": null, "guest_phone": "13478476743", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "13478476743"}}	t	2026-06-17 13:17:06.382621+00
6652e4b5-1559-495a-9076-a2a27ce7e057	\N	\N	\N	INSERT invitations	invitations	909f367e-52e9-4a8c-bea7-e0f1dafca821	2a06:98c0:3600::103	\N	{"new": {"id": "909f367e-52e9-4a8c-bea7-e0f1dafca821", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T13:17:06.382621+00:00", "guest_name": "Maxine Damazio", "rsvp_token": "bF/dbGRNWfYNbDP9/WFjfn1L", "guest_email": null, "guest_phone": "13478476743", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "13478476743"}}	t	2026-06-17 13:17:06.382621+00
0ae4c787-57bc-4bc7-a15b-7a4aa6c33fd2	\N	\N	\N	UPDATE invitations	invitations	909f367e-52e9-4a8c-bea7-e0f1dafca821	2a06:98c0:3600::103	\N	{"new": {"id": "909f367e-52e9-4a8c-bea7-e0f1dafca821", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T13:17:06.382621+00:00", "guest_name": "Maxine Damazio", "rsvp_token": "bF/dbGRNWfYNbDP9/WFjfn1L", "guest_email": null, "guest_phone": "13478476743", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "13478476743"}, "old": {"id": "909f367e-52e9-4a8c-bea7-e0f1dafca821", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T13:17:06.382621+00:00", "guest_name": "Maxine Damazio", "rsvp_token": "bF/dbGRNWfYNbDP9/WFjfn1L", "guest_email": null, "guest_phone": "13478476743", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "13478476743"}}	t	2026-06-17 13:17:06.706804+00
7f699311-8291-47a2-9711-1b848fe4e418	\N	\N	\N	UPDATE invitations	invitations	909f367e-52e9-4a8c-bea7-e0f1dafca821	2a06:98c0:3600::103	\N	{"new": {"id": "909f367e-52e9-4a8c-bea7-e0f1dafca821", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T13:17:06.382621+00:00", "guest_name": "Maxine Damazio", "rsvp_token": "bF/dbGRNWfYNbDP9/WFjfn1L", "guest_email": null, "guest_phone": "13478476743", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "13478476743"}, "old": {"id": "909f367e-52e9-4a8c-bea7-e0f1dafca821", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T13:17:06.382621+00:00", "guest_name": "Maxine Damazio", "rsvp_token": "bF/dbGRNWfYNbDP9/WFjfn1L", "guest_email": null, "guest_phone": "13478476743", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "13478476743"}}	t	2026-06-17 13:17:06.706804+00
025ae68c-e5b1-4ff5-aba3-10e3cba27c45	\N	\N	\N	INSERT rsvps	rsvps	6954ec4f-3386-4895-99d7-dcbeda0c7edc	2a06:98c0:3600::103	\N	{"new": {"id": "6954ec4f-3386-4895-99d7-dcbeda0c7edc", "status": "yes", "message": null, "created_at": "2026-06-17T13:17:06.809032+00:00", "invited_by": "Jacquelyn Spears", "party_size": 1, "responded_at": "2026-06-17T13:17:06.778+00:00", "dietary_notes": null, "invitation_id": "909f367e-52e9-4a8c-bea7-e0f1dafca821", "ordering_food": null, "attendance_mode": "zoom"}}	t	2026-06-17 13:17:06.809032+00
8ccce0d8-d187-4a4b-96de-0b218ba037d7	\N	\N	\N	INSERT rsvps	rsvps	6954ec4f-3386-4895-99d7-dcbeda0c7edc	2a06:98c0:3600::103	\N	{"new": {"id": "6954ec4f-3386-4895-99d7-dcbeda0c7edc", "status": "yes", "message": null, "created_at": "2026-06-17T13:17:06.809032+00:00", "invited_by": "Jacquelyn Spears", "party_size": 1, "responded_at": "2026-06-17T13:17:06.778+00:00", "dietary_notes": null, "invitation_id": "909f367e-52e9-4a8c-bea7-e0f1dafca821", "ordering_food": null, "attendance_mode": "zoom"}}	t	2026-06-17 13:17:06.809032+00
0aaf6e02-793c-4021-a875-b1bd68f8c0dd	\N	\N	\N	UPDATE inviters	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	\N	\N	{"new": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": "14029795214", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": null, "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 16:52:40.915926+00
caa0fb82-fddf-412c-b62a-1bc2784a3427	e7619554-8bc3-4576-916d-2d46229702f4	14022539229	Betsaida Ruiz	UPDATE invitations	invitations	13db7e7a-1b73-43cb-b531-6ccc0a3885c3	174.201.110.29	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"new": {"id": "13db7e7a-1b73-43cb-b531-6ccc0a3885c3", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:36.569858+00:00", "guest_name": "Fanny Villarreal", "rsvp_token": "sIbu+ZcQfy5f90oGzktTfNf5", "guest_email": null, "guest_phone": "402-981-7594", "is_committee": false, "invite_sent_at": "2026-06-17T13:51:05.625+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029817594"}, "old": {"id": "13db7e7a-1b73-43cb-b531-6ccc0a3885c3", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:36.569858+00:00", "guest_name": "Fanny Villarreal", "rsvp_token": "sIbu+ZcQfy5f90oGzktTfNf5", "guest_email": null, "guest_phone": "402-981-7594", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029817594"}}	t	2026-06-17 13:51:05.823663+00
6eea5cfc-77a8-447d-83f2-bc4b0e6312bc	e7619554-8bc3-4576-916d-2d46229702f4	14022539229	Betsaida Ruiz	UPDATE invitations	invitations	13db7e7a-1b73-43cb-b531-6ccc0a3885c3	174.201.110.29	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"new": {"id": "13db7e7a-1b73-43cb-b531-6ccc0a3885c3", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:36.569858+00:00", "guest_name": "Fanny Villarreal", "rsvp_token": "sIbu+ZcQfy5f90oGzktTfNf5", "guest_email": null, "guest_phone": "402-981-7594", "is_committee": false, "invite_sent_at": "2026-06-17T13:51:05.625+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029817594"}, "old": {"id": "13db7e7a-1b73-43cb-b531-6ccc0a3885c3", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:36.569858+00:00", "guest_name": "Fanny Villarreal", "rsvp_token": "sIbu+ZcQfy5f90oGzktTfNf5", "guest_email": null, "guest_phone": "402-981-7594", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029817594"}}	t	2026-06-17 13:51:05.823663+00
bf209374-728a-4762-af07-4dd729ce0beb	e7619554-8bc3-4576-916d-2d46229702f4	14022539229	Betsaida Ruiz	UPDATE invitations	invitations	552622d6-702f-4f48-95ef-0ca823dfe537	174.201.110.29	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"new": {"id": "552622d6-702f-4f48-95ef-0ca823dfe537", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:36.736912+00:00", "guest_name": "Hortencia Jaimes", "rsvp_token": "/H0Twwt+aTn8AmFkgHHpmE5M", "guest_email": null, "guest_phone": "531-444-8758", "is_committee": false, "invite_sent_at": "2026-06-17T13:51:06.883+00:00", "guest_email_normalized": null, "guest_phone_normalized": "5314448758"}, "old": {"id": "552622d6-702f-4f48-95ef-0ca823dfe537", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:36.736912+00:00", "guest_name": "Hortencia Jaimes", "rsvp_token": "/H0Twwt+aTn8AmFkgHHpmE5M", "guest_email": null, "guest_phone": "531-444-8758", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "5314448758"}}	t	2026-06-17 13:51:07.099097+00
1be92fbe-a384-457e-aa82-b8f49504e080	e7619554-8bc3-4576-916d-2d46229702f4	14022539229	Betsaida Ruiz	UPDATE invitations	invitations	552622d6-702f-4f48-95ef-0ca823dfe537	174.201.110.29	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"new": {"id": "552622d6-702f-4f48-95ef-0ca823dfe537", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:36.736912+00:00", "guest_name": "Hortencia Jaimes", "rsvp_token": "/H0Twwt+aTn8AmFkgHHpmE5M", "guest_email": null, "guest_phone": "531-444-8758", "is_committee": false, "invite_sent_at": "2026-06-17T13:51:06.883+00:00", "guest_email_normalized": null, "guest_phone_normalized": "5314448758"}, "old": {"id": "552622d6-702f-4f48-95ef-0ca823dfe537", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:36.736912+00:00", "guest_name": "Hortencia Jaimes", "rsvp_token": "/H0Twwt+aTn8AmFkgHHpmE5M", "guest_email": null, "guest_phone": "531-444-8758", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "5314448758"}}	t	2026-06-17 13:51:07.099097+00
469906ec-4d9a-4835-b768-dde305b63b0a	\N	\N	\N	INSERT inviters	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	\N	\N	{"new": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Fromm", "email": null, "phone": null, "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 16:47:32.157637+00
e1244ebf-94fc-463f-a496-07c836699214	\N	\N	\N	INSERT inviters	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	\N	\N	{"new": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Fromm", "email": null, "phone": null, "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 16:47:32.157637+00
2943fead-c67d-4f2e-abd0-5571b11b8b0a	\N	\N	\N	UPDATE inviters	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	\N	\N	{"new": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": null, "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Fromm", "email": null, "phone": null, "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 16:48:11.68633+00
4e9b2b25-745c-4273-bcba-18002f74f42b	\N	\N	\N	UPDATE inviters	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	\N	\N	{"new": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": null, "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Fromm", "email": null, "phone": null, "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 16:48:11.68633+00
01a06290-619d-4255-9ed0-46a5e9125f15	f90abc4a-6ba0-434c-a825-e287bb6414bb	4029795214	MsDixie L. Frahm	auth.login.success	auth	\N	209.79.168.42	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	{}	t	2026-06-17 16:49:32.498032+00
fc97ee85-8d0c-4fbf-be80-11feef6c1658	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-17 23:06:46.999138+00
3d86565e-1484-4240-81b9-d1bb71d09f3c	\N	\N	\N	UPDATE inviters	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	\N	\N	{"new": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": "14029795214", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": null, "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 16:52:40.915926+00
bcc21fea-85d2-4366-aa27-3d3ab22ecd26	\N	\N	\N	INSERT user_roles	user_roles	f05d39fb-df92-484b-bcf0-4888dffed4e3	\N	\N	{"new": {"id": "f05d39fb-df92-484b-bcf0-4888dffed4e3", "role": "team", "user_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb"}}	t	2026-06-17 16:52:40.915926+00
5d1dd89b-08d5-45b4-a51c-1e3aa2df460a	f90abc4a-6ba0-434c-a825-e287bb6414bb	4029795214	MsDixie L. Frahm	auth.login.success	auth	\N	2600:387:15:4713::6	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-17 16:53:10.221579+00
c693b5a5-2e90-441c-8253-515a6161ddee	f90abc4a-6ba0-434c-a825-e287bb6414bb	14029795214	MsDixie L. Frahm	INSERT inviters	inviters	428f6f14-e64f-47b6-826c-c51c9ab9ff7b	209.79.168.42	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "MsDixie L. Frahm", "email": null, "phone": null, "quota": 40, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": 20, "quota_request_note": null, "quota_requested_at": "2026-06-17T16:55:43.876+00:00"}}	t	2026-06-17 16:55:44.39525+00
e53338f2-2f6c-44b2-808b-4ea772c82f52	f90abc4a-6ba0-434c-a825-e287bb6414bb	14029795214	MsDixie L. Frahm	INSERT inviters	inviters	428f6f14-e64f-47b6-826c-c51c9ab9ff7b	209.79.168.42	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "MsDixie L. Frahm", "email": null, "phone": null, "quota": 40, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": 20, "quota_request_note": null, "quota_requested_at": "2026-06-17T16:55:43.876+00:00"}}	t	2026-06-17 16:55:44.39525+00
1fb9499c-6e3d-4d0e-8eb8-a711728f49a5	f90abc4a-6ba0-434c-a825-e287bb6414bb	14029795214	MsDixie L. Frahm	INSERT invitations	invitations	b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3	209.79.168.42	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3", "notes": null, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T16:57:26.965919+00:00", "guest_name": "Kari Gray", "rsvp_token": "pffJVzxOI1LmFl8U9MfUk3Hg", "guest_email": null, "guest_phone": "1 (808) 278-7562", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "18082787562"}}	t	2026-06-17 16:57:26.965919+00
296e7711-9c42-4f2f-9e6b-8516ab6c59a0	f90abc4a-6ba0-434c-a825-e287bb6414bb	14029795214	MsDixie L. Frahm	INSERT invitations	invitations	b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3	209.79.168.42	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3", "notes": null, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T16:57:26.965919+00:00", "guest_name": "Kari Gray", "rsvp_token": "pffJVzxOI1LmFl8U9MfUk3Hg", "guest_email": null, "guest_phone": "1 (808) 278-7562", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "18082787562"}}	t	2026-06-17 16:57:26.965919+00
8401566b-04c0-4c7a-ad89-66664c024a92	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	2600:387:15:4719::8	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-17 17:31:05.939409+00
5e24d3c0-02bd-4c19-bf92-a5782c3f87d0	f90abc4a-6ba0-434c-a825-e287bb6414bb	4029795214	MsDixie L. Frahm	auth.login.success	auth	\N	209.79.168.116	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	{}	t	2026-06-17 17:55:12.376873+00
fed651bb-d037-4938-af31-72e68a7dbe02	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE inviters	inviters	428f6f14-e64f-47b6-826c-c51c9ab9ff7b	209.79.168.116	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "MsDixie L. Frahm", "email": null, "phone": null, "quota": 20, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "MsDixie L. Frahm", "email": null, "phone": null, "quota": 40, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": 20, "quota_request_note": null, "quota_requested_at": "2026-06-17T16:55:43.876+00:00"}}	t	2026-06-17 18:14:19.970532+00
9832790d-39cb-495c-9a52-e234c2b0e7b2	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE inviters	inviters	428f6f14-e64f-47b6-826c-c51c9ab9ff7b	209.79.168.116	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "MsDixie L. Frahm", "email": null, "phone": null, "quota": 20, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "MsDixie L. Frahm", "email": null, "phone": null, "quota": 40, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": 20, "quota_request_note": null, "quota_requested_at": "2026-06-17T16:55:43.876+00:00"}}	t	2026-06-17 18:14:19.970532+00
4f106fcf-23c5-4bd7-9f3f-920bfaf50dd2	e7619554-8bc3-4576-916d-2d46229702f4	14022539229	Betsaida Ruiz	INSERT category_messages	category_messages	b1e6e2aa-b288-4669-8e84-258f7e168a47	38.3.17.55	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	{"new": {"id": "b1e6e2aa-b288-4669-8e84-258f7e168a47", "body": "Got it, thanks Kari!", "user_id": "e7619554-8bc3-4576-916d-2d46229702f4", "created_at": "2026-06-17T22:02:58.675334+00:00", "category_id": "9e8da7e7-3371-4b42-b3f0-a48e341e3275"}}	t	2026-06-17 22:02:58.675334+00
9e4de060-8e93-442f-8a77-5503a9545913	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-17 23:06:13.613206+00
c5d29619-40b8-49db-ad5f-9ea1988dfe74	\N	\N	\N	UPDATE inviters	inviters	428f6f14-e64f-47b6-826c-c51c9ab9ff7b	\N	\N	{"new": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "Dixie Frahm", "email": null, "phone": "14029795214", "quota": 20, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "MsDixie L. Frahm", "email": null, "phone": null, "quota": 20, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 23:17:01.060887+00
96483f23-3104-4a6c-9a46-30b534b77026	\N	\N	\N	UPDATE inviters	inviters	428f6f14-e64f-47b6-826c-c51c9ab9ff7b	\N	\N	{"new": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "Dixie Frahm", "email": null, "phone": "14029795214", "quota": 20, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "428f6f14-e64f-47b6-826c-c51c9ab9ff7b", "name": "MsDixie L. Frahm", "email": null, "phone": null, "quota": 20, "active": true, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "created_at": "2026-06-17T16:55:44.39525+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-17 23:17:01.060887+00
a0684ee4-0697-46b0-b0ad-bf777d83d1e4	f90abc4a-6ba0-434c-a825-e287bb6414bb	4029795214	MsDixie L. Frahm	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-17 23:18:57.499813+00
b3776527-7be9-40de-b7c4-66aef33ef440	f90abc4a-6ba0-434c-a825-e287bb6414bb	14029795214	MsDixie L. Frahm	DELETE invitations	invitations	b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3", "notes": null, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T16:57:26.965919+00:00", "guest_name": "Kari Gray", "rsvp_token": "pffJVzxOI1LmFl8U9MfUk3Hg", "guest_email": null, "guest_phone": "1 (808) 278-7562", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "18082787562"}}	t	2026-06-17 23:19:45.42739+00
0eda6d55-8fa4-498a-9635-d4d896067212	f90abc4a-6ba0-434c-a825-e287bb6414bb	14029795214	MsDixie L. Frahm	DELETE invitations	invitations	b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3", "notes": null, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T16:57:26.965919+00:00", "guest_name": "Kari Gray", "rsvp_token": "pffJVzxOI1LmFl8U9MfUk3Hg", "guest_email": null, "guest_phone": "1 (808) 278-7562", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "18082787562"}}	t	2026-06-17 23:19:45.42739+00
44b58a7c-7864-494c-9e21-4ba6fd7647be	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-17 23:26:29.901183+00
8519d2bb-6b64-4c1c-a397-46db4ad42c6c	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-18 03:41:54.292619+00
ebfe3234-a63f-4ee1-b50f-fcba1fc6212b	\N	\N	\N	INSERT user_roles	user_roles	686ed5e8-b387-4c9d-9cc0-cdd5d3fc0c3f	\N	\N	{"new": {"id": "686ed5e8-b387-4c9d-9cc0-cdd5d3fc0c3f", "role": "host", "user_id": "8ea8ab67-d110-402d-94a6-6482eb08f692"}}	t	2026-06-18 17:10:32.899546+00
e90dfad7-d8a4-4003-badb-6de48386eba2	\N	\N	\N	UPDATE invitations	invitations	38d7a42f-6da9-4458-9e33-5de51ea9022d	2a06:98c0:3600::103	\N	{"new": {"id": "38d7a42f-6da9-4458-9e33-5de51ea9022d", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-15T19:08:21.260571+00:00", "guest_name": "Tirzah Corbin", "rsvp_token": "jPkA0WgtRh2qqtQe05HEqG7H", "guest_email": null, "guest_phone": "6084124014", "is_committee": false, "invite_sent_at": "2026-06-15T19:09:53.532+00:00", "guest_email_normalized": null, "guest_phone_normalized": "6084124014"}, "old": {"id": "38d7a42f-6da9-4458-9e33-5de51ea9022d", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-15T19:08:21.260571+00:00", "guest_name": "Caleb & Tirzah Corbin", "rsvp_token": "jPkA0WgtRh2qqtQe05HEqG7H", "guest_email": null, "guest_phone": "608) 412-4014", "is_committee": false, "invite_sent_at": "2026-06-15T19:09:53.532+00:00", "guest_email_normalized": null, "guest_phone_normalized": "6084124014"}}	t	2026-06-18 17:10:33.47723+00
56f5a975-ae66-437d-968e-78abbbdc70fe	\N	\N	\N	UPDATE invitations	invitations	38d7a42f-6da9-4458-9e33-5de51ea9022d	2a06:98c0:3600::103	\N	{"new": {"id": "38d7a42f-6da9-4458-9e33-5de51ea9022d", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-15T19:08:21.260571+00:00", "guest_name": "Tirzah Corbin", "rsvp_token": "jPkA0WgtRh2qqtQe05HEqG7H", "guest_email": null, "guest_phone": "6084124014", "is_committee": false, "invite_sent_at": "2026-06-15T19:09:53.532+00:00", "guest_email_normalized": null, "guest_phone_normalized": "6084124014"}, "old": {"id": "38d7a42f-6da9-4458-9e33-5de51ea9022d", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-15T19:08:21.260571+00:00", "guest_name": "Caleb & Tirzah Corbin", "rsvp_token": "jPkA0WgtRh2qqtQe05HEqG7H", "guest_email": null, "guest_phone": "608) 412-4014", "is_committee": false, "invite_sent_at": "2026-06-15T19:09:53.532+00:00", "guest_email_normalized": null, "guest_phone_normalized": "6084124014"}}	t	2026-06-18 17:10:33.47723+00
6d5aef31-c3cf-40ed-a2e9-0e48c8754d04	\N	\N	\N	INSERT rsvps	rsvps	d7601c52-4d50-4919-be19-f38f5f244e1e	2a06:98c0:3600::103	\N	{"new": {"id": "d7601c52-4d50-4919-be19-f38f5f244e1e", "status": "yes", "message": null, "created_at": "2026-06-18T17:10:33.601449+00:00", "invited_by": "Betsaida Ruiz", "party_size": 2, "responded_at": "2026-06-18T17:10:33.531+00:00", "dietary_notes": null, "invitation_id": "38d7a42f-6da9-4458-9e33-5de51ea9022d", "ordering_food": true, "attendance_mode": "in_person"}}	t	2026-06-18 17:10:33.601449+00
ecfe86fb-1325-40ee-8a6f-030ee0776b37	\N	\N	\N	INSERT rsvps	rsvps	d7601c52-4d50-4919-be19-f38f5f244e1e	2a06:98c0:3600::103	\N	{"new": {"id": "d7601c52-4d50-4919-be19-f38f5f244e1e", "status": "yes", "message": null, "created_at": "2026-06-18T17:10:33.601449+00:00", "invited_by": "Betsaida Ruiz", "party_size": 2, "responded_at": "2026-06-18T17:10:33.531+00:00", "dietary_notes": null, "invitation_id": "38d7a42f-6da9-4458-9e33-5de51ea9022d", "ordering_food": true, "attendance_mode": "in_person"}}	t	2026-06-18 17:10:33.601449+00
20cc20ee-7041-4992-bdd7-19fd1ed88ccb	\N	\N	\N	INSERT cuisine_preorders	cuisine_preorders	f49e9503-7c35-4df4-930c-f68be5ed628b	2a06:98c0:3600::103	\N	{"new": {"id": "f49e9503-7c35-4df4-930c-f68be5ed628b", "name": "Tirzah Corbin", "phone": "6084124014", "created_at": "2026-06-18T17:10:33.70243+00:00", "selections": [{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "Indonesian"}], "updated_at": "2026-06-18T17:10:33.70243+00:00", "invitation_id": "38d7a42f-6da9-4458-9e33-5de51ea9022d"}}	t	2026-06-18 17:10:33.70243+00
75303fc7-702c-47d2-bfca-63cb4e6b4697	\N	\N	\N	INSERT cuisine_preorders	cuisine_preorders	f49e9503-7c35-4df4-930c-f68be5ed628b	2a06:98c0:3600::103	\N	{"new": {"id": "f49e9503-7c35-4df4-930c-f68be5ed628b", "name": "Tirzah Corbin", "phone": "6084124014", "created_at": "2026-06-18T17:10:33.70243+00:00", "selections": [{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "Indonesian"}], "updated_at": "2026-06-18T17:10:33.70243+00:00", "invitation_id": "38d7a42f-6da9-4458-9e33-5de51ea9022d"}}	t	2026-06-18 17:10:33.70243+00
d5175816-daed-44b7-821d-668715d775ad	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT rsvps	rsvps	5a8ede71-18a3-440d-9323-339078ad683d	209.79.168.55	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "5a8ede71-18a3-440d-9323-339078ad683d", "status": "no", "message": null, "created_at": "2026-06-18T17:28:06.407681+00:00", "invited_by": null, "party_size": 1, "responded_at": "2026-06-18T17:28:05.947+00:00", "dietary_notes": null, "invitation_id": "e64d3665-bae2-4081-b704-0ec4fc3fc22c", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-18 17:28:06.407681+00
85cb6cdb-5187-402b-bf4d-ca2ceb060798	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT rsvps	rsvps	5a8ede71-18a3-440d-9323-339078ad683d	209.79.168.55	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "5a8ede71-18a3-440d-9323-339078ad683d", "status": "no", "message": null, "created_at": "2026-06-18T17:28:06.407681+00:00", "invited_by": null, "party_size": 1, "responded_at": "2026-06-18T17:28:05.947+00:00", "dietary_notes": null, "invitation_id": "e64d3665-bae2-4081-b704-0ec4fc3fc22c", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-18 17:28:06.407681+00
edba04de-1b06-4113-895d-47c99a942f87	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	auth.login.success	auth	\N	2600:387:15:4714::7	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.217 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-19 01:45:00.641197+00
7787da9c-29f2-4801-8e47-6812c151e7d8	\N	14023213146	Drake	auth.login.failure	auth	\N	172.56.129.51	Mozilla/5.0 (iPhone; CPU iPhone OS 26_1_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/425.6.927981711 Mobile/15E148 Safari/604.1	{"reason": "phone_not_on_list"}	f	2026-06-19 01:59:03.263883+00
3966d124-e161-4671-a9c2-b85f11fe5833	\N	14023213146	Drake l	auth.login.failure	auth	\N	172.56.129.51	Mozilla/5.0 (iPhone; CPU iPhone OS 26_1_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/425.6.927981711 Mobile/15E148 Safari/604.1	{"reason": "phone_not_on_list"}	f	2026-06-19 01:59:25.600218+00
6a2aa2f7-5cec-42b8-af55-171b7104e1c6	2bb6d8c2-f152-442e-978a-ead28f0a281b	4023213146	Teresa Drake	auth.login.success	auth	\N	172.56.129.51	Mozilla/5.0 (iPhone; CPU iPhone OS 26_1_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) GSA/425.6.927981711 Mobile/15E148 Safari/604.1	{}	t	2026-06-19 01:59:49.81894+00
15f8f279-8252-4c4e-ba8e-b76bdca9c6e7	\N	\N	\N	UPDATE invitations	invitations	fa164673-7fcd-4cd9-b9df-a52c6ded47ba	2a06:98c0:3600::103	\N	{"new": {"id": "fa164673-7fcd-4cd9-b9df-a52c6ded47ba", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:12.231033+00:00", "guest_name": "Teresa Drake", "rsvp_token": "R1PK04s87c1t+DmoV5ppRE3B", "guest_email": null, "guest_phone": "4023213146", "is_committee": true, "invite_sent_at": "2026-06-03T06:27:17.017+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4023213146"}, "old": {"id": "fa164673-7fcd-4cd9-b9df-a52c6ded47ba", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:12.231033+00:00", "guest_name": "Teresa Drake", "rsvp_token": "R1PK04s87c1t+DmoV5ppRE3B", "guest_email": null, "guest_phone": "(402) 321-3146", "is_committee": true, "invite_sent_at": "2026-06-03T06:27:17.017+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4023213146"}}	t	2026-06-19 02:02:20.392354+00
8a55a95e-925b-4813-a24a-d39ff984cc85	\N	\N	\N	UPDATE invitations	invitations	fa164673-7fcd-4cd9-b9df-a52c6ded47ba	2a06:98c0:3600::103	\N	{"new": {"id": "fa164673-7fcd-4cd9-b9df-a52c6ded47ba", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:12.231033+00:00", "guest_name": "Teresa Drake", "rsvp_token": "R1PK04s87c1t+DmoV5ppRE3B", "guest_email": null, "guest_phone": "4023213146", "is_committee": true, "invite_sent_at": "2026-06-03T06:27:17.017+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4023213146"}, "old": {"id": "fa164673-7fcd-4cd9-b9df-a52c6ded47ba", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:12.231033+00:00", "guest_name": "Teresa Drake", "rsvp_token": "R1PK04s87c1t+DmoV5ppRE3B", "guest_email": null, "guest_phone": "(402) 321-3146", "is_committee": true, "invite_sent_at": "2026-06-03T06:27:17.017+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4023213146"}}	t	2026-06-19 02:02:20.392354+00
098fb19e-1a21-4724-9443-2f933b11c19f	\N	\N	\N	INSERT rsvps	rsvps	5a35e521-f842-487f-b532-192c6a372c2b	2a06:98c0:3600::103	\N	{"new": {"id": "5a35e521-f842-487f-b532-192c6a372c2b", "status": "yes", "message": null, "created_at": "2026-06-19T02:02:20.577425+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-19T02:02:20.513+00:00", "dietary_notes": null, "invitation_id": "fa164673-7fcd-4cd9-b9df-a52c6ded47ba", "ordering_food": false, "attendance_mode": "in_person"}}	t	2026-06-19 02:02:20.577425+00
da2cdf5a-5695-42fd-bf6e-edff0741df34	\N	\N	\N	INSERT rsvps	rsvps	5a35e521-f842-487f-b532-192c6a372c2b	2a06:98c0:3600::103	\N	{"new": {"id": "5a35e521-f842-487f-b532-192c6a372c2b", "status": "yes", "message": null, "created_at": "2026-06-19T02:02:20.577425+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-19T02:02:20.513+00:00", "dietary_notes": null, "invitation_id": "fa164673-7fcd-4cd9-b9df-a52c6ded47ba", "ordering_food": false, "attendance_mode": "in_person"}}	t	2026-06-19 02:02:20.577425+00
7a0792e1-45c1-4eee-8e2d-f7a032624d12	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT category_messages	category_messages	07634d11-463f-4224-8831-b8f3d4f7c2da	209.79.168.63	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "07634d11-463f-4224-8831-b8f3d4f7c2da", "body": "https://docs.google.com/document/d/14EYO6j_ZAB0n6nqxQ-grL9IdiOEDsyHWrC1oVkd7nos/edit?usp=drivesdk", "user_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "created_at": "2026-06-19T17:21:55.294554+00:00", "category_id": "9e8da7e7-3371-4b42-b3f0-a48e341e3275"}}	t	2026-06-19 17:21:55.294554+00
c9a1f1d1-1ffc-440f-a7a7-2dbc305f807a	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT category_messages	category_messages	bce10bf8-e3da-4e3c-b083-d13926fa740f	209.79.168.63	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "bce10bf8-e3da-4e3c-b083-d13926fa740f", "body": "We have confirmed reservation for 4", "user_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "created_at": "2026-06-19T17:22:20.260655+00:00", "category_id": "9e8da7e7-3371-4b42-b3f0-a48e341e3275"}}	t	2026-06-19 17:22:20.260655+00
c22d88ee-1447-4e56-924e-6853a029754e	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-19 19:04:45.563942+00
1c17d048-a5b8-4bfe-929d-3a530cbf22fc	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{}	t	2026-06-19 19:04:58.021309+00
b167b3e7-934c-4b8c-9f20-9fa6afa4a47a	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	ea74a45e-a8f3-4ee7-9c20-6bf2dcad2f99	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "ea74a45e-a8f3-4ee7-9c20-6bf2dcad2f99", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T21:49:35.81796+00:00", "guest_name": "MICHELLE SHAUGER", "rsvp_token": "K5ngx5vjjKVYEjTQ9AvDN9xV", "guest_email": null, "guest_phone": "989-430-1979", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:01.263+00:00", "guest_email_normalized": null, "guest_phone_normalized": "9894301979"}, "old": {"id": "ea74a45e-a8f3-4ee7-9c20-6bf2dcad2f99", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T21:49:35.81796+00:00", "guest_name": "MICHELLE SHAUGER", "rsvp_token": "K5ngx5vjjKVYEjTQ9AvDN9xV", "guest_email": null, "guest_phone": "989-430-1979", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "9894301979"}}	t	2026-06-19 19:16:03.321004+00
0938856b-bbdb-4b79-b77d-c41d8a4b4149	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	ea74a45e-a8f3-4ee7-9c20-6bf2dcad2f99	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "ea74a45e-a8f3-4ee7-9c20-6bf2dcad2f99", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T21:49:35.81796+00:00", "guest_name": "MICHELLE SHAUGER", "rsvp_token": "K5ngx5vjjKVYEjTQ9AvDN9xV", "guest_email": null, "guest_phone": "989-430-1979", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:01.263+00:00", "guest_email_normalized": null, "guest_phone_normalized": "9894301979"}, "old": {"id": "ea74a45e-a8f3-4ee7-9c20-6bf2dcad2f99", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T21:49:35.81796+00:00", "guest_name": "MICHELLE SHAUGER", "rsvp_token": "K5ngx5vjjKVYEjTQ9AvDN9xV", "guest_email": null, "guest_phone": "989-430-1979", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "9894301979"}}	t	2026-06-19 19:16:03.321004+00
7afd56a7-8525-4bee-860f-e5f1170749bc	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	e325e7a9-6c95-4be4-9aad-622e428408df	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "e325e7a9-6c95-4be4-9aad-622e428408df", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T21:16:27.028789+00:00", "guest_name": "Shelley Monaghan", "rsvp_token": "LqZe6BjpuNT+T/8xj9CNMNNN", "guest_email": null, "guest_phone": "4026394513", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:05.058+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026394513"}, "old": {"id": "e325e7a9-6c95-4be4-9aad-622e428408df", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T21:16:27.028789+00:00", "guest_name": "Shelley Monaghan", "rsvp_token": "LqZe6BjpuNT+T/8xj9CNMNNN", "guest_email": null, "guest_phone": "4026394513", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4026394513"}}	t	2026-06-19 19:16:06.49937+00
38d531bb-bb76-4c35-9611-a1d69259cde3	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	e325e7a9-6c95-4be4-9aad-622e428408df	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "e325e7a9-6c95-4be4-9aad-622e428408df", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T21:16:27.028789+00:00", "guest_name": "Shelley Monaghan", "rsvp_token": "LqZe6BjpuNT+T/8xj9CNMNNN", "guest_email": null, "guest_phone": "4026394513", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:05.058+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026394513"}, "old": {"id": "e325e7a9-6c95-4be4-9aad-622e428408df", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T21:16:27.028789+00:00", "guest_name": "Shelley Monaghan", "rsvp_token": "LqZe6BjpuNT+T/8xj9CNMNNN", "guest_email": null, "guest_phone": "4026394513", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4026394513"}}	t	2026-06-19 19:16:06.49937+00
e762468d-7e5a-4e22-b183-b3ccb41565b0	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	6c5d709a-3ab1-41a1-a0fe-2c75d526edfa	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "6c5d709a-3ab1-41a1-a0fe-2c75d526edfa", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.461234+00:00", "guest_name": "Sofia Barios", "rsvp_token": "k0iXzXEVGIE+z00JcTDFWUgM", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:09.826+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}, "old": {"id": "6c5d709a-3ab1-41a1-a0fe-2c75d526edfa", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.461234+00:00", "guest_name": "Sofia Barios", "rsvp_token": "k0iXzXEVGIE+z00JcTDFWUgM", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}}	t	2026-06-19 19:16:11.387729+00
78cf21bc-8115-4486-b05d-5704be2b6ddf	\N	\N	\N	INSERT invitations	invitations	b57cc74c-8298-4f7c-9324-88f17b498626	2a06:98c0:3600::103	\N	{"new": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}}	t	2026-06-22 10:15:04.913092+00
a7de65a3-d220-47d3-b60d-3018ebd6ca51	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	6c5d709a-3ab1-41a1-a0fe-2c75d526edfa	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "6c5d709a-3ab1-41a1-a0fe-2c75d526edfa", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.461234+00:00", "guest_name": "Sofia Barios", "rsvp_token": "k0iXzXEVGIE+z00JcTDFWUgM", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:09.826+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}, "old": {"id": "6c5d709a-3ab1-41a1-a0fe-2c75d526edfa", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.461234+00:00", "guest_name": "Sofia Barios", "rsvp_token": "k0iXzXEVGIE+z00JcTDFWUgM", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}}	t	2026-06-19 19:16:11.387729+00
aacd305b-8ff2-4fd5-b146-aa4971c7b351	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	c2da937c-44f2-48d5-a7a2-2e950fafccb4	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "c2da937c-44f2-48d5-a7a2-2e950fafccb4", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:30:04.605245+00:00", "guest_name": "Alma Hauz", "rsvp_token": "bBo0tfwXNQIFJMoB/TozKoQy", "guest_email": null, "guest_phone": "(402) 968-4098", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:18.242+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029684098"}, "old": {"id": "c2da937c-44f2-48d5-a7a2-2e950fafccb4", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:30:04.605245+00:00", "guest_name": "Alma Hauz", "rsvp_token": "bBo0tfwXNQIFJMoB/TozKoQy", "guest_email": null, "guest_phone": "(402) 968-4098", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029684098"}}	t	2026-06-19 19:16:19.606673+00
f31aeb55-c076-42d7-9f6b-2fe149ef6449	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	c2da937c-44f2-48d5-a7a2-2e950fafccb4	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "c2da937c-44f2-48d5-a7a2-2e950fafccb4", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:30:04.605245+00:00", "guest_name": "Alma Hauz", "rsvp_token": "bBo0tfwXNQIFJMoB/TozKoQy", "guest_email": null, "guest_phone": "(402) 968-4098", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:18.242+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029684098"}, "old": {"id": "c2da937c-44f2-48d5-a7a2-2e950fafccb4", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:30:04.605245+00:00", "guest_name": "Alma Hauz", "rsvp_token": "bBo0tfwXNQIFJMoB/TozKoQy", "guest_email": null, "guest_phone": "(402) 968-4098", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029684098"}}	t	2026-06-19 19:16:19.606673+00
b38699f5-069b-4946-a57e-d7865bf36ba7	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	0a04ea4a-4bca-4adf-afa9-519b47c62233	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "0a04ea4a-4bca-4adf-afa9-519b47c62233", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T16:53:11.633065+00:00", "guest_name": "Abraham Rodriguez", "rsvp_token": "6Xf6u/YcN67tmQm6TGq8LR+k", "guest_email": null, "guest_phone": "7076289800", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:33.95+00:00", "guest_email_normalized": null, "guest_phone_normalized": "7076289800"}, "old": {"id": "0a04ea4a-4bca-4adf-afa9-519b47c62233", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T16:53:11.633065+00:00", "guest_name": "Abraham Rodriguez", "rsvp_token": "6Xf6u/YcN67tmQm6TGq8LR+k", "guest_email": null, "guest_phone": "7076289800", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "7076289800"}}	t	2026-06-19 19:16:35.414291+00
a9ec0f9b-ed63-42cf-9d43-9aace16a5f0c	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	0a04ea4a-4bca-4adf-afa9-519b47c62233	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "0a04ea4a-4bca-4adf-afa9-519b47c62233", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T16:53:11.633065+00:00", "guest_name": "Abraham Rodriguez", "rsvp_token": "6Xf6u/YcN67tmQm6TGq8LR+k", "guest_email": null, "guest_phone": "7076289800", "is_committee": false, "invite_sent_at": "2026-06-19T19:16:33.95+00:00", "guest_email_normalized": null, "guest_phone_normalized": "7076289800"}, "old": {"id": "0a04ea4a-4bca-4adf-afa9-519b47c62233", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T16:53:11.633065+00:00", "guest_name": "Abraham Rodriguez", "rsvp_token": "6Xf6u/YcN67tmQm6TGq8LR+k", "guest_email": null, "guest_phone": "7076289800", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "7076289800"}}	t	2026-06-19 19:16:35.414291+00
4a5c21cf-d2ce-40b7-9c5d-eead50949913	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT rsvps	rsvps	b59b4099-f0ec-4783-a620-b49ae095b8ee	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "b59b4099-f0ec-4783-a620-b49ae095b8ee", "status": "no", "message": null, "created_at": "2026-06-19T19:17:49.123236+00:00", "invited_by": null, "party_size": 1, "responded_at": "2026-06-19T19:17:47.066+00:00", "dietary_notes": null, "invitation_id": "5a73b19b-305b-4d23-87cb-2e64e64b5b86", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-19 19:17:49.123236+00
c54caea1-c004-4244-8071-1ab8fda8f8e9	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT rsvps	rsvps	b59b4099-f0ec-4783-a620-b49ae095b8ee	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "b59b4099-f0ec-4783-a620-b49ae095b8ee", "status": "no", "message": null, "created_at": "2026-06-19T19:17:49.123236+00:00", "invited_by": null, "party_size": 1, "responded_at": "2026-06-19T19:17:47.066+00:00", "dietary_notes": null, "invitation_id": "5a73b19b-305b-4d23-87cb-2e64e64b5b86", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-19 19:17:49.123236+00
52fb04f6-5de1-421e-b540-845ff9f5eac6	\N	\N	\N	INSERT user_roles	user_roles	ce05934f-8347-45f0-9494-73c4f1efe21b	\N	\N	{"new": {"id": "ce05934f-8347-45f0-9494-73c4f1efe21b", "role": "host", "user_id": "792d7129-1efe-4617-bc48-d4a3b7d43530"}}	t	2026-06-23 03:36:57.372104+00
bff41253-c399-4ec5-ba48-bbfdd2560520	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	8a30cef1-f3c0-41fd-a93a-83d73d34f09b	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "8a30cef1-f3c0-41fd-a93a-83d73d34f09b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T08:06:08.546062+00:00", "guest_name": "Ms Dixie L. Frahm", "rsvp_token": "xaoSXWDvYm54iVC8I/Iiweef", "guest_email": null, "guest_phone": "4029795214", "is_committee": false, "invite_sent_at": "2026-06-03T08:06:25.858+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029795214"}, "old": {"id": "8a30cef1-f3c0-41fd-a93a-83d73d34f09b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T08:06:08.546062+00:00", "guest_name": "MsDixie L. Frahm", "rsvp_token": "xaoSXWDvYm54iVC8I/Iiweef", "guest_email": null, "guest_phone": "4029795214", "is_committee": false, "invite_sent_at": "2026-06-03T08:06:25.858+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029795214"}}	t	2026-06-19 19:18:08.203332+00
193c64ba-d165-44b2-9ac1-874fb5ab70bd	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	8a30cef1-f3c0-41fd-a93a-83d73d34f09b	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "8a30cef1-f3c0-41fd-a93a-83d73d34f09b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T08:06:08.546062+00:00", "guest_name": "Ms Dixie L. Frahm", "rsvp_token": "xaoSXWDvYm54iVC8I/Iiweef", "guest_email": null, "guest_phone": "4029795214", "is_committee": false, "invite_sent_at": "2026-06-03T08:06:25.858+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029795214"}, "old": {"id": "8a30cef1-f3c0-41fd-a93a-83d73d34f09b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T08:06:08.546062+00:00", "guest_name": "MsDixie L. Frahm", "rsvp_token": "xaoSXWDvYm54iVC8I/Iiweef", "guest_email": null, "guest_phone": "4029795214", "is_committee": false, "invite_sent_at": "2026-06-03T08:06:25.858+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029795214"}}	t	2026-06-19 19:18:08.203332+00
8123ec5b-92b4-4bb3-aae8-bb5325b44cde	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	f55e10f3-592a-4526-bef6-00558aedeb1f	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "f55e10f3-592a-4526-bef6-00558aedeb1f", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:12.095954+00:00", "guest_name": "Steven & Denise Madsen", "rsvp_token": "fRitcPJqZVlomIssMbLm0ZTC", "guest_email": null, "guest_phone": "(402) 714 1491", "is_committee": false, "invite_sent_at": "2026-06-03T07:02:38.965+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4027141491"}, "old": {"id": "f55e10f3-592a-4526-bef6-00558aedeb1f", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:12.095954+00:00", "guest_name": "Steven&Denise Madsen", "rsvp_token": "fRitcPJqZVlomIssMbLm0ZTC", "guest_email": null, "guest_phone": "(402) 714 1491", "is_committee": false, "invite_sent_at": "2026-06-03T07:02:38.965+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4027141491"}}	t	2026-06-19 19:20:04.557574+00
762b0432-5024-409c-ad4e-f018344b9918	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	f55e10f3-592a-4526-bef6-00558aedeb1f	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "f55e10f3-592a-4526-bef6-00558aedeb1f", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:12.095954+00:00", "guest_name": "Steven & Denise Madsen", "rsvp_token": "fRitcPJqZVlomIssMbLm0ZTC", "guest_email": null, "guest_phone": "(402) 714 1491", "is_committee": false, "invite_sent_at": "2026-06-03T07:02:38.965+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4027141491"}, "old": {"id": "f55e10f3-592a-4526-bef6-00558aedeb1f", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:12.095954+00:00", "guest_name": "Steven&Denise Madsen", "rsvp_token": "fRitcPJqZVlomIssMbLm0ZTC", "guest_email": null, "guest_phone": "(402) 714 1491", "is_committee": false, "invite_sent_at": "2026-06-03T07:02:38.965+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4027141491"}}	t	2026-06-19 19:20:04.557574+00
84cabfdb-8bea-4fb8-ba90-fba8665a3d63	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	970eadfe-ddf9-48fe-a659-0d84b3968b73	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "970eadfe-ddf9-48fe-a659-0d84b3968b73", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.743598+00:00", "guest_name": "Shelley & Pat Monahan", "rsvp_token": "Mpm9j3TBwph6/pGvdQidhKNK", "guest_email": null, "guest_phone": "+1 402-639-4513", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:26.352+00:00", "guest_email_normalized": null, "guest_phone_normalized": "14026394513"}}	t	2026-06-19 19:26:15.877097+00
05354b4a-0d41-4070-9b34-b6444f6be252	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	970eadfe-ddf9-48fe-a659-0d84b3968b73	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "970eadfe-ddf9-48fe-a659-0d84b3968b73", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.743598+00:00", "guest_name": "Shelley & Pat Monahan", "rsvp_token": "Mpm9j3TBwph6/pGvdQidhKNK", "guest_email": null, "guest_phone": "+1 402-639-4513", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:26.352+00:00", "guest_email_normalized": null, "guest_phone_normalized": "14026394513"}}	t	2026-06-19 19:26:15.877097+00
b6326fa9-c26d-4a32-b7a8-7e0d032860a2	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	0aea5691-1402-4357-9429-9062353d9622	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "0aea5691-1402-4357-9429-9062353d9622", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.064897+00:00", "guest_name": "Michelle Shawger", "rsvp_token": "OPP/IApzbh3QB8FHSfwYtTpK", "guest_email": null, "guest_phone": "+1 989-430-1979", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:14.958+00:00", "guest_email_normalized": null, "guest_phone_normalized": "19894301979"}}	t	2026-06-19 19:26:26.013967+00
c4cc3f76-7518-407c-af63-251635ff1538	\N	\N	\N	INSERT rsvps	rsvps	b07d054a-fe9c-47f7-9a57-2f1f57fd21dc	2a06:98c0:3600::103	\N	{"new": {"id": "b07d054a-fe9c-47f7-9a57-2f1f57fd21dc", "status": "no", "message": null, "created_at": "2026-06-26T17:34:49.771317+00:00", "invited_by": "Kari Gray", "party_size": 2, "responded_at": "2026-06-26T17:34:49.704+00:00", "dietary_notes": null, "invitation_id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-26 17:34:49.771317+00
9c9e9f9e-5696-4c0e-8796-e0c79978f103	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	0aea5691-1402-4357-9429-9062353d9622	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"old": {"id": "0aea5691-1402-4357-9429-9062353d9622", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.064897+00:00", "guest_name": "Michelle Shawger", "rsvp_token": "OPP/IApzbh3QB8FHSfwYtTpK", "guest_email": null, "guest_phone": "+1 989-430-1979", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:14.958+00:00", "guest_email_normalized": null, "guest_phone_normalized": "19894301979"}}	t	2026-06-19 19:26:26.013967+00
6045a6dc-d7d9-483f-b9ad-bfd965783776	\N	\N	\N	UPDATE invitations	invitations	e6a7d814-64ba-4119-8311-933ffd77b108	\N	\N	{"new": {"id": "e6a7d814-64ba-4119-8311-933ffd77b108", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:28.608426+00:00", "guest_name": "Melissa Novotny", "rsvp_token": "FlyUFwPTtO+5wC6Gik2IliCQ", "guest_email": null, "guest_phone": "4026796544", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:33.963+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026796544"}, "old": {"id": "e6a7d814-64ba-4119-8311-933ffd77b108", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:28.608426+00:00", "guest_name": "Melissa Novotne", "rsvp_token": "FlyUFwPTtO+5wC6Gik2IliCQ", "guest_email": null, "guest_phone": "4026796544", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:33.963+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026796544"}}	t	2026-06-20 01:52:04.82755+00
7706c1f3-b8c0-4b57-81e0-8fe8f130b3fb	\N	\N	\N	UPDATE invitations	invitations	e6a7d814-64ba-4119-8311-933ffd77b108	\N	\N	{"new": {"id": "e6a7d814-64ba-4119-8311-933ffd77b108", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:28.608426+00:00", "guest_name": "Melissa Novotny", "rsvp_token": "FlyUFwPTtO+5wC6Gik2IliCQ", "guest_email": null, "guest_phone": "4026796544", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:33.963+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026796544"}, "old": {"id": "e6a7d814-64ba-4119-8311-933ffd77b108", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:28.608426+00:00", "guest_name": "Melissa Novotne", "rsvp_token": "FlyUFwPTtO+5wC6Gik2IliCQ", "guest_email": null, "guest_phone": "4026796544", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:33.963+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026796544"}}	t	2026-06-20 01:52:04.82755+00
101fe264-ab2e-496f-9b1b-72cf3db03962	\N	\N	\N	UPDATE inviters	inviters	9fed6a58-142a-4200-8b68-c5c8ef83a40c	\N	\N	{"new": {"id": "9fed6a58-142a-4200-8b68-c5c8ef83a40c", "name": "Melissa Novotny", "email": null, "phone": "4026796544", "quota": 25, "active": true, "host_id": "d386b116-f1ec-44fd-954b-800248f2f623", "created_at": "2026-06-03T00:07:04.865016+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "9fed6a58-142a-4200-8b68-c5c8ef83a40c", "name": "Melissa Novotne", "email": null, "phone": null, "quota": 25, "active": true, "host_id": "d386b116-f1ec-44fd-954b-800248f2f623", "created_at": "2026-06-03T00:07:04.865016+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-20 01:52:04.82755+00
6a37a37a-0822-47e3-991e-3bd17956edc6	\N	\N	\N	UPDATE inviters	inviters	9fed6a58-142a-4200-8b68-c5c8ef83a40c	\N	\N	{"new": {"id": "9fed6a58-142a-4200-8b68-c5c8ef83a40c", "name": "Melissa Novotny", "email": null, "phone": "4026796544", "quota": 25, "active": true, "host_id": "d386b116-f1ec-44fd-954b-800248f2f623", "created_at": "2026-06-03T00:07:04.865016+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "9fed6a58-142a-4200-8b68-c5c8ef83a40c", "name": "Melissa Novotne", "email": null, "phone": null, "quota": 25, "active": true, "host_id": "d386b116-f1ec-44fd-954b-800248f2f623", "created_at": "2026-06-03T00:07:04.865016+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-20 01:52:04.82755+00
260a9ae5-e1d7-4d2c-a8ee-0a1e6135b6fa	\N	\N	\N	UPDATE invitations	invitations	2d1f587c-26a7-4491-a2a0-cafce4556d7b	\N	\N	{"new": {"id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:27.490386+00:00", "guest_name": "Jay Wilcher", "rsvp_token": "ushuC9myESKB6C5zFgKxcafk", "guest_email": null, "guest_phone": "(402) 850-8379", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:24.244+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028508379"}, "old": {"id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:27.490386+00:00", "guest_name": "Jay & Rhonda Wilcher", "rsvp_token": "ushuC9myESKB6C5zFgKxcafk", "guest_email": null, "guest_phone": "(402) 850-8379", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:24.244+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028508379"}}	t	2026-06-20 01:52:04.82755+00
4b6c2e83-1311-4e44-98da-507bf36e1c5c	\N	\N	\N	UPDATE invitations	invitations	2d1f587c-26a7-4491-a2a0-cafce4556d7b	\N	\N	{"new": {"id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:27.490386+00:00", "guest_name": "Jay Wilcher", "rsvp_token": "ushuC9myESKB6C5zFgKxcafk", "guest_email": null, "guest_phone": "(402) 850-8379", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:24.244+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028508379"}, "old": {"id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:27.490386+00:00", "guest_name": "Jay & Rhonda Wilcher", "rsvp_token": "ushuC9myESKB6C5zFgKxcafk", "guest_email": null, "guest_phone": "(402) 850-8379", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:24.244+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028508379"}}	t	2026-06-20 01:52:04.82755+00
44fe4fd5-91dd-4901-9ca9-08b8e8784650	\N	\N	\N	UPDATE inviters	inviters	57b0dfd6-df25-49b9-99a4-281327906032	\N	\N	{"new": {"id": "57b0dfd6-df25-49b9-99a4-281327906032", "name": "Jay Wilcher", "email": null, "phone": "(402) 850-8379", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-06T01:52:48.327389+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "57b0dfd6-df25-49b9-99a4-281327906032", "name": "Jay & Rhonda Wilcher", "email": null, "phone": "(402) 850-8379", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-06T01:52:48.327389+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-20 01:52:04.82755+00
cfe2567b-b139-4aa7-8338-bff5b38af4ed	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-26 23:55:59.223487+00
c3692845-ce5c-417c-b366-d4ee15493bf8	\N	\N	\N	UPDATE inviters	inviters	57b0dfd6-df25-49b9-99a4-281327906032	\N	\N	{"new": {"id": "57b0dfd6-df25-49b9-99a4-281327906032", "name": "Jay Wilcher", "email": null, "phone": "(402) 850-8379", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-06T01:52:48.327389+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}, "old": {"id": "57b0dfd6-df25-49b9-99a4-281327906032", "name": "Jay & Rhonda Wilcher", "email": null, "phone": "(402) 850-8379", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-06T01:52:48.327389+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-20 01:52:04.82755+00
2883abf4-0d56-4632-9097-01532a686377	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT inviters	inviters	262317f9-4128-4673-b6da-7cd471ce2b89	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "262317f9-4128-4673-b6da-7cd471ce2b89", "name": "Saul Morro", "email": null, "phone": "+1531-484-5553", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-20T01:54:32.821268+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-20 01:54:32.821268+00
c7088c8d-4767-49b8-aeb8-7f522ff27949	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT inviters	inviters	262317f9-4128-4673-b6da-7cd471ce2b89	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"new": {"id": "262317f9-4128-4673-b6da-7cd471ce2b89", "name": "Saul Morro", "email": null, "phone": "+1531-484-5553", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-20T01:54:32.821268+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}}	t	2026-06-20 01:54:32.821268+00
b244c766-7d69-49e7-b9d2-1ff574952ac7	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	729998ad-4b8a-403d-9ab4-444f5bead9c2	209.79.168.56	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "729998ad-4b8a-403d-9ab4-444f5bead9c2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.119032+00:00", "guest_name": "BW Sister Rodriguez", "rsvp_token": "nEsyHJyI/ZXFXGa2QpqwhL2B", "guest_email": null, "guest_phone": "(402) 973-8878", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029738878"}}	t	2026-06-21 17:25:03.119032+00
757eb1e6-6453-4881-af71-b08dfc0bc668	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	729998ad-4b8a-403d-9ab4-444f5bead9c2	209.79.168.56	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "729998ad-4b8a-403d-9ab4-444f5bead9c2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.119032+00:00", "guest_name": "BW Sister Rodriguez", "rsvp_token": "nEsyHJyI/ZXFXGa2QpqwhL2B", "guest_email": null, "guest_phone": "(402) 973-8878", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029738878"}}	t	2026-06-21 17:25:03.119032+00
0fd08b3e-2298-44db-a1e2-2d0d419abf1f	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	0f1d067f-c2dc-410e-910b-d9791bad9303	209.79.168.56	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "0f1d067f-c2dc-410e-910b-d9791bad9303", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.456448+00:00", "guest_name": "1 other person", "rsvp_token": "SOMHhczIjRi4AYdJfvl/mpcG", "guest_email": null, "guest_phone": null, "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": ""}}	t	2026-06-21 17:25:03.456448+00
d4a42a77-0e89-4fef-81f7-8440abd6a378	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	0f1d067f-c2dc-410e-910b-d9791bad9303	209.79.168.56	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "0f1d067f-c2dc-410e-910b-d9791bad9303", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.456448+00:00", "guest_name": "1 other person", "rsvp_token": "SOMHhczIjRi4AYdJfvl/mpcG", "guest_email": null, "guest_phone": null, "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": ""}}	t	2026-06-21 17:25:03.456448+00
a2111817-c19e-4614-bff3-61a148df5460	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	0eb32b2d-6b36-415e-b348-c9a3e2bc7866	209.79.168.56	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "0eb32b2d-6b36-415e-b348-c9a3e2bc7866", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T19:32:04.852153+00:00", "guest_name": "NE Teri Crohn", "rsvp_token": "bwK6IbKteU/utf8UHs2nsppe", "guest_email": null, "guest_phone": "(402) 738-0706", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4027380706"}}	t	2026-06-21 19:32:04.852153+00
1aa6637c-72fe-4bf2-a1f4-d812195f638c	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	0eb32b2d-6b36-415e-b348-c9a3e2bc7866	209.79.168.56	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "0eb32b2d-6b36-415e-b348-c9a3e2bc7866", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T19:32:04.852153+00:00", "guest_name": "NE Teri Crohn", "rsvp_token": "bwK6IbKteU/utf8UHs2nsppe", "guest_email": null, "guest_phone": "(402) 738-0706", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4027380706"}}	t	2026-06-21 19:32:04.852153+00
d274163e-ceb1-4059-884c-785ac713fdc7	00651c0f-c5e3-45b1-8979-960f3f752c74	8082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-22 01:39:29.170155+00
b203c5c0-15f5-4c1f-9631-ad4a2dc23c0a	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-22 03:04:14.431602+00
8b7a0ebb-b453-44f0-bcf0-3fe720650978	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-22 03:04:24.919958+00
21e29f93-b2b3-42ce-a48a-184ba06d33eb	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	c4b01026-452f-4ed3-936a-0670ffdcfae2	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "c4b01026-452f-4ed3-936a-0670ffdcfae2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.594513+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "3cvNRnr8QhQO2K1iTqVFrf9u", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}}	t	2026-06-22 03:05:56.594513+00
f4fe8135-dcda-4322-aa03-072a140d0f87	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	c4b01026-452f-4ed3-936a-0670ffdcfae2	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "c4b01026-452f-4ed3-936a-0670ffdcfae2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.594513+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "3cvNRnr8QhQO2K1iTqVFrf9u", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}}	t	2026-06-22 03:05:56.594513+00
6b428eb5-8bd7-461c-8a14-47f71c27a5f1	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	fc6e555b-f918-4f29-8ffe-6479052e7429	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "fc6e555b-f918-4f29-8ffe-6479052e7429", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.797183+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "sVvYpceTVgytgcNtwIsDg3qo", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}}	t	2026-06-22 03:05:56.797183+00
fb76a44a-833f-4fe7-8bb5-1fe505660659	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	fc6e555b-f918-4f29-8ffe-6479052e7429	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "fc6e555b-f918-4f29-8ffe-6479052e7429", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.797183+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "sVvYpceTVgytgcNtwIsDg3qo", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}}	t	2026-06-22 03:05:56.797183+00
6e2a0d39-3b1e-4d76-8398-ddb61c93f945	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	fc6e555b-f918-4f29-8ffe-6479052e7429	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "fc6e555b-f918-4f29-8ffe-6479052e7429", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.797183+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "sVvYpceTVgytgcNtwIsDg3qo", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": "2026-06-22T03:16:14.561+00:00", "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}, "old": {"id": "fc6e555b-f918-4f29-8ffe-6479052e7429", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.797183+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "sVvYpceTVgytgcNtwIsDg3qo", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}}	t	2026-06-22 03:16:14.763148+00
9c6b7331-4216-4fe2-b10a-c69395298413	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	fc6e555b-f918-4f29-8ffe-6479052e7429	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "fc6e555b-f918-4f29-8ffe-6479052e7429", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.797183+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "sVvYpceTVgytgcNtwIsDg3qo", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": "2026-06-22T03:16:14.561+00:00", "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}, "old": {"id": "fc6e555b-f918-4f29-8ffe-6479052e7429", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.797183+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "sVvYpceTVgytgcNtwIsDg3qo", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}}	t	2026-06-22 03:16:14.763148+00
2e727ab5-98a4-43b6-b361-2d2c18809f1d	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	c4b01026-452f-4ed3-936a-0670ffdcfae2	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"old": {"id": "c4b01026-452f-4ed3-936a-0670ffdcfae2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.594513+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "3cvNRnr8QhQO2K1iTqVFrf9u", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}}	t	2026-06-22 03:16:20.200792+00
f6b35edc-899a-4f2a-b2e8-3376bac4c686	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	c4b01026-452f-4ed3-936a-0670ffdcfae2	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"old": {"id": "c4b01026-452f-4ed3-936a-0670ffdcfae2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.594513+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "3cvNRnr8QhQO2K1iTqVFrf9u", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}}	t	2026-06-22 03:16:20.200792+00
32dcfb18-94f9-47e9-93a8-e9fef09c355c	\N	\N	\N	INSERT user_roles	user_roles	a4237517-d761-4435-92e5-006e12f21334	\N	\N	{"new": {"id": "a4237517-d761-4435-92e5-006e12f21334", "role": "host", "user_id": "bc4566e5-a976-4c54-9fb6-9fbf32c1a273"}}	t	2026-06-26 23:57:08.533318+00
64debc7e-c0cd-4e13-9ef8-429384e5674f	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	bce49578-39a8-4b6a-9be3-a70703b03350	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "bce49578-39a8-4b6a-9be3-a70703b03350", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:53.899936+00:00", "guest_name": "Deisy Baker", "rsvp_token": "qgLL+8TJdpkCwzJOaL7RZwWG", "guest_email": null, "guest_phone": "(310) 619-3331", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3106193331"}}	t	2026-06-22 03:16:53.899936+00
16e18df2-f30e-42e0-b1b0-9c5011ae3821	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	bce49578-39a8-4b6a-9be3-a70703b03350	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "bce49578-39a8-4b6a-9be3-a70703b03350", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:53.899936+00:00", "guest_name": "Deisy Baker", "rsvp_token": "qgLL+8TJdpkCwzJOaL7RZwWG", "guest_email": null, "guest_phone": "(310) 619-3331", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3106193331"}}	t	2026-06-22 03:16:53.899936+00
8038ef8b-7f76-4d6d-b11e-a3102d7059ff	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	e224d5be-5bd2-4022-87e0-33a8c816f6bc	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "e224d5be-5bd2-4022-87e0-33a8c816f6bc", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.168856+00:00", "guest_name": "Cari Clifford", "rsvp_token": "byGS9giexpuIhfH27kX0yb/f", "guest_email": null, "guest_phone": "(402) 681-7443", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4026817443"}}	t	2026-06-22 03:16:54.168856+00
864ec795-5dca-4ae1-ace2-b0dbef797698	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	e224d5be-5bd2-4022-87e0-33a8c816f6bc	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "e224d5be-5bd2-4022-87e0-33a8c816f6bc", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.168856+00:00", "guest_name": "Cari Clifford", "rsvp_token": "byGS9giexpuIhfH27kX0yb/f", "guest_email": null, "guest_phone": "(402) 681-7443", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4026817443"}}	t	2026-06-22 03:16:54.168856+00
833710ad-e8b4-4484-8a1a-a1b41e415e1f	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	3b7252eb-41be-4ae6-adc5-992b8fbfbf4b	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "3b7252eb-41be-4ae6-adc5-992b8fbfbf4b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.315724+00:00", "guest_name": "GeGe Spradling", "rsvp_token": "IOnBurM485nO5B+qQ+r8amNT", "guest_email": null, "guest_phone": "(903) 573-0947", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "9035730947"}}	t	2026-06-22 03:16:54.315724+00
5ef825bb-283b-4bb6-abfa-94548e2eb89a	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	INSERT invitations	invitations	3b7252eb-41be-4ae6-adc5-992b8fbfbf4b	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "3b7252eb-41be-4ae6-adc5-992b8fbfbf4b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.315724+00:00", "guest_name": "GeGe Spradling", "rsvp_token": "IOnBurM485nO5B+qQ+r8amNT", "guest_email": null, "guest_phone": "(903) 573-0947", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "9035730947"}}	t	2026-06-22 03:16:54.315724+00
98e6733e-0ea9-4ced-9a8b-dceb252f96cd	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	3b7252eb-41be-4ae6-adc5-992b8fbfbf4b	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "3b7252eb-41be-4ae6-adc5-992b8fbfbf4b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.315724+00:00", "guest_name": "GeGe Spradling", "rsvp_token": "IOnBurM485nO5B+qQ+r8amNT", "guest_email": null, "guest_phone": "(903) 573-0947", "is_committee": false, "invite_sent_at": "2026-06-22T03:17:40.349+00:00", "guest_email_normalized": null, "guest_phone_normalized": "9035730947"}, "old": {"id": "3b7252eb-41be-4ae6-adc5-992b8fbfbf4b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.315724+00:00", "guest_name": "GeGe Spradling", "rsvp_token": "IOnBurM485nO5B+qQ+r8amNT", "guest_email": null, "guest_phone": "(903) 573-0947", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "9035730947"}}	t	2026-06-22 03:17:40.922902+00
204acc7a-8da8-42c0-a14e-a8261a95eda4	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	3b7252eb-41be-4ae6-adc5-992b8fbfbf4b	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.91 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "3b7252eb-41be-4ae6-adc5-992b8fbfbf4b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.315724+00:00", "guest_name": "GeGe Spradling", "rsvp_token": "IOnBurM485nO5B+qQ+r8amNT", "guest_email": null, "guest_phone": "(903) 573-0947", "is_committee": false, "invite_sent_at": "2026-06-22T03:17:40.349+00:00", "guest_email_normalized": null, "guest_phone_normalized": "9035730947"}, "old": {"id": "3b7252eb-41be-4ae6-adc5-992b8fbfbf4b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.315724+00:00", "guest_name": "GeGe Spradling", "rsvp_token": "IOnBurM485nO5B+qQ+r8amNT", "guest_email": null, "guest_phone": "(903) 573-0947", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "9035730947"}}	t	2026-06-22 03:17:40.922902+00
d0693682-5a6d-40a1-8352-797cc1363d69	\N	\N	\N	INSERT user_roles	user_roles	9eac0c4f-0f04-4385-b538-d1b9c1f00ecb	\N	\N	{"new": {"id": "9eac0c4f-0f04-4385-b538-d1b9c1f00ecb", "role": "host", "user_id": "ace15320-adf7-43f1-873c-3b86afea210e"}}	t	2026-06-22 10:15:04.490443+00
a7ac4873-8225-4880-8d8b-d0643e70ca88	\N	\N	\N	INSERT invitations	invitations	b57cc74c-8298-4f7c-9324-88f17b498626	2a06:98c0:3600::103	\N	{"new": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}}	t	2026-06-22 10:15:04.913092+00
197ab9ee-c0ff-472f-871d-bae031b4ef00	\N	\N	\N	UPDATE invitations	invitations	b57cc74c-8298-4f7c-9324-88f17b498626	2a06:98c0:3600::103	\N	{"new": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}, "old": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}}	t	2026-06-22 10:15:05.232866+00
73a1bcc9-f2fd-4f2c-b2d6-a57515e8d1a4	\N	\N	\N	UPDATE invitations	invitations	b57cc74c-8298-4f7c-9324-88f17b498626	2a06:98c0:3600::103	\N	{"new": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}, "old": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}}	t	2026-06-22 10:15:05.232866+00
88579d37-1e0d-407f-a54b-f017fd1d5e0f	\N	\N	\N	INSERT rsvps	rsvps	3724ef19-afeb-4a27-9511-90c673e90c46	2a06:98c0:3600::103	\N	{"new": {"id": "3724ef19-afeb-4a27-9511-90c673e90c46", "status": "yes", "message": null, "created_at": "2026-06-22T10:15:05.311914+00:00", "invited_by": "Jacquelyn Spears", "party_size": 1, "responded_at": "2026-06-22T10:15:05.271+00:00", "dietary_notes": null, "invitation_id": "b57cc74c-8298-4f7c-9324-88f17b498626", "ordering_food": null, "attendance_mode": "zoom"}}	t	2026-06-22 10:15:05.311914+00
e3689590-1097-41eb-816c-98ef95c8e1be	\N	\N	\N	INSERT rsvps	rsvps	3724ef19-afeb-4a27-9511-90c673e90c46	2a06:98c0:3600::103	\N	{"new": {"id": "3724ef19-afeb-4a27-9511-90c673e90c46", "status": "yes", "message": null, "created_at": "2026-06-22T10:15:05.311914+00:00", "invited_by": "Jacquelyn Spears", "party_size": 1, "responded_at": "2026-06-22T10:15:05.271+00:00", "dietary_notes": null, "invitation_id": "b57cc74c-8298-4f7c-9324-88f17b498626", "ordering_food": null, "attendance_mode": "zoom"}}	t	2026-06-22 10:15:05.311914+00
3bcb291d-1496-4f81-938e-f78406dcd155	\N	\N	\N	UPDATE invitations	invitations	b57cc74c-8298-4f7c-9324-88f17b498626	2a06:98c0:3600::103	\N	{"new": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}, "old": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}}	t	2026-06-22 10:15:18.162908+00
baa4cb81-ffe8-4605-9c65-3a124b7d62a8	\N	\N	\N	UPDATE invitations	invitations	b57cc74c-8298-4f7c-9324-88f17b498626	2a06:98c0:3600::103	\N	{"new": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}, "old": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}}	t	2026-06-22 10:15:18.162908+00
bbd6c924-7490-441a-b85b-cdc33d24dacd	\N	\N	\N	UPDATE rsvps	rsvps	3724ef19-afeb-4a27-9511-90c673e90c46	2a06:98c0:3600::103	\N	{"new": {"id": "3724ef19-afeb-4a27-9511-90c673e90c46", "status": "yes", "message": null, "created_at": "2026-06-22T10:15:05.311914+00:00", "invited_by": "Jacquelyn Spears", "party_size": 1, "responded_at": "2026-06-22T10:15:18.204+00:00", "dietary_notes": null, "invitation_id": "b57cc74c-8298-4f7c-9324-88f17b498626", "ordering_food": null, "attendance_mode": "zoom"}, "old": {"id": "3724ef19-afeb-4a27-9511-90c673e90c46", "status": "yes", "message": null, "created_at": "2026-06-22T10:15:05.311914+00:00", "invited_by": "Jacquelyn Spears", "party_size": 1, "responded_at": "2026-06-22T10:15:05.271+00:00", "dietary_notes": null, "invitation_id": "b57cc74c-8298-4f7c-9324-88f17b498626", "ordering_food": null, "attendance_mode": "zoom"}}	t	2026-06-22 10:15:18.247325+00
cbe49e94-8290-40f3-918d-8cced70796ea	\N	\N	\N	UPDATE rsvps	rsvps	3724ef19-afeb-4a27-9511-90c673e90c46	2a06:98c0:3600::103	\N	{"new": {"id": "3724ef19-afeb-4a27-9511-90c673e90c46", "status": "yes", "message": null, "created_at": "2026-06-22T10:15:05.311914+00:00", "invited_by": "Jacquelyn Spears", "party_size": 1, "responded_at": "2026-06-22T10:15:18.204+00:00", "dietary_notes": null, "invitation_id": "b57cc74c-8298-4f7c-9324-88f17b498626", "ordering_food": null, "attendance_mode": "zoom"}, "old": {"id": "3724ef19-afeb-4a27-9511-90c673e90c46", "status": "yes", "message": null, "created_at": "2026-06-22T10:15:05.311914+00:00", "invited_by": "Jacquelyn Spears", "party_size": 1, "responded_at": "2026-06-22T10:15:05.271+00:00", "dietary_notes": null, "invitation_id": "b57cc74c-8298-4f7c-9324-88f17b498626", "ordering_food": null, "attendance_mode": "zoom"}}	t	2026-06-22 10:15:18.247325+00
061e90eb-c135-43b3-bb9e-0b420307685c	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-22 23:01:02.028427+00
dcbf5e2f-3f65-4283-b09e-602a79767724	\N	\N	\N	UPDATE invitations	invitations	2d1f587c-26a7-4491-a2a0-cafce4556d7b	2a06:98c0:3600::103	\N	{"new": {"id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:27.490386+00:00", "guest_name": "Jay & Ronda Wilcher", "rsvp_token": "ushuC9myESKB6C5zFgKxcafk", "guest_email": null, "guest_phone": "4028508379", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:24.244+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028508379"}, "old": {"id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:27.490386+00:00", "guest_name": "Jay Wilcher", "rsvp_token": "ushuC9myESKB6C5zFgKxcafk", "guest_email": null, "guest_phone": "(402) 850-8379", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:24.244+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028508379"}}	t	2026-06-23 03:36:58.794311+00
9d93a262-62ae-45ce-bfcb-066358e4db66	\N	\N	\N	UPDATE invitations	invitations	2d1f587c-26a7-4491-a2a0-cafce4556d7b	2a06:98c0:3600::103	\N	{"new": {"id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:27.490386+00:00", "guest_name": "Jay & Ronda Wilcher", "rsvp_token": "ushuC9myESKB6C5zFgKxcafk", "guest_email": null, "guest_phone": "4028508379", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:24.244+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028508379"}, "old": {"id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-26T18:57:27.490386+00:00", "guest_name": "Jay Wilcher", "rsvp_token": "ushuC9myESKB6C5zFgKxcafk", "guest_email": null, "guest_phone": "(402) 850-8379", "is_committee": true, "invite_sent_at": "2026-06-03T06:25:24.244+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028508379"}}	t	2026-06-23 03:36:58.794311+00
03b006aa-ea88-4fd6-a728-08a830acfdd4	\N	\N	\N	INSERT rsvps	rsvps	42e60333-e354-4949-b5a7-0be39f74872d	2a06:98c0:3600::103	\N	{"new": {"id": "42e60333-e354-4949-b5a7-0be39f74872d", "status": "yes", "message": null, "created_at": "2026-06-23T03:36:58.916295+00:00", "invited_by": "Jay Wilcher", "party_size": 2, "responded_at": "2026-06-23T03:36:58.892+00:00", "dietary_notes": null, "invitation_id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "ordering_food": false, "attendance_mode": "in_person"}}	t	2026-06-23 03:36:58.916295+00
749b79db-2b82-49f3-a0a5-3fcfb8877371	\N	\N	\N	INSERT rsvps	rsvps	42e60333-e354-4949-b5a7-0be39f74872d	2a06:98c0:3600::103	\N	{"new": {"id": "42e60333-e354-4949-b5a7-0be39f74872d", "status": "yes", "message": null, "created_at": "2026-06-23T03:36:58.916295+00:00", "invited_by": "Jay Wilcher", "party_size": 2, "responded_at": "2026-06-23T03:36:58.892+00:00", "dietary_notes": null, "invitation_id": "2d1f587c-26a7-4491-a2a0-cafce4556d7b", "ordering_food": false, "attendance_mode": "in_person"}}	t	2026-06-23 03:36:58.916295+00
bd7fa1cf-7b1a-4c21-8886-4f505f7830b1	\N	18082787562	Gray	auth.login.failure	auth	\N	173.213.155.220	Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-23 16:44:45.796624+00
722e5740-d451-40b6-9ee2-cb3473b42ae8	\N	4022136518	Sallis	auth.login.failure	auth	\N	172.56.131.38	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-26 03:49:34.8375+00
beb9185b-dd8f-4a66-9fc1-affb7235d0ba	\N	4022136518	Sallis	auth.login.failure	auth	\N	172.56.131.38	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-26 03:50:11.226619+00
ee53b040-95de-4b4d-90ac-87d9ad3acf4b	\N	4022136518	Sallis	auth.login.failure	auth	\N	172.56.131.38	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	{"reason": "phone_not_on_list"}	f	2026-06-26 03:51:59.489192+00
677d4bfa-595d-4ca4-8453-1259981975d9	\N	\N	\N	INSERT user_roles	user_roles	3dcbda6a-080f-4712-9f3a-cd0e545e2b16	\N	\N	{"new": {"id": "3dcbda6a-080f-4712-9f3a-cd0e545e2b16", "role": "host", "user_id": "c35729d1-326d-43bc-a66b-c0d3bde91cf0"}}	t	2026-06-26 04:21:36.559728+00
53371a2e-7cc3-49fc-b19f-a86105d26ba0	\N	\N	\N	UPDATE invitations	invitations	5caa4514-9306-40de-bb6e-424cfcae0e4e	2a06:98c0:3600::103	\N	{"new": {"id": "5caa4514-9306-40de-bb6e-424cfcae0e4e", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.348336+00:00", "guest_name": "Dee Sallis", "rsvp_token": "MtzyWjqwBxOwxujSSBipym66", "guest_email": null, "guest_phone": "4022136518", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:18.013+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4022136518"}, "old": {"id": "5caa4514-9306-40de-bb6e-424cfcae0e4e", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.348336+00:00", "guest_name": "Dewinica Salis", "rsvp_token": "MtzyWjqwBxOwxujSSBipym66", "guest_email": null, "guest_phone": "+1 402-213-6518", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:18.013+00:00", "guest_email_normalized": null, "guest_phone_normalized": "14022136518"}}	t	2026-06-26 04:21:37.523785+00
85278f00-151f-4b64-9d87-5fcf029d1bf4	\N	\N	\N	UPDATE invitations	invitations	5caa4514-9306-40de-bb6e-424cfcae0e4e	2a06:98c0:3600::103	\N	{"new": {"id": "5caa4514-9306-40de-bb6e-424cfcae0e4e", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.348336+00:00", "guest_name": "Dee Sallis", "rsvp_token": "MtzyWjqwBxOwxujSSBipym66", "guest_email": null, "guest_phone": "4022136518", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:18.013+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4022136518"}, "old": {"id": "5caa4514-9306-40de-bb6e-424cfcae0e4e", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.348336+00:00", "guest_name": "Dewinica Salis", "rsvp_token": "MtzyWjqwBxOwxujSSBipym66", "guest_email": null, "guest_phone": "+1 402-213-6518", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:18.013+00:00", "guest_email_normalized": null, "guest_phone_normalized": "14022136518"}}	t	2026-06-26 04:21:37.523785+00
bb98654e-32ff-496d-8103-c2830029bd40	\N	\N	\N	INSERT rsvps	rsvps	26cbe26b-8e5a-497c-b6cf-b13cec58a104	2a06:98c0:3600::103	\N	{"new": {"id": "26cbe26b-8e5a-497c-b6cf-b13cec58a104", "status": "yes", "message": null, "created_at": "2026-06-26T04:21:37.618174+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-26T04:21:37.596+00:00", "dietary_notes": null, "invitation_id": "5caa4514-9306-40de-bb6e-424cfcae0e4e", "ordering_food": true, "attendance_mode": "in_person"}}	t	2026-06-26 04:21:37.618174+00
662e9eb7-69e9-4fef-b363-36610090ee1e	\N	\N	\N	INSERT rsvps	rsvps	26cbe26b-8e5a-497c-b6cf-b13cec58a104	2a06:98c0:3600::103	\N	{"new": {"id": "26cbe26b-8e5a-497c-b6cf-b13cec58a104", "status": "yes", "message": null, "created_at": "2026-06-26T04:21:37.618174+00:00", "invited_by": "Kari Gray", "party_size": 1, "responded_at": "2026-06-26T04:21:37.596+00:00", "dietary_notes": null, "invitation_id": "5caa4514-9306-40de-bb6e-424cfcae0e4e", "ordering_food": true, "attendance_mode": "in_person"}}	t	2026-06-26 04:21:37.618174+00
68f9ba35-1383-4126-91d0-7d7f80f03532	\N	\N	\N	INSERT cuisine_preorders	cuisine_preorders	c81fbcb8-1a50-4eb3-9e6d-b2b8e18791da	2a06:98c0:3600::103	\N	{"new": {"id": "c81fbcb8-1a50-4eb3-9e6d-b2b8e18791da", "name": "Dee Sallis", "phone": "4022136518", "created_at": "2026-06-26T04:21:37.677534+00:00", "selections": [{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "African"}, {"qty": 1, "cuisine": "Indonesian"}], "updated_at": "2026-06-26T04:21:37.677534+00:00", "invitation_id": "5caa4514-9306-40de-bb6e-424cfcae0e4e"}}	t	2026-06-26 04:21:37.677534+00
a53fe972-3f6a-41f2-b516-d284efafa441	\N	\N	\N	INSERT cuisine_preorders	cuisine_preorders	c81fbcb8-1a50-4eb3-9e6d-b2b8e18791da	2a06:98c0:3600::103	\N	{"new": {"id": "c81fbcb8-1a50-4eb3-9e6d-b2b8e18791da", "name": "Dee Sallis", "phone": "4022136518", "created_at": "2026-06-26T04:21:37.677534+00:00", "selections": [{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "African"}, {"qty": 1, "cuisine": "Indonesian"}], "updated_at": "2026-06-26T04:21:37.677534+00:00", "invitation_id": "5caa4514-9306-40de-bb6e-424cfcae0e4e"}}	t	2026-06-26 04:21:37.677534+00
73746dd1-8a97-453d-9b18-fa71eda9bb0b	\N	\N	\N	INSERT user_roles	user_roles	2ec4066e-de39-4239-b480-d8579b8eec2c	2a06:98c0:3600::103	\N	{"new": {"id": "2ec4066e-de39-4239-b480-d8579b8eec2c", "role": "team", "user_id": "c35729d1-326d-43bc-a66b-c0d3bde91cf0"}}	t	2026-06-26 04:22:22.624096+00
453ae396-84c6-45e9-97b5-a6e456e5b48e	c35729d1-326d-43bc-a66b-c0d3bde91cf0	4022136518	Dee Sallis	auth.login.success	auth	\N	172.56.131.48	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	{}	t	2026-06-26 04:22:22.94144+00
8b75b80c-fc0f-41b8-babd-c8caf8ba3e89	c35729d1-326d-43bc-a66b-c0d3bde91cf0	14022136518	Dee Sallis	INSERT category_assignments	category_assignments	bcbaadaf-8141-43bd-a5ae-49007ad5423f	172.56.131.48	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	{"new": {"id": "bcbaadaf-8141-43bd-a5ae-49007ad5423f", "notes": null, "user_id": "c35729d1-326d-43bc-a66b-c0d3bde91cf0", "created_at": "2026-06-26T04:24:35.145986+00:00", "category_id": "851482e6-4274-4190-8572-cd819f8cd9e4", "volunteer_name": null}}	t	2026-06-26 04:24:35.145986+00
dbf02f4e-80df-4293-9872-514793092955	c35729d1-326d-43bc-a66b-c0d3bde91cf0	14022136518	Dee Sallis	INSERT category_assignments	category_assignments	bc22b2a5-6246-4b52-b663-60af8551828b	172.56.131.48	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	{"new": {"id": "bc22b2a5-6246-4b52-b663-60af8551828b", "notes": null, "user_id": "c35729d1-326d-43bc-a66b-c0d3bde91cf0", "created_at": "2026-06-26T04:24:53.742275+00:00", "category_id": "e445ad55-f516-4948-80c1-b439869ce84e", "volunteer_name": null}}	t	2026-06-26 04:24:53.742275+00
b5ce2846-5927-4916-bacd-679a24e14db9	c35729d1-326d-43bc-a66b-c0d3bde91cf0	14022136518	Dee Sallis	INSERT category_assignments	category_assignments	372b67ea-032a-451e-8524-bd16c64f5919	172.56.131.48	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	{"new": {"id": "372b67ea-032a-451e-8524-bd16c64f5919", "notes": null, "user_id": "c35729d1-326d-43bc-a66b-c0d3bde91cf0", "created_at": "2026-06-26T04:27:27.006418+00:00", "category_id": "208816b5-3b82-4815-ba90-b47e1dd9c91d", "volunteer_name": null}}	t	2026-06-26 04:27:27.006418+00
bfeab2f7-2d5b-40be-b7a8-892d98b6201a	\N	\N	\N	INSERT user_roles	user_roles	6552b927-91cd-4520-bd7e-47638a48c143	\N	\N	{"new": {"id": "6552b927-91cd-4520-bd7e-47638a48c143", "role": "host", "user_id": "c734fcf2-254a-4d9f-a8bd-7a6b04858af4"}}	t	2026-06-26 16:22:18.561995+00
cd192de3-2846-498a-bef7-21c12fcce6c0	c734fcf2-254a-4d9f-a8bd-7a6b04858af4	4027406722	Robn Droz	auth.login.success	auth	\N	174.71.93.137	Mozilla/5.0 (iPhone; CPU iPhone OS 15_8_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.8 Mobile/15E148 Safari/604.1	{}	t	2026-06-26 16:22:19.095423+00
5af7d846-7d40-44f5-822c-270405389403	\N	\N	\N	INSERT invitations	invitations	3bba124a-7497-4a69-87b3-cbacf527f9e6	2a06:98c0:3600::103	\N	{"new": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "402740672"}}	t	2026-06-26 17:34:49.342901+00
fc8bb794-cbe4-47a2-a3f6-2209cda45d04	\N	\N	\N	INSERT invitations	invitations	3bba124a-7497-4a69-87b3-cbacf527f9e6	2a06:98c0:3600::103	\N	{"new": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "402740672"}}	t	2026-06-26 17:34:49.342901+00
b641d9b2-a881-40ec-8fa9-1e321f24c84c	\N	\N	\N	UPDATE invitations	invitations	3bba124a-7497-4a69-87b3-cbacf527f9e6	2a06:98c0:3600::103	\N	{"new": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "402740672"}, "old": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "402740672"}}	t	2026-06-26 17:34:49.643401+00
9a08e5e6-2e59-4dbf-ba24-f0b4e99169bd	\N	\N	\N	UPDATE invitations	invitations	3bba124a-7497-4a69-87b3-cbacf527f9e6	2a06:98c0:3600::103	\N	{"new": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "402740672"}, "old": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "402740672"}}	t	2026-06-26 17:34:49.643401+00
6046bf28-8b54-4c21-b2cf-ea9c3e901f47	\N	\N	\N	INSERT rsvps	rsvps	b07d054a-fe9c-47f7-9a57-2f1f57fd21dc	2a06:98c0:3600::103	\N	{"new": {"id": "b07d054a-fe9c-47f7-9a57-2f1f57fd21dc", "status": "no", "message": null, "created_at": "2026-06-26T17:34:49.771317+00:00", "invited_by": "Kari Gray", "party_size": 2, "responded_at": "2026-06-26T17:34:49.704+00:00", "dietary_notes": null, "invitation_id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "ordering_food": null, "attendance_mode": "in_person"}}	t	2026-06-26 17:34:49.771317+00
82126417-2b4e-4d9b-b633-23e58eef6b75	\N	\N	\N	UPDATE invitations	invitations	2bf8fce4-c2d3-4152-904d-9dc2e820d412	2a06:98c0:3600::103	\N	{"new": {"id": "2bf8fce4-c2d3-4152-904d-9dc2e820d412", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:33.958688+00:00", "guest_name": "Adrianna Marie Gonzalez", "rsvp_token": "etSmUCSv+izal0ec9PHljg7Q", "guest_email": null, "guest_phone": "4028076980", "is_committee": false, "invite_sent_at": "2026-06-08T13:58:52.118+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028076980"}, "old": {"id": "2bf8fce4-c2d3-4152-904d-9dc2e820d412", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:33.958688+00:00", "guest_name": "Adriana Gonzalez", "rsvp_token": "etSmUCSv+izal0ec9PHljg7Q", "guest_email": null, "guest_phone": "402-807-6980", "is_committee": false, "invite_sent_at": "2026-06-08T13:58:52.118+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028076980"}}	t	2026-06-26 23:57:09.086559+00
bce6c259-dc72-47d1-ae3e-e184fdb4ecb1	\N	\N	\N	UPDATE invitations	invitations	2bf8fce4-c2d3-4152-904d-9dc2e820d412	2a06:98c0:3600::103	\N	{"new": {"id": "2bf8fce4-c2d3-4152-904d-9dc2e820d412", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:33.958688+00:00", "guest_name": "Adrianna Marie Gonzalez", "rsvp_token": "etSmUCSv+izal0ec9PHljg7Q", "guest_email": null, "guest_phone": "4028076980", "is_committee": false, "invite_sent_at": "2026-06-08T13:58:52.118+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028076980"}, "old": {"id": "2bf8fce4-c2d3-4152-904d-9dc2e820d412", "notes": null, "host_id": "e7619554-8bc3-4576-916d-2d46229702f4", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-08T02:36:33.958688+00:00", "guest_name": "Adriana Gonzalez", "rsvp_token": "etSmUCSv+izal0ec9PHljg7Q", "guest_email": null, "guest_phone": "402-807-6980", "is_committee": false, "invite_sent_at": "2026-06-08T13:58:52.118+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4028076980"}}	t	2026-06-26 23:57:09.086559+00
6e2d036f-4761-48dd-9f53-b1e8b2432ffb	\N	\N	\N	INSERT rsvps	rsvps	e3708336-2f79-4c5f-a982-a66015647ca4	2a06:98c0:3600::103	\N	{"new": {"id": "e3708336-2f79-4c5f-a982-a66015647ca4", "status": "yes", "message": null, "created_at": "2026-06-26T23:57:09.194132+00:00", "invited_by": "Betsaida Ruiz", "party_size": 2, "responded_at": "2026-06-26T23:57:09.158+00:00", "dietary_notes": null, "invitation_id": "2bf8fce4-c2d3-4152-904d-9dc2e820d412", "ordering_food": true, "attendance_mode": "in_person"}}	t	2026-06-26 23:57:09.194132+00
d98fe873-9670-4653-acd7-0b0639cbbfec	\N	\N	\N	INSERT rsvps	rsvps	e3708336-2f79-4c5f-a982-a66015647ca4	2a06:98c0:3600::103	\N	{"new": {"id": "e3708336-2f79-4c5f-a982-a66015647ca4", "status": "yes", "message": null, "created_at": "2026-06-26T23:57:09.194132+00:00", "invited_by": "Betsaida Ruiz", "party_size": 2, "responded_at": "2026-06-26T23:57:09.158+00:00", "dietary_notes": null, "invitation_id": "2bf8fce4-c2d3-4152-904d-9dc2e820d412", "ordering_food": true, "attendance_mode": "in_person"}}	t	2026-06-26 23:57:09.194132+00
c62aa60a-5152-4dea-a095-7e5036b194c3	\N	\N	\N	INSERT cuisine_preorders	cuisine_preorders	8cf2efc1-36af-423f-8a01-8e18e23a627b	2a06:98c0:3600::103	\N	{"new": {"id": "8cf2efc1-36af-423f-8a01-8e18e23a627b", "name": "Adrianna Marie Gonzalez", "phone": "4028076980", "created_at": "2026-06-26T23:57:09.277898+00:00", "selections": [{"qty": 1, "cuisine": "Indonesian"}, {"qty": 1, "cuisine": "Myanmar"}], "updated_at": "2026-06-26T23:57:09.277898+00:00", "invitation_id": "2bf8fce4-c2d3-4152-904d-9dc2e820d412"}}	t	2026-06-26 23:57:09.277898+00
f0910aed-37bf-4bd9-b668-6f7dc2423d78	\N	\N	\N	INSERT cuisine_preorders	cuisine_preorders	8cf2efc1-36af-423f-8a01-8e18e23a627b	2a06:98c0:3600::103	\N	{"new": {"id": "8cf2efc1-36af-423f-8a01-8e18e23a627b", "name": "Adrianna Marie Gonzalez", "phone": "4028076980", "created_at": "2026-06-26T23:57:09.277898+00:00", "selections": [{"qty": 1, "cuisine": "Indonesian"}, {"qty": 1, "cuisine": "Myanmar"}], "updated_at": "2026-06-26T23:57:09.277898+00:00", "invitation_id": "2bf8fce4-c2d3-4152-904d-9dc2e820d412"}}	t	2026-06-26 23:57:09.277898+00
e3711841-3306-4020-81fd-12f5b47810e9	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	auth.login.success	auth	\N	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{}	t	2026-06-27 00:02:12.443143+00
d20a78c0-2df0-427d-baf6-799b53cf5a9f	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	d6cb152b-d5c2-4207-aa31-66ea08655620	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": "2026-06-27T00:53:38.978+00:00", "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}, "old": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}}	t	2026-06-27 00:53:39.703534+00
36b5b9c4-9a71-4ef1-94e4-8c1a436cb75a	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	d6cb152b-d5c2-4207-aa31-66ea08655620	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": "2026-06-27T00:53:38.978+00:00", "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}, "old": {"id": "d6cb152b-d5c2-4207-aa31-66ea08655620", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-16T21:24:53.31544+00:00", "guest_name": "Cynthia Futo", "rsvp_token": "eXtnNHWHPDCLuKF4AEWB0269", "guest_email": null, "guest_phone": "3146406836", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3146406836"}}	t	2026-06-27 00:53:39.703534+00
be980851-b2cd-41c0-9bdf-33095164d18a	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	b57cc74c-8298-4f7c-9324-88f17b498626	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": "2026-06-27T00:53:49.224+00:00", "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}, "old": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}}	t	2026-06-27 00:53:49.573444+00
7231c22b-bffe-4e47-b98c-92c98b71d161	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	b57cc74c-8298-4f7c-9324-88f17b498626	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": "2026-06-27T00:53:49.224+00:00", "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}, "old": {"id": "b57cc74c-8298-4f7c-9324-88f17b498626", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T10:15:04.913092+00:00", "guest_name": "Lenora Clark", "rsvp_token": "pFQPFhTQ9vu7eFwe0BTua9Xk", "guest_email": null, "guest_phone": "3144201702", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3144201702"}}	t	2026-06-27 00:53:49.573444+00
a1ed2158-cdc5-49bf-b8ec-0423ae2d90cd	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	3bba124a-7497-4a69-87b3-cbacf527f9e6	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": "2026-06-27T00:54:27.491+00:00", "guest_email_normalized": null, "guest_phone_normalized": "402740672"}, "old": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "402740672"}}	t	2026-06-27 00:54:27.829915+00
280e5887-1c2b-412e-90d6-742041acdb4b	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	3bba124a-7497-4a69-87b3-cbacf527f9e6	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": "2026-06-27T00:54:27.491+00:00", "guest_email_normalized": null, "guest_phone_normalized": "402740672"}, "old": {"id": "3bba124a-7497-4a69-87b3-cbacf527f9e6", "notes": null, "host_id": "c3160a24-000a-46b0-811b-ffe22e265981", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-26T17:34:49.342901+00:00", "guest_name": "Robin Droz", "rsvp_token": "Y16r4VInmp1rDU8cLdnWQGMg", "guest_email": null, "guest_phone": "402740672", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "402740672"}}	t	2026-06-27 00:54:27.829915+00
95149356-ec06-48ee-850e-290f41285498	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	0f1d067f-c2dc-410e-910b-d9791bad9303	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"old": {"id": "0f1d067f-c2dc-410e-910b-d9791bad9303", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.456448+00:00", "guest_name": "1 other person", "rsvp_token": "SOMHhczIjRi4AYdJfvl/mpcG", "guest_email": null, "guest_phone": null, "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": ""}}	t	2026-06-27 00:54:43.147279+00
f5d533d8-6306-453e-baf1-7e134a10cd27	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	DELETE invitations	invitations	0f1d067f-c2dc-410e-910b-d9791bad9303	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"old": {"id": "0f1d067f-c2dc-410e-910b-d9791bad9303", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.456448+00:00", "guest_name": "1 other person", "rsvp_token": "SOMHhczIjRi4AYdJfvl/mpcG", "guest_email": null, "guest_phone": null, "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": ""}}	t	2026-06-27 00:54:43.147279+00
b3d94452-8c3d-4f4d-ba79-be21437b3987	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	729998ad-4b8a-403d-9ab4-444f5bead9c2	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "729998ad-4b8a-403d-9ab4-444f5bead9c2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.119032+00:00", "guest_name": "BW Sister Rodriguez", "rsvp_token": "nEsyHJyI/ZXFXGa2QpqwhL2B", "guest_email": null, "guest_phone": "(402) 973-8878", "is_committee": false, "invite_sent_at": "2026-06-27T00:55:04.393+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029738878"}, "old": {"id": "729998ad-4b8a-403d-9ab4-444f5bead9c2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.119032+00:00", "guest_name": "BW Sister Rodriguez", "rsvp_token": "nEsyHJyI/ZXFXGa2QpqwhL2B", "guest_email": null, "guest_phone": "(402) 973-8878", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029738878"}}	t	2026-06-27 00:55:04.700195+00
3925c527-e59b-4d7d-8415-4de3511f3ce7	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	729998ad-4b8a-403d-9ab4-444f5bead9c2	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "729998ad-4b8a-403d-9ab4-444f5bead9c2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.119032+00:00", "guest_name": "BW Sister Rodriguez", "rsvp_token": "nEsyHJyI/ZXFXGa2QpqwhL2B", "guest_email": null, "guest_phone": "(402) 973-8878", "is_committee": false, "invite_sent_at": "2026-06-27T00:55:04.393+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4029738878"}, "old": {"id": "729998ad-4b8a-403d-9ab4-444f5bead9c2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.119032+00:00", "guest_name": "BW Sister Rodriguez", "rsvp_token": "nEsyHJyI/ZXFXGa2QpqwhL2B", "guest_email": null, "guest_phone": "(402) 973-8878", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4029738878"}}	t	2026-06-27 00:55:04.700195+00
08979733-2446-4ca0-84a1-5b903f81e6e5	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	7d18e116-f92e-4971-8af4-199de909e009	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "7d18e116-f92e-4971-8af4-199de909e009", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T07:47:36.85646+00:00", "guest_name": "Caleb Morgan", "rsvp_token": "i43dyzDD6e9EAw/awRQdEO/l", "guest_email": null, "guest_phone": "(402) 618-9036", "is_committee": false, "invite_sent_at": "2026-06-03T07:59:22.766+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026189036"}, "old": {"id": "7d18e116-f92e-4971-8af4-199de909e009", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T07:47:36.85646+00:00", "guest_name": "Caleb Morgan", "rsvp_token": "i43dyzDD6e9EAw/awRQdEO/l", "guest_email": null, "guest_phone": "(402) 618-9036", "is_committee": false, "invite_sent_at": "2026-06-03T07:59:22.766+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026189036"}}	t	2026-06-27 00:55:04.697257+00
71ea9c5c-06e6-47af-b5df-db9ca0e8a247	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	7d18e116-f92e-4971-8af4-199de909e009	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "7d18e116-f92e-4971-8af4-199de909e009", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T07:47:36.85646+00:00", "guest_name": "Caleb Morgan", "rsvp_token": "i43dyzDD6e9EAw/awRQdEO/l", "guest_email": null, "guest_phone": "(402) 618-9036", "is_committee": false, "invite_sent_at": "2026-06-03T07:59:22.766+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026189036"}, "old": {"id": "7d18e116-f92e-4971-8af4-199de909e009", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-03T07:47:36.85646+00:00", "guest_name": "Caleb Morgan", "rsvp_token": "i43dyzDD6e9EAw/awRQdEO/l", "guest_email": null, "guest_phone": "(402) 618-9036", "is_committee": false, "invite_sent_at": "2026-06-03T07:59:22.766+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026189036"}}	t	2026-06-27 00:55:04.697257+00
f5963e33-5895-4db2-b8f3-3ac5f468e73d	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	e224d5be-5bd2-4022-87e0-33a8c816f6bc	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "e224d5be-5bd2-4022-87e0-33a8c816f6bc", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.168856+00:00", "guest_name": "Cari Clifford", "rsvp_token": "byGS9giexpuIhfH27kX0yb/f", "guest_email": null, "guest_phone": "(402) 681-7443", "is_committee": false, "invite_sent_at": "2026-06-27T00:55:14.118+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026817443"}, "old": {"id": "e224d5be-5bd2-4022-87e0-33a8c816f6bc", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.168856+00:00", "guest_name": "Cari Clifford", "rsvp_token": "byGS9giexpuIhfH27kX0yb/f", "guest_email": null, "guest_phone": "(402) 681-7443", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4026817443"}}	t	2026-06-27 00:55:14.469331+00
64fef3f4-049b-41d8-b20c-33a9fda66720	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	e224d5be-5bd2-4022-87e0-33a8c816f6bc	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "e224d5be-5bd2-4022-87e0-33a8c816f6bc", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.168856+00:00", "guest_name": "Cari Clifford", "rsvp_token": "byGS9giexpuIhfH27kX0yb/f", "guest_email": null, "guest_phone": "(402) 681-7443", "is_committee": false, "invite_sent_at": "2026-06-27T00:55:14.118+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4026817443"}, "old": {"id": "e224d5be-5bd2-4022-87e0-33a8c816f6bc", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:54.168856+00:00", "guest_name": "Cari Clifford", "rsvp_token": "byGS9giexpuIhfH27kX0yb/f", "guest_email": null, "guest_phone": "(402) 681-7443", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4026817443"}}	t	2026-06-27 00:55:14.469331+00
263843cd-14e3-4ae6-8101-6a5636cf08c2	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	bce49578-39a8-4b6a-9be3-a70703b03350	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "bce49578-39a8-4b6a-9be3-a70703b03350", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:53.899936+00:00", "guest_name": "Deisy Baker", "rsvp_token": "qgLL+8TJdpkCwzJOaL7RZwWG", "guest_email": null, "guest_phone": "(310) 619-3331", "is_committee": false, "invite_sent_at": "2026-06-27T00:55:25.833+00:00", "guest_email_normalized": null, "guest_phone_normalized": "3106193331"}, "old": {"id": "bce49578-39a8-4b6a-9be3-a70703b03350", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:53.899936+00:00", "guest_name": "Deisy Baker", "rsvp_token": "qgLL+8TJdpkCwzJOaL7RZwWG", "guest_email": null, "guest_phone": "(310) 619-3331", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3106193331"}}	t	2026-06-27 00:55:26.157143+00
192c7fba-caeb-423b-9806-8af6b00c96c4	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	bce49578-39a8-4b6a-9be3-a70703b03350	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "bce49578-39a8-4b6a-9be3-a70703b03350", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:53.899936+00:00", "guest_name": "Deisy Baker", "rsvp_token": "qgLL+8TJdpkCwzJOaL7RZwWG", "guest_email": null, "guest_phone": "(310) 619-3331", "is_committee": false, "invite_sent_at": "2026-06-27T00:55:25.833+00:00", "guest_email_normalized": null, "guest_phone_normalized": "3106193331"}, "old": {"id": "bce49578-39a8-4b6a-9be3-a70703b03350", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:16:53.899936+00:00", "guest_name": "Deisy Baker", "rsvp_token": "qgLL+8TJdpkCwzJOaL7RZwWG", "guest_email": null, "guest_phone": "(310) 619-3331", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3106193331"}}	t	2026-06-27 00:55:26.157143+00
51347f40-50e8-4772-bab0-4cbfb1f0eb6d	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	0eb32b2d-6b36-415e-b348-c9a3e2bc7866	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "0eb32b2d-6b36-415e-b348-c9a3e2bc7866", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T19:32:04.852153+00:00", "guest_name": "NE Teri Crohn", "rsvp_token": "bwK6IbKteU/utf8UHs2nsppe", "guest_email": null, "guest_phone": "(402) 738-0706", "is_committee": false, "invite_sent_at": "2026-06-27T00:56:22.869+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4027380706"}, "old": {"id": "0eb32b2d-6b36-415e-b348-c9a3e2bc7866", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T19:32:04.852153+00:00", "guest_name": "NE Teri Crohn", "rsvp_token": "bwK6IbKteU/utf8UHs2nsppe", "guest_email": null, "guest_phone": "(402) 738-0706", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4027380706"}}	t	2026-06-27 00:56:23.193924+00
f5e3b2c4-6807-45e0-907f-c9c3a5b99ce2	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	UPDATE invitations	invitations	0eb32b2d-6b36-415e-b348-c9a3e2bc7866	173.213.155.220	Mozilla/5.0 (Linux; Android 16; SM-S938U Build/BP4A.251205.006; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/149.0.7827.93 Mobile Safari/537.36 LovableApp/1.0.9	{"new": {"id": "0eb32b2d-6b36-415e-b348-c9a3e2bc7866", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T19:32:04.852153+00:00", "guest_name": "NE Teri Crohn", "rsvp_token": "bwK6IbKteU/utf8UHs2nsppe", "guest_email": null, "guest_phone": "(402) 738-0706", "is_committee": false, "invite_sent_at": "2026-06-27T00:56:22.869+00:00", "guest_email_normalized": null, "guest_phone_normalized": "4027380706"}, "old": {"id": "0eb32b2d-6b36-415e-b348-c9a3e2bc7866", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T19:32:04.852153+00:00", "guest_name": "NE Teri Crohn", "rsvp_token": "bwK6IbKteU/utf8UHs2nsppe", "guest_email": null, "guest_phone": "(402) 738-0706", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4027380706"}}	t	2026-06-27 00:56:23.193924+00
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."categories" ("id", "name", "sort_order", "created_at", "description") FROM stdin;
3dae77d0-57c0-47e3-b6d7-f0988ee69bfc	Alcohol Attendant	0	2026-05-26 02:55:21.682209+00	This includes ensuring the event is dignified and alcohol is limited to those of legal age and limit intake to 2 drinks.
308acecf-a9cb-48ca-92d7-80c211cbfd27	Entertainment	10	2026-05-15 22:24:49.393558+00	This role decides after reviewingsubmitted videos, the appropriate entertainement for the event.
620bdb1e-63ca-4bd3-9efb-f701f8b3eddb	Security	20	2026-05-15 22:24:49.393558+00	To ensure the safety of all, this role is for brothers to be at the entrance, and stop any without an RSVP from entering.
9e8da7e7-3371-4b42-b3f0-a48e341e3275	Catered Food	80	2026-05-15 22:24:49.393558+00	We want to try the resturants before we cater. If you want to be a taster, sign up below.
5017c27e-a693-45d3-b2dd-3f5f3f4365f1	Video Creation - Myanmar	41	2026-05-27 07:51:56.242409+00	If video editing and creating is your skill, be sure to volunteer.
9993301b-29ad-44a9-a4bc-3379f6987f5c	Video Creation - Mozambique (Africa)	42	2026-05-27 07:51:56.242409+00	If video editing and creating is your skill, be sure to volunteer.
7b9560c3-fc17-48a9-a9b8-45bf115e4d54	Director of the Feast	100	2026-05-15 22:24:49.393558+00	Seeking a bother to oversee the festivites at the event.
3acafbf8-9f99-40fe-a1d1-01c7fa7190db	Video Creation - Indonesia	43	2026-05-27 07:51:56.242409+00	If video editing and creating is your skill, be sure to volunteer.
52ae24cd-5cb4-49af-8819-a219a41bf851	Video Creation - New Zealand	44	2026-05-27 07:51:56.242409+00	If video editing and creating is your skill, be sure to volunteer.
e445ad55-f516-4948-80c1-b439869ce84e	Decoration	53	2026-05-24 19:08:31.979808+00	We will need help the day of the event darkening the windows with black plastic and depending on the donations, we may have small decorations as well.
cc6467d2-cdc0-4c4f-8b03-f59f2c93f932	Video projector - video equipment	52	2026-05-24 14:01:50.157439+00	We need video projectors and screens. If you have such, please text Kari Gray at 808.278.7562
679bc2f3-297d-43bc-8929-98a2d663dfe8	Set Up	110	2026-05-15 22:24:49.393558+00	We will need help the day of the event darkening the windows with black plastic.
167c811c-f486-479c-b09f-f9faae8a0843	Graphic artist	54	2026-05-24 19:08:31.979808+00	If you are a graphic artist, we have a Canva account to do design of the photo booth and the bags that all attendees receive on arriving.
8c72b229-a093-4670-96d7-632b861a6ff3	Videographer	55	2026-05-26 03:03:10.968142+00	We need someone with an Ipad to manage the video camera called a MeVo which provides multiple camera angles for the virtual attendees.
f660b181-56b8-4d3a-a5ed-f28dc2d74eb6	Clean Up	120	2026-05-15 22:24:49.393558+00	Ensuring the facilty owner and staff have a good witness by returning the building in a cleaned condition is important after the event.
e2ecdfac-1bfe-42c1-bf8b-4d7a2641225f	Parking Attendants	60	2026-05-15 22:24:49.393558+00	We will need help with parking to ensure all can come and go safetly.
851482e6-4274-4190-8572-cd819f8cd9e4	Food Servers	70	2026-05-15 22:24:49.393558+00	We need attendents to ensure the food area is kept clean and organized at the event, and trash is picked up and trash is removed when cans are full.
9d048792-52d7-4423-8564-4617858676a9	Donations	130	2026-05-15 22:24:49.393558+00	Any who want to donate to the event, can contact Kari Gray at 808.278.7562.
0502cd04-3d0a-4eda-aca8-95a37cbe2fee	MC	140	2026-05-15 22:24:49.393558+00	This role is for one or two friends to guide the evening festivities.
91c7ba53-f259-494a-b8be-5ac6904f3f55	AI Invitations	170	2026-05-15 22:24:49.393558+00	If tech is your genious, please sign up.
92886527-c0af-4a33-a1fd-74194e12c688	Zoom - Meetn attendant	180	2026-05-23 17:03:14.128354+00	We will have a virtual attendees and we need to ensure they are connected.
208816b5-3b82-4815-ba90-b47e1dd9c91d	Welcoming Committee	190	2026-05-24 23:10:54.565964+00	We need as many as possible be part of the Welcoming Committee to ensure when our brothers and sisters arrive, they feel exceptional love and welcome in the spirit of the conventions.
94934e70-8874-4eb7-8392-92fa1841ffae	Photobooth	200	2026-05-27 03:31:30.161564+00	The photoboth is for friends to take pictures and remember this special evening with a backgound that marks the event.
43eccd2a-42d0-4bab-bb05-4489d33c823e	Event Planning	210	2026-05-27 07:53:12.279607+00	Organizing the 4.5 hour event will take coordination to ensure the attendees experience the eveneing in a "I can't believe it's already over" feeling.
\.


--
-- Data for Name: category_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."category_assignments" ("id", "category_id", "user_id", "volunteer_name", "notes", "created_at") FROM stdin;
6f296270-6bb7-4d6c-a8c9-99ac861566de	91c7ba53-f259-494a-b8be-5ac6904f3f55	\N	Teresa Drake	invitation list	2026-05-15 22:24:49.393558+00
80129e0a-9f4b-4247-a2f2-a352eea5a15c	92886527-c0af-4a33-a1fd-74194e12c688	e9e84923-a9bd-4cd3-ad5c-0daf7c05abb3	\N	\N	2026-05-27 03:24:47.076494+00
2b77aeb8-d292-47a2-bfa3-d63b57c20a2a	208816b5-3b82-4815-ba90-b47e1dd9c91d	\N	Shelley Monahan	\N	2026-05-27 03:25:05.892583+00
65b92463-c1b7-4d98-b925-71207c626aa8	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 03:30:15.767361+00
bfa525b4-b29b-4319-b2c5-3f9bc4d53785	e445ad55-f516-4948-80c1-b439869ce84e	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 03:30:37.431323+00
a66a6c7e-0878-483e-a4cd-d7fab405693f	94934e70-8874-4eb7-8392-92fa1841ffae	\N	Pat Monahan	\N	2026-05-27 03:31:51.812862+00
7e063532-df76-4974-881e-57631728cfde	208816b5-3b82-4815-ba90-b47e1dd9c91d	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 17:11:31.321573+00
d7b3bce6-8039-4b25-8d54-74859170aa2b	43eccd2a-42d0-4bab-bb05-4489d33c823e	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 17:14:08.445035+00
093004fa-0655-453c-bd6e-57046f576a69	9d048792-52d7-4423-8564-4617858676a9	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 17:14:24.825773+00
8afa2e79-5601-444b-8563-70323c4aa384	679bc2f3-297d-43bc-8929-98a2d663dfe8	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-20 23:28:21.94178+00
edc2b337-e33a-4ef4-969e-432f0bd43886	f660b181-56b8-4d3a-a5ed-f28dc2d74eb6	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-20 23:28:33.847109+00
776e0d9f-ac96-49de-8f9c-2b177d76cee9	91c7ba53-f259-494a-b8be-5ac6904f3f55	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-20 23:29:03.299983+00
f4408f50-5625-4e3a-9bc2-14f562624241	5017c27e-a693-45d3-b2dd-3f5f3f4365f1	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 07:51:56.242409+00
c40eef15-dda0-4a7b-830c-8cb7d21f8df0	3acafbf8-9f99-40fe-a1d1-01c7fa7190db	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 07:51:56.242409+00
df559391-4297-4354-a6d1-3ee1135dfbaa	cc6467d2-cdc0-4c4f-8b03-f59f2c93f932	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 17:36:28.903213+00
78513cdd-b357-4f8d-87f4-6ee9f978302c	167c811c-f486-479c-b09f-f9faae8a0843	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	2026-05-27 17:36:55.020225+00
3d4cf847-a49a-43ca-a1b1-9cba13120f10	308acecf-a9cb-48ca-92d7-80c211cbfd27	d321e808-0d90-4336-b0d5-baee6f158bcb	\N	\N	2026-06-02 04:17:18.151129+00
ee6a88e2-8015-433b-a5fa-02121ad92eb9	5017c27e-a693-45d3-b2dd-3f5f3f4365f1	d321e808-0d90-4336-b0d5-baee6f158bcb	\N	\N	2026-06-02 04:17:22.90613+00
59e5b603-02d3-4b39-babb-a621021e0d66	3acafbf8-9f99-40fe-a1d1-01c7fa7190db	d321e808-0d90-4336-b0d5-baee6f158bcb	\N	\N	2026-06-02 04:17:26.928674+00
78e29c19-9f43-4e79-a216-e1a210dd2668	9d048792-52d7-4423-8564-4617858676a9	d386b116-f1ec-44fd-954b-800248f2f623	\N	\N	2026-06-03 00:49:25.028292+00
7d022d01-63f4-4c77-92b5-9b6b3eabdc96	f660b181-56b8-4d3a-a5ed-f28dc2d74eb6	d386b116-f1ec-44fd-954b-800248f2f623	\N	\N	2026-06-03 00:50:57.523203+00
cfd681b6-8ec1-4a5c-928d-852bacb199f6	208816b5-3b82-4815-ba90-b47e1dd9c91d	d386b116-f1ec-44fd-954b-800248f2f623	\N	\N	2026-06-03 00:51:26.154397+00
0cd97b4f-3b25-43ef-82d5-73d915806809	679bc2f3-297d-43bc-8929-98a2d663dfe8	d386b116-f1ec-44fd-954b-800248f2f623	\N	\N	2026-06-03 00:52:50.667509+00
add64c4d-b5cc-4abd-8bce-7447dac0b9c0	e445ad55-f516-4948-80c1-b439869ce84e	d386b116-f1ec-44fd-954b-800248f2f623	\N	\N	2026-06-03 00:53:52.008324+00
5f271f33-e022-491b-b70a-65a7ed63e86e	9993301b-29ad-44a9-a4bc-3379f6987f5c	e7619554-8bc3-4576-916d-2d46229702f4	\N	\N	2026-06-14 21:52:33.721211+00
e5d77591-0acd-455e-93c9-5475567769b8	3acafbf8-9f99-40fe-a1d1-01c7fa7190db	e7619554-8bc3-4576-916d-2d46229702f4	\N	\N	2026-06-14 21:52:45.241978+00
11a4c2e7-cc13-43cf-8002-393a15bce103	9e8da7e7-3371-4b42-b3f0-a48e341e3275	e7619554-8bc3-4576-916d-2d46229702f4	\N	\N	2026-06-14 22:37:39.283226+00
5db57a1b-1e28-4b5e-9e1a-0267906bfa6a	e445ad55-f516-4948-80c1-b439869ce84e	e7619554-8bc3-4576-916d-2d46229702f4	\N	\N	2026-06-14 22:38:15.896769+00
b3aac929-4014-412d-a133-2f4e7ccd65fd	208816b5-3b82-4815-ba90-b47e1dd9c91d	7e578c20-8e68-4f51-a37b-86a94c062baf	\N	\N	2026-06-14 22:58:14.366574+00
8c59bdf1-3c1c-4cb3-ae12-71d341275612	208816b5-3b82-4815-ba90-b47e1dd9c91d	3379c93c-6524-4b81-b2cb-b751c94b64e1	\N	\N	2026-06-14 23:03:27.910919+00
4bc66f91-9e5a-4d07-ae0e-22eccdfc53f1	9e8da7e7-3371-4b42-b3f0-a48e341e3275	bca9db99-76a2-40d0-be10-fc3cec21ea4c	\N	\N	2026-06-15 22:57:17.350041+00
23cc72fd-5e4a-4787-9da3-e7d9bf57654b	208816b5-3b82-4815-ba90-b47e1dd9c91d	bca9db99-76a2-40d0-be10-fc3cec21ea4c	\N	\N	2026-06-15 23:02:41.796078+00
29b39652-f1e6-484a-80b6-769c0fe4d8c5	167c811c-f486-479c-b09f-f9faae8a0843	c9b87cf9-b5b2-486f-a343-6fd8b3a94f05	\N	\N	2026-06-17 01:59:01.918162+00
bcbaadaf-8141-43bd-a5ae-49007ad5423f	851482e6-4274-4190-8572-cd819f8cd9e4	c35729d1-326d-43bc-a66b-c0d3bde91cf0	\N	\N	2026-06-26 04:24:35.145986+00
bc22b2a5-6246-4b52-b663-60af8551828b	e445ad55-f516-4948-80c1-b439869ce84e	c35729d1-326d-43bc-a66b-c0d3bde91cf0	\N	\N	2026-06-26 04:24:53.742275+00
372b67ea-032a-451e-8524-bd16c64f5919	208816b5-3b82-4815-ba90-b47e1dd9c91d	c35729d1-326d-43bc-a66b-c0d3bde91cf0	\N	\N	2026-06-26 04:27:27.006418+00
\.


--
-- Data for Name: category_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."category_messages" ("id", "category_id", "user_id", "body", "created_at") FROM stdin;
2fb07093-14fe-4629-8de1-bd0557e24e25	5017c27e-a693-45d3-b2dd-3f5f3f4365f1	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:36:04.474385+00
bdabb60c-6496-4630-96e9-b1c06cc12d05	3acafbf8-9f99-40fe-a1d1-01c7fa7190db	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:36:14.530128+00
206b7e4f-80d9-438a-86c0-12cc2376d952	cc6467d2-cdc0-4c4f-8b03-f59f2c93f932	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:36:34.550997+00
f67076ff-b0ca-444c-bf15-02113818312f	e445ad55-f516-4948-80c1-b439869ce84e	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:36:45.279464+00
19d6195c-525f-484c-98b2-a8c5bc652f92	167c811c-f486-479c-b09f-f9faae8a0843	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:37:00.603627+00
b7dec3ff-cf75-4421-b626-4ac113221f69	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:37:18.309792+00
ea143a1f-c7d8-406b-a82e-50b076f3b512	679bc2f3-297d-43bc-8929-98a2d663dfe8	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:37:30.29082+00
01e650a6-0632-4b06-b36a-26b98bbfc74b	f660b181-56b8-4d3a-a5ed-f28dc2d74eb6	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:37:38.591384+00
4bc60b26-0f80-4cd5-bedf-ece1650cd2e4	9d048792-52d7-4423-8564-4617858676a9	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:37:46.361075+00
e384d944-8b0f-4a50-93b5-1a683f4ba5f5	91c7ba53-f259-494a-b8be-5ac6904f3f55	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:37:56.180608+00
267df9b2-d319-4f62-b8c2-ceb98600579f	208816b5-3b82-4815-ba90-b47e1dd9c91d	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:38:12.242211+00
d414fbd6-1bfc-45b1-be2c-d8f25e463522	43eccd2a-42d0-4bab-bb05-4489d33c823e	00651c0f-c5e3-45b1-8979-960f3f752c74	hi	2026-05-27 17:38:24.274185+00
2f7c91e6-0cf5-4695-ad96-76cbadb48e5c	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	We have a 6 pm appointment with Inez from Koen Japanese BBQ and Izakaya, Farnam Street Suite 201, Omaha, Nebraska	2026-06-15 22:40:50.862914+00
06908b9c-6114-42a0-8519-d78e79381071	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	https://share.google/Ns8CuoRd3ipQuYSKI	2026-06-15 22:40:56.839297+00
a173e5e2-9b64-4e8e-933e-aa1c47f26e4e	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	This is for Indonesia	2026-06-15 22:41:16.171499+00
907156ed-90ee-4751-a53d-31910bd1eb88	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	She is Indonesian	2026-06-15 22:41:32.124633+00
63771645-18c5-4949-9c9d-30ad33560e4f	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	Sunday is 5 pm the 21st	2026-06-15 22:43:40.629676+00
96e06555-166e-4642-8c1a-5138f875516f	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	3863 Farnam St Ste 201, Omaha, NE 68131	2026-06-15 22:44:54.735681+00
36977558-1abf-4bdb-ae4a-98c3b3f76d57	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	Park on Harney st because of construction on Farnam	2026-06-15 22:45:23.888268+00
b86381b9-1966-4f3e-9783-fd02fd7f8778	9e8da7e7-3371-4b42-b3f0-a48e341e3275	bca9db99-76a2-40d0-be10-fc3cec21ea4c	Hi	2026-06-15 22:57:56.638744+00
35b7a98c-b646-4a04-ac80-0310666bbb44	9e8da7e7-3371-4b42-b3f0-a48e341e3275	bca9db99-76a2-40d0-be10-fc3cec21ea4c	Is this for today?	2026-06-15 22:59:02.685837+00
624cfcd8-c65a-4a46-8bb1-f0ef53a873c7	9e8da7e7-3371-4b42-b3f0-a48e341e3275	bca9db99-76a2-40d0-be10-fc3cec21ea4c	Never mind	2026-06-15 23:00:41.637402+00
a5bc9cd7-ef59-4aa5-b448-3ead491f25a2	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	Sunday June 21	2026-06-15 23:03:24.672429+00
9fa54850-c342-4226-8a85-7088aad63c88	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	5 pm	2026-06-15 23:03:37.423709+00
3d04431b-6d93-47bf-a35e-a92117b3f97a	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	You want to ride with me Tianna?	2026-06-15 23:04:02.898206+00
2800d01e-f046-4f72-b59c-b33014e76e99	9e8da7e7-3371-4b42-b3f0-a48e341e3275	bca9db99-76a2-40d0-be10-fc3cec21ea4c	Is there going to be any cost for the tasting	2026-06-15 23:04:03.80626+00
6b8514ca-f98d-475c-9055-b9dd82bcecde	9e8da7e7-3371-4b42-b3f0-a48e341e3275	bca9db99-76a2-40d0-be10-fc3cec21ea4c	Yes please	2026-06-15 23:04:14.8776+00
0bc2520e-3161-401f-9ced-488a5831588d	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	I would think so. We discussed keeping it in the 20 range for the catered meal.	2026-06-15 23:05:00.928525+00
edb8f462-dfc7-4b42-90fc-947c67cbe72b	9e8da7e7-3371-4b42-b3f0-a48e341e3275	bca9db99-76a2-40d0-be10-fc3cec21ea4c	Ok	2026-06-15 23:05:16.503044+00
6685306c-1cd1-412f-b1bc-7ac13d14c826	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	We will leave at 4:15 pm	2026-06-15 23:05:45.085648+00
bc3dc5f0-ac9d-468e-ab7f-533753715175	9e8da7e7-3371-4b42-b3f0-a48e341e3275	bca9db99-76a2-40d0-be10-fc3cec21ea4c	Alright I will be ready	2026-06-15 23:06:01.918457+00
b1e6e2aa-b288-4669-8e84-258f7e168a47	9e8da7e7-3371-4b42-b3f0-a48e341e3275	e7619554-8bc3-4576-916d-2d46229702f4	Got it, thanks Kari!	2026-06-17 22:02:58.675334+00
07634d11-463f-4224-8831-b8f3d4f7c2da	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	https://docs.google.com/document/d/14EYO6j_ZAB0n6nqxQ-grL9IdiOEDsyHWrC1oVkd7nos/edit?usp=drivesdk	2026-06-19 17:21:55.294554+00
bce10bf8-e3da-4e3c-b083-d13926fa740f	9e8da7e7-3371-4b42-b3f0-a48e341e3275	00651c0f-c5e3-45b1-8979-960f3f752c74	We have confirmed reservation for 4	2026-06-19 17:22:20.260655+00
\.


--
-- Data for Name: chat_last_seen; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."chat_last_seen" ("user_id", "chat_kind", "chat_id", "last_seen_at") FROM stdin;
00651c0f-c5e3-45b1-8979-960f3f752c74	category	167c811c-f486-479c-b09f-f9faae8a0843	2026-06-17 06:29:45.254+00
f90abc4a-6ba0-434c-a825-e287bb6414bb	team	00000000-0000-0000-0000-000000000001	2026-06-17 17:15:29.915+00
e7619554-8bc3-4576-916d-2d46229702f4	team	00000000-0000-0000-0000-000000000001	2026-06-17 22:00:40.616+00
e7619554-8bc3-4576-916d-2d46229702f4	category	3acafbf8-9f99-40fe-a1d1-01c7fa7190db	2026-06-17 22:00:58.172+00
e7619554-8bc3-4576-916d-2d46229702f4	category	e445ad55-f516-4948-80c1-b439869ce84e	2026-06-17 22:04:03.896+00
00651c0f-c5e3-45b1-8979-960f3f752c74	category	208816b5-3b82-4815-ba90-b47e1dd9c91d	2026-06-18 17:28:52.303+00
00651c0f-c5e3-45b1-8979-960f3f752c74	category	91c7ba53-f259-494a-b8be-5ac6904f3f55	2026-06-19 17:19:07.28+00
00651c0f-c5e3-45b1-8979-960f3f752c74	category	9e8da7e7-3371-4b42-b3f0-a48e341e3275	2026-06-19 17:21:55.617+00
bca9db99-76a2-40d0-be10-fc3cec21ea4c	category	9e8da7e7-3371-4b42-b3f0-a48e341e3275	2026-06-21 14:01:04.947+00
e7619554-8bc3-4576-916d-2d46229702f4	category	9e8da7e7-3371-4b42-b3f0-a48e341e3275	2026-06-21 17:26:55.067+00
c35729d1-326d-43bc-a66b-c0d3bde91cf0	team	00000000-0000-0000-0000-000000000001	2026-06-26 04:34:30.748+00
00651c0f-c5e3-45b1-8979-960f3f752c74	team	00000000-0000-0000-0000-000000000001	2026-06-27 06:35:15.304+00
\.


--
-- Data for Name: cuisine_preorders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."cuisine_preorders" ("id", "name", "phone", "selections", "created_at", "invitation_id", "updated_at") FROM stdin;
15434fc3-ebc1-4caa-b906-d1cb4676e1b2	Melissa Novotne	4026796544	[{"qty": 1, "cuisine": "Myanmar"}]	2026-06-02 03:00:32.679346+00	e6a7d814-64ba-4119-8311-933ffd77b108	2026-06-02 03:00:32.679346+00
d10bbdee-a86c-4454-8053-94b77ea57a57	Gina Rae Filer	(402) 812-7437	[{"qty": 1, "cuisine": "Myanmar"}]	2026-06-03 00:33:28.142774+00	782f8752-1d48-4ef8-878e-e2637d65138a	2026-06-03 00:33:28.142774+00
37b2af73-bf02-4cc2-989e-c7fb324cd816	Betsaida Ruiz	4022539229	[{"qty": 2, "cuisine": "Indonesian"}]	2026-06-03 01:26:59.668994+00	0a3a06dd-d5cd-4b3f-8252-9bb3f214967b	2026-06-03 01:26:59.668994+00
980c744c-a5df-4c27-8843-e932c9110a73	Kenda Andersen	(402) 296-9922	[{"qty": 1, "cuisine": "Indonesian"}]	2026-06-03 12:59:43.653361+00	4b7436b1-ef27-4a96-8e4c-afa80fb1c768	2026-06-03 12:59:43.653361+00
34ba2bb1-28c0-4fa7-a768-b1d320dbf9aa	Brenda Lucas	4028045102	[{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "African"}, {"qty": 1, "cuisine": "Indonesian"}]	2026-06-03 14:42:44.812853+00	1294c193-e185-479a-88f0-07ccd464d0b1	2026-06-03 14:42:44.812853+00
e264a507-bb04-4935-8ae4-386df597cbbd	Gloria J Groves	4026707566	[{"qty": 2, "cuisine": "Myanmar"}]	2026-06-04 01:26:32.757098+00	e6e0f567-29c4-4825-a644-cc364f60f142	2026-06-04 01:26:32.757098+00
cc9cfc14-e93e-44a8-b181-57cd102900cd	Steven&Denise Madsen	(402) 714 1491	[{"qty": 2, "cuisine": "African"}]	2026-06-04 02:47:09.2617+00	f55e10f3-592a-4526-bef6-00558aedeb1f	2026-06-04 02:47:09.2617+00
e983a8ba-dc88-4190-9b74-3d0710e45310	S. Carmen De La Cruz	4022912856	[{"qty": 1, "cuisine": "African"}]	2026-06-06 02:15:52.831957+00	569ed7ad-2c9f-4d4a-883a-6501b4ae6e35	2026-06-06 02:15:52.831957+00
97834e5f-493b-40c7-8859-57be91028180	MsDixie L. Frahm	4029795214	[{"qty": 1, "cuisine": "Indonesian"}]	2026-06-08 14:19:30.600968+00	8a30cef1-f3c0-41fd-a93a-83d73d34f09b	2026-06-08 14:20:05.533719+00
44bd9a50-d2e6-43b5-b143-4255f779c24c	Aletta Blair	4029991213	[{"qty": 1, "cuisine": "Myanmar"}]	2026-06-03 18:17:31.770949+00	d4d1dd12-40da-4acb-8b3f-ef7c0d887c40	2026-06-08 21:58:47.375579+00
0f068a72-b9d7-473c-b1b7-fa849e356af2	Rick & Maddie Madrid	5623264395	[{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "Indonesian"}]	2026-06-09 03:43:29.791223+00	386ddfb3-f3f1-4acc-94ae-15fb50668d26	2026-06-09 03:48:04.753928+00
527cd51b-d096-4ebc-abb3-40231c5f769f	Tiana Stoddard	(402) 202-8845	[{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "African"}, {"qty": 1, "cuisine": "Indonesian"}]	2026-06-14 22:22:08.583379+00	12fbbc43-8bb9-4479-9180-98650229e369	2026-06-14 22:44:06.907674+00
e958b919-a110-42c9-a30d-85551a75bab4	Kari Gray	8082787562	[{"qty": 1, "cuisine": "Indonesian"}, {"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "African"}]	2026-05-26 08:14:29.098985+00	e616d5f5-43ba-435a-8020-f71ec58f1bda	2026-06-14 23:29:34.836213+00
fb82bf18-9418-4701-8bb7-cad2e32bc6fe	Liza Efigenio	4025157916	[{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "African"}, {"qty": 1, "cuisine": "Indonesian"}]	2026-06-15 02:20:12.706563+00	e3d2376d-1e1c-4426-8891-9cc17ebdec79	2026-06-15 02:20:12.706563+00
76fadd9d-29bf-47bf-895a-8f559a15c0e0	Lisa Espinosa	4029992600	[{"qty": 1, "cuisine": "Indonesian"}]	2026-06-15 17:28:18.045577+00	ab8b93be-4778-4a1d-b83b-cdc8fb116707	2026-06-15 17:28:44.756986+00
f49e9503-7c35-4df4-930c-f68be5ed628b	Tirzah Corbin	6084124014	[{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "Indonesian"}]	2026-06-18 17:10:33.70243+00	38d7a42f-6da9-4458-9e33-5de51ea9022d	2026-06-18 17:10:33.70243+00
c81fbcb8-1a50-4eb3-9e6d-b2b8e18791da	Dee Sallis	4022136518	[{"qty": 1, "cuisine": "Myanmar"}, {"qty": 1, "cuisine": "African"}, {"qty": 1, "cuisine": "Indonesian"}]	2026-06-26 04:21:37.677534+00	5caa4514-9306-40de-bb6e-424cfcae0e4e	2026-06-26 04:21:37.677534+00
8cf2efc1-36af-423f-8a01-8e18e23a627b	Adrianna Marie Gonzalez	4028076980	[{"qty": 1, "cuisine": "Indonesian"}, {"qty": 1, "cuisine": "Myanmar"}]	2026-06-26 23:57:09.277898+00	2bf8fce4-c2d3-4152-904d-9dc2e820d412	2026-06-26 23:57:09.277898+00
\.


--
-- Data for Name: deleted_rows_archive; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."deleted_rows_archive" ("id", "table_name", "row_id", "row_data", "deleted_by", "deleted_by_phone", "deleted_by_name", "deleted_at") FROM stdin;
a42a2d96-df73-4b34-ae24-4cd5d21cbc25	cuisine_preorders	2bbaf321-9185-440e-83ce-55b61c2dee5e	{"id": "2bbaf321-9185-440e-83ce-55b61c2dee5e", "name": "Kenda Andersen", "phone": "(402) 296-9922", "created_at": "2026-06-03T13:00:42.219319+00:00", "selections": [{"qty": 1, "country": "Jakarta, Indonesia"}], "updated_at": "2026-06-03T13:00:42.219319+00:00", "invitation_id": null}	\N	\N	\N	2026-06-16 06:04:07.414752+00
ef16462e-c312-4ac7-bbe4-e283a65f29a6	cuisine_preorders	da9ab028-32d2-4474-9cb6-e1b72708047d	{"id": "da9ab028-32d2-4474-9cb6-e1b72708047d", "name": "S. Carmen De La Cruz", "phone": "4022912856", "created_at": "2026-06-06T02:14:15.251328+00:00", "selections": [{"qty": 1, "country": "Mozambique"}], "updated_at": "2026-06-06T02:14:15.251328+00:00", "invitation_id": null}	\N	\N	\N	2026-06-16 06:04:07.414752+00
daf9c683-ed55-4130-ba7e-bed840003a11	cuisine_preorders	feb248d0-42b2-4846-8516-92c9b8ebdaaf	{"id": "feb248d0-42b2-4846-8516-92c9b8ebdaaf", "name": "MsDixie Frahm", "phone": "4029795214", "created_at": "2026-06-08T14:17:10.354914+00:00", "selections": [{"qty": 1, "country": "Indonesia"}], "updated_at": "2026-06-08T14:17:10.354914+00:00", "invitation_id": null}	\N	\N	\N	2026-06-16 06:04:07.414752+00
70f84ea6-f7ed-49a3-830b-7220c48c57e5	invitations	fa170011-f8a5-41cb-b96d-b80da4be8c6f	{"id": "fa170011-f8a5-41cb-b96d-b80da4be8c6f", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-14T18:35:26.23677+00:00", "guest_name": "NE Sofia Barios", "rsvp_token": "pr2GFJlBMxSLh7JNM9dskhb0", "guest_email": null, "guest_phone": "(402) 804-6923", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "4028046923"}	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	2026-06-16 07:18:31.057158+00
4207c297-bd7f-45e8-932a-c79c508472ca	inviters	44f416cf-155c-444e-bd32-8d1e15b91449	{"id": "44f416cf-155c-444e-bd32-8d1e15b91449", "name": "Sarah Campbell", "email": null, "phone": "(402) 802-4026", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-02T02:16:18.957855+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	2026-06-16 07:23:20.463238+00
14d741cd-f265-4a3d-837d-d287fe9a6019	inviters	046d10b2-31d3-46be-96d5-e09362a9c035	{"id": "046d10b2-31d3-46be-96d5-e09362a9c035", "name": "Saul Morro", "email": null, "phone": "+1531-484-5553", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-06T01:52:48.327389+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	2026-06-16 07:27:36.276726+00
ded85a6a-57b6-452b-b1ff-536503324950	inviters	5a2dfd54-c826-4f78-a5db-7fc9bc507d91	{"id": "5a2dfd54-c826-4f78-a5db-7fc9bc507d91", "name": "Dixie Frahm", "email": null, "phone": "14029795214", "quota": 0, "active": true, "host_id": null, "created_at": "2026-06-17T16:47:32.157637+00:00", "requested_quota": null, "quota_request_note": null, "quota_requested_at": null}	\N	\N	\N	2026-06-17 23:17:01.060887+00
22150465-7dbf-4469-99e7-f76a8ac0252f	invitations	b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3	{"id": "b5e0bbaf-8e31-4607-b6ca-f9eac1653ed3", "notes": null, "host_id": "f90abc4a-6ba0-434c-a825-e287bb6414bb", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-17T16:57:26.965919+00:00", "guest_name": "Kari Gray", "rsvp_token": "pffJVzxOI1LmFl8U9MfUk3Hg", "guest_email": null, "guest_phone": "1 (808) 278-7562", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "18082787562"}	f90abc4a-6ba0-434c-a825-e287bb6414bb	14029795214	MsDixie L. Frahm	2026-06-17 23:19:45.42739+00
9f13d5a1-988e-4bff-a673-7c2e950b9db2	invitations	970eadfe-ddf9-48fe-a659-0d84b3968b73	{"id": "970eadfe-ddf9-48fe-a659-0d84b3968b73", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.743598+00:00", "guest_name": "Shelley & Pat Monahan", "rsvp_token": "Mpm9j3TBwph6/pGvdQidhKNK", "guest_email": null, "guest_phone": "+1 402-639-4513", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:26.352+00:00", "guest_email_normalized": null, "guest_phone_normalized": "14026394513"}	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	2026-06-19 19:26:15.877097+00
93505dcb-d258-49c9-9df9-672dc8eeffba	invitations	0aea5691-1402-4357-9429-9062353d9622	{"id": "0aea5691-1402-4357-9429-9062353d9622", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-05-22T22:02:10.064897+00:00", "guest_name": "Michelle Shawger", "rsvp_token": "OPP/IApzbh3QB8FHSfwYtTpK", "guest_email": null, "guest_phone": "+1 989-430-1979", "is_committee": true, "invite_sent_at": "2026-06-03T06:26:14.958+00:00", "guest_email_normalized": null, "guest_phone_normalized": "19894301979"}	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	2026-06-19 19:26:26.013967+00
81a36873-7fd4-473b-9227-df9ee29aecc2	invitations	c4b01026-452f-4ed3-936a-0670ffdcfae2	{"id": "c4b01026-452f-4ed3-936a-0670ffdcfae2", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-22T03:05:56.594513+00:00", "guest_name": "BW Jos Whe Kersaint", "rsvp_token": "3cvNRnr8QhQO2K1iTqVFrf9u", "guest_email": null, "guest_phone": "(347) 417-0691", "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": "3474170691"}	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	2026-06-22 03:16:20.200792+00
baa29c36-e46d-4d96-855b-b1855439fecc	invitations	0f1d067f-c2dc-410e-910b-d9791bad9303	{"id": "0f1d067f-c2dc-410e-910b-d9791bad9303", "notes": null, "host_id": "00651c0f-c5e3-45b1-8979-960f3f752c74", "event_id": "00000000-0000-0000-0000-000000000001", "created_at": "2026-06-21T17:25:03.456448+00:00", "guest_name": "1 other person", "rsvp_token": "SOMHhczIjRi4AYdJfvl/mpcG", "guest_email": null, "guest_phone": null, "is_committee": false, "invite_sent_at": null, "guest_email_normalized": null, "guest_phone_normalized": ""}	00651c0f-c5e3-45b1-8979-960f3f752c74	18082787562	Kari Gray	2026-06-27 00:54:43.147279+00
\.


--
-- Data for Name: donations_summary; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."donations_summary" ("id", "total_amount", "notes", "updated_at") FROM stdin;
t	0	\N	2026-05-24 03:59:12.966987+00
\.


--
-- Data for Name: duplicate_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."duplicate_flags" ("id", "event_id", "invitation_a", "invitation_b", "match_type", "created_at") FROM stdin;
\.


--
-- Data for Name: email_send_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."email_send_log" ("id", "message_id", "template_name", "recipient_email", "status", "error_message", "metadata", "created_at") FROM stdin;
285f1ca9-a7e9-4764-9b5c-9a3276d7a02f	59cf1d33-bccd-432b-9942-6b02529a6aa8	recovery	kgray623@gmail.com	pending	\N	\N	2026-05-20 18:30:45.640245+00
17c409f2-c1bb-48fb-b89c-cdb2b8ef0cbe	59cf1d33-bccd-432b-9942-6b02529a6aa8	recovery	kgray623@gmail.com	sent	\N	\N	2026-05-20 18:37:38.557688+00
e440f6d3-7f96-410d-9a2d-f9bf932bedeb	006a5461-5fcf-4177-9160-51e0e716e053	recovery	kgray623@gmail.com	pending	\N	\N	2026-05-20 20:42:17.15095+00
6557c703-e71b-442f-a3e6-70e849e38c8d	7a1644b0-c64f-4c6e-a21f-a37afa0963bd	recovery	kgray623@gmail.com	pending	\N	\N	2026-05-20 20:42:17.972059+00
a7dcba28-b956-4c45-a1b3-e2d75355d7c2	006a5461-5fcf-4177-9160-51e0e716e053	recovery	kgray623@gmail.com	sent	\N	\N	2026-05-20 20:42:23.643591+00
8ece6d1d-f041-4030-979e-04a6852a0a4c	7a1644b0-c64f-4c6e-a21f-a37afa0963bd	recovery	kgray623@gmail.com	sent	\N	\N	2026-05-20 20:42:24.216249+00
a170489c-3a3a-4289-b9a1-ced4fd8d0fdb	efe6007b-17dc-4caa-92ce-86f5a8894355	recovery	kgray623@gmail.com	pending	\N	\N	2026-05-20 21:06:01.457479+00
5e91926c-cef9-4993-a355-a4a5140c03d4	efe6007b-17dc-4caa-92ce-86f5a8894355	recovery	kgray623@gmail.com	sent	\N	\N	2026-05-20 21:06:03.794707+00
c1d12484-dbc2-46ea-9eb8-9d5ad6d8eff5	8411e4c8-2045-4133-b87e-b1d1e1a3f6d1	rsvp-confirmation	livingprevention@gmail.com	pending	\N	\N	2026-05-21 18:36:08.727184+00
96ef1b62-fa55-4ce6-a648-85836f0cc207	8411e4c8-2045-4133-b87e-b1d1e1a3f6d1	rsvp-confirmation	livingprevention@gmail.com	sent	\N	\N	2026-05-21 18:36:14.165773+00
8ea84abb-52ee-4be7-ace8-09e5e78c0d1b	78708ca5-df6b-4dfd-9823-10c37607e94a	rsvp-confirmation	livingprevention@gmail.com	pending	\N	\N	2026-05-21 19:10:04.107347+00
f012e021-bff9-4728-90de-3c6d3e460c66	78708ca5-df6b-4dfd-9823-10c37607e94a	rsvp-confirmation	livingprevention@gmail.com	sent	\N	\N	2026-05-21 19:10:11.07151+00
be4a7bda-093c-42e6-8230-68d5f6071dfa	0c42ab45-3e2b-456a-b1e6-1c606eaffe6a	rsvp-confirmation	bust_a_move_@hotmail.com	pending	\N	\N	2026-05-21 20:42:38.98416+00
716a1844-1575-429b-afeb-1eb447c3bedf	0c42ab45-3e2b-456a-b1e6-1c606eaffe6a	rsvp-confirmation	bust_a_move_@hotmail.com	sent	\N	\N	2026-05-21 20:42:43.38708+00
e8bd8a81-1771-4895-9838-1eb083096534	c0249471-2a36-4087-bfb7-71adf3ca8f8f	team-invite	livingprevention@gmail.com	pending	\N	\N	2026-05-24 04:23:37.442725+00
0b4cbd03-66e3-4ffb-ac25-9a19b06252b5	c0249471-2a36-4087-bfb7-71adf3ca8f8f	team-invite	livingprevention@gmail.com	sent	\N	\N	2026-05-24 04:23:44.053896+00
04516da2-0812-4caa-b828-cce2bd82d4cb	1a7ae7cd-68d3-4269-a795-e318f9431111	team-invite	livingprevention@gmail.com	pending	\N	\N	2026-05-24 05:11:27.811421+00
fd7b887b-e261-4ea1-945e-5a1001363f7d	1a7ae7cd-68d3-4269-a795-e318f9431111	team-invite	livingprevention@gmail.com	sent	\N	\N	2026-05-24 05:11:34.324477+00
bf4f8232-e8b5-46c1-9520-b0a67ad1b500	19c8f59b-6c16-469e-a278-bc73acfd29e1	rsvp-confirmation	livingprevention@gmail.com	pending	\N	\N	2026-05-24 13:27:46.052523+00
2ab7d03c-daed-455e-b3f0-31684d848c98	7d22a76d-c966-4b22-9345-5015e16326a5	rsvp-confirmation	livingprevention@gmail.com	pending	\N	\N	2026-05-24 13:27:48.150689+00
1331e8e8-09c8-4422-bc6e-d480afa28371	19c8f59b-6c16-469e-a278-bc73acfd29e1	rsvp-confirmation	livingprevention@gmail.com	sent	\N	\N	2026-05-24 13:27:51.935454+00
ed5e1b4b-afb6-49f4-8153-8125dc2105a9	7d22a76d-c966-4b22-9345-5015e16326a5	rsvp-confirmation	livingprevention@gmail.com	sent	\N	\N	2026-05-24 13:27:53.726287+00
\.


--
-- Data for Name: email_send_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."email_send_state" ("id", "retry_after_until", "batch_size", "send_delay_ms", "auth_email_ttl_minutes", "transactional_email_ttl_minutes", "updated_at") FROM stdin;
1	\N	10	200	15	60	2026-05-20 15:40:17.446588+00
\.


--
-- Data for Name: email_unsubscribe_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."email_unsubscribe_tokens" ("id", "token", "email", "created_at", "used_at") FROM stdin;
1de6bbbe-c142-4167-8349-7d8e018b8b11	9bf0f52018d768a19f2be8322ff27a00d2fba406f12247c38022f2d28a1d1945	livingprevention@gmail.com	2026-05-21 18:36:08.334819+00	\N
704e59d0-5363-43a2-b325-85fce485a807	0266666532ae7042ab91acd05ec7e48d07df56f05395ab0d68686bd5f4503071	bust_a_move_@hotmail.com	2026-05-21 20:42:38.819773+00	\N
\.


--
-- Data for Name: entertainment_submissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."entertainment_submissions" ("id", "created_at", "name", "email", "phone", "talent", "notes", "video_path") FROM stdin;
e072cbfa-bf05-4ead-a35c-6a840e4a5a06	2026-05-22 17:15:47.681675+00	Jacquelyn Spears	\N	4175923238	\N	I sing like Mariah carey	fa5a52ec-6297-47b1-82a3-6d695097bc40.mp4
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."events" ("id", "title", "description", "starts_at", "ends_at", "location", "virtual_link", "cover_image_url", "created_by", "created_at") FROM stdin;
00000000-0000-0000-0000-000000000001	A Taste of Special Conventions	Come spend an evening virtually traveling to multiple Special Conventions and connect with friends, make new friends, while getting a taste of the Special Conventions throughout the earth.\n\nSpend an unforgettable evening of culture, cuisine, conversation, and connection.	2026-08-30 21:00:00+00	2026-08-31 02:00:00+00	Falconwood Park, Hanke Building, 905 Allied Road, Bellevue, NE 68123	https://maps.app.goo.gl/BtYtkMKMDxMsiC4p9?g_st=ac	\N	\N	2026-05-15 01:12:30.090444+00
\.


--
-- Data for Name: guest_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."guest_messages" ("id", "invitation_id", "sender", "user_id", "body", "read_by_admin", "read_by_guest", "created_at") FROM stdin;
e20c4c22-f7e5-4640-b452-8ac1c6ac3e99	99bc748b-a8f9-4018-a9b2-4fccba179a94	guest	\N	Test	f	f	2026-05-21 19:10:43.6186+00
59e13393-79bd-437a-b5dd-d383d83ba549	99bc748b-a8f9-4018-a9b2-4fccba179a94	admin	c3160a24-000a-46b0-811b-ffe22e265981	T u	f	f	2026-05-21 19:11:48.765806+00
89bf1886-ebcd-4be0-b20f-68425795dd4e	402f3c9d-e96f-441e-a095-1c40a40188ed	admin	c3160a24-000a-46b0-811b-ffe22e265981	Testing	f	f	2026-05-21 19:12:01.510006+00
466d7511-0dd3-4b24-9348-636eae5d4c62	99bc748b-a8f9-4018-a9b2-4fccba179a94	admin	c3160a24-000a-46b0-811b-ffe22e265981	Testing	f	f	2026-05-21 19:12:01.510006+00
\.


--
-- Data for Name: invitation_content; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."invitation_content" ("id", "singleton", "hero_eyebrow", "hero_title", "hero_title_emphasis", "hero_title_suffix", "hero_tagline", "hero_intro", "video_url", "itinerary", "datetime_heading", "datetime_body", "location_name", "location_subtitle", "location_body", "dress_body", "gifts_body", "updated_at") FROM stdin;
c93cf325-bb6c-4e2a-a747-557e078f10d2	t	You're Cordially Invited To	A Taste of	Special	Conventions	An event and an evening to remember.	You are cordially invited to join us for a very special evening of association, cultural enrichment, gift exchanges, meeting new friends, seeing old friends, and making wonderful memories — this side of paradise. See the video for details. 	https://jqlrwcembabqlqoxeliq.supabase.co/storage/v1/object/public/invitation-media/hero-invitation-inline.mp4	[{"note": "We start in Yangoon, Myanmar as we share the flavors and the faith-inspiring stories from a country of great hardship, immense poverty, and inspiring generosity and faith.", "when": "Convention · 2014", "country": "Myanmar", "restaurant": true}, {"note": "Let's travel to the \\"Be Courageous\\" Special Convention in Maputo, Mozambique and meet brothers of faith from a country of former persecution with brothers and sisters from across the world.", "when": "Convention · 2018", "country": "Mozambique", "restaurant": true}, {"note": "Next we travel to Jakarta, Indonesia , the largest city on the earth to connect 'heart to heart' with our brothers and sisters at the \\"To the Ends of the Earth\\" Special Convention.", "when": "Convention · 2025", "country": "Indonesia", "restaurant": true}, {"note": "We close this amazing evening in Auckland, New Zealand —and enjoy the inspiring memories shared by those who were there in this beautiful country.", "when": "Convention · 2026", "country": "New Zealand", "restaurant": false}]	Sunday, August 30, 2026 · 4:00 PM – 9:30 PM	Join us from 4:00 PM to 9:30 PM for an evening together.	Falconwood Park	Bellevue, Nebraska	905 Allied Road, Hanke Hall Bellevue, NE 68123	This is an event to enjoy culture: your culture, one you serve in, or one you have an interest in. Cultural dress is encouraged or appropriate meeting or formal attire. This evening is a festive and beautiful occasion for all to enjoy! Convention badges are encouraged to be worn, and children are invited with a parent or guardian.	In the spirit of the Special and International conventions, friends bring small gifts to exchange with each other when meeting one another. See the video below — for details.	2026-06-20 01:30:13.044+00
\.


--
-- Data for Name: invitations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."invitations" ("id", "event_id", "host_id", "guest_name", "guest_email", "guest_phone", "notes", "rsvp_token", "created_at", "invite_sent_at", "is_committee") FROM stdin;
569ed7ad-2c9f-4d4a-883a-6501b4ae6e35	00000000-0000-0000-0000-000000000001	c3160a24-000a-46b0-811b-ffe22e265981	S. Carmen De La Cruz	\N	4022912856	\N	1+u3b1+m7zdZiQntkjGRPt0Y	2026-06-06 02:15:52.200855+00	2026-06-06 02:22:03.362+00	f
2adab274-bcbc-40ea-b363-30081791eba5	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Abigail and DeShawn Bradley	\N	(402) 452-1683	\N	kXIqlHga5lXridPa7b5Wzrz5	2026-06-03 08:06:07.924943+00	2026-06-03 08:06:36.349+00	f
58fd842a-ab6f-43d2-8bd2-a553bebdef49	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Shannan Bessey	\N	(402) 730-9945	\N	pGR9Ek3T4tFjg9RIAHGGDiKl	2026-06-03 07:47:37.134768+00	2026-06-03 07:58:03.75+00	f
4f46531b-a768-47ad-ab14-623e8505978a	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Dottie & Javan Allen	\N	402-639-6230	\N	SrjvHEuAOvaZG7frHFtYNwVB	2026-06-03 00:11:08.137313+00	2026-06-03 00:29:40.205+00	f
45822c74-835d-447a-825c-d27f09ae2b99	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Gina Filer	\N	402-822-7437	\N	lJQL9EdPGoyhB3968x+/TT9K	2026-06-03 00:11:08.261695+00	2026-06-03 00:29:35.099+00	f
30c03368-3866-473a-873a-cbce8511850c	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Norma Stanley	\N	(402) 804-5835	\N	Mq4U35BAoxx+K1rt4/XOXRSN	2026-06-04 09:13:32.472886+00	2026-06-04 09:13:47.485+00	f
5a73b19b-305b-4d23-87cb-2e64e64b5b86	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Randy Andrews	\N	(402) 598-0258	\N	XGV/BVXasCfA8PYFxXtOWlAz	2026-06-04 09:09:39.430305+00	2026-06-04 09:10:24.846+00	f
90ac5db5-a3cc-478c-8775-fb71f7b7e336	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	John Warren	\N	\N	\N	wrjXc6ypdOmYe3YxhHbwIfNC	2026-06-04 09:17:34.425518+00	2026-06-04 09:17:49.656+00	f
12fbbc43-8bb9-4479-9180-98650229e369	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Tiana Stoddard	\N	(402) 202-8845	\N	EzbiySrHA+m5+dOBTDqoAsJU	2026-06-04 09:09:40.263266+00	2026-06-04 09:10:06.602+00	f
8da5c670-7df4-4410-a7e6-e1cded4206fb	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Teena Chappal	\N	(402) 227-5177	\N	ZYwkMxlYP22odxQRMiAl3v0G	2026-05-23 02:43:09.204657+00	2026-06-03 07:10:44.258+00	f
e34e5f5b-0949-4891-86c1-ca2a3d9eabce	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Robn Droz	\N	(402) 740-6722	\N	zvQJjYNEnwOt2CxLR0na3aOv	2026-05-22 22:02:12.376422+00	2026-06-03 07:03:32.217+00	f
d6228d2f-7dbd-44cc-bb4e-11b9078ae229	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Jacquelyn Spears	\N	4175923238	\N	9Ws/OHJsQpOsxRrAx9sXrn+f	2026-06-02 00:39:41.404001+00	2026-06-03 06:25:36.366+00	f
81854c4d-9d08-4e07-bedd-e1f6ee70af30	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Saul Morro	\N	+1531-484-5553	\N	TUWwP5lfFYYg0/xskCRpRzGu	2026-05-22 22:02:09.684701+00	2026-06-03 06:26:09.718+00	t
f37d42e0-e16f-4b87-a988-b7a113169d54	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Jennifer Spears	niferspears@hotmail.com	(808) 250-4081	\N	TGTqQA5knBkOflq2KvTOKZpU	2026-05-22 22:02:13.01873+00	2026-06-03 06:27:25.118+00	f
9ff515cd-86f2-4665-b131-c59c4905872c	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Vivian Moore	\N	(402) 838-5105	\N	Sb8QFx1Lu60L1pM/EsvvjeVD	2026-05-22 22:02:09.92796+00	2026-06-03 06:43:41.334+00	f
6b91f913-afac-4c38-84c3-87e694519cd4	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Lilly Berrios	\N	+1 402-516-2802	\N	tJo0bNl78OaAfYA639jSDqlm	2026-05-22 22:02:10.20907+00	2026-06-03 06:45:06.593+00	f
b57bf811-0321-4417-8ff7-892b0a753fcd	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Jacqueline Graves	\N	(904) 442-4513	6604 N 90th Plaza Apt A Omaha Nebraska 68122	PRZjYgbHkuUrdcT/6pnKFWYK	2026-05-22 22:02:11.681941+00	2026-06-03 06:59:33.545+00	f
9a0ed75c-d0b9-473c-883a-6262f5c52226	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Hannah Adepenu	\N	+1 402-452-9565	\N	nzjv4C/EkHrS9wTKnvFb7YHT	2026-05-22 22:02:11.82034+00	2026-06-03 07:02:01.083+00	f
2c6f69b0-ce65-483c-9d72-2b817ead263b	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Cindi Eldridge	\N	+1 402-990-5557	\N	JBtx+D3S+hsqdBVOo84uZZ0T	2026-05-22 22:02:12.50343+00	2026-06-03 07:03:36.27+00	f
fa86baf9-06a9-4b9f-acac-049b7572c7f6	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Ami Moore	\N	+1 402-305-8875	\N	R9Tipxh/IKhXNaq+1yUyEPvE	2026-05-22 22:02:12.5984+00	2026-06-03 07:05:44.324+00	f
a14af6c5-8ba6-45f8-9684-3b107b4d93f4	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Audrey Eldridge Burhr	\N	+1 402-639-1212	\N	dR+WFhY2vGOChXUOMzl8uOkB	2026-05-22 22:02:12.73735+00	2026-06-03 07:05:47.667+00	f
9fed5138-a4b8-43ee-9896-eccb7c3a607d	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Anneth Cuadras	\N	402-659-0608	\N	fpOiOq0dHdoG9LTxF4HyI9uj	2026-06-08 02:36:35.667842+00	2026-06-08 18:02:34.346+00	f
91ae52bb-13bb-45da-9828-e62fa56a6ce3	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Jessica Diaz	\N	4022906120	\N	CmaPYwiVdbzW6ZTGCmuabMA7	2026-06-08 02:36:34.468933+00	2026-06-08 17:01:54.556+00	f
f93ebcc0-7d5b-4387-987d-494ba5c04937	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Adrian Conde	\N	531-225-7005	\N	tpb49G22aMnfZaiavx2R2pVD	2026-06-08 02:36:36.949472+00	2026-06-10 02:38:25.713+00	f
ab8b93be-4778-4a1d-b83b-cdc8fb116707	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Lisa Espinosa	\N	4029992600	\N	sKcvcigN/ogrcrlw5ffJ6/pf	2026-06-14 23:20:07.798387+00	2026-06-15 15:10:57.418+00	f
38d7a42f-6da9-4458-9e33-5de51ea9022d	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Tirzah Corbin	\N	6084124014	\N	jPkA0WgtRh2qqtQe05HEqG7H	2026-06-15 19:08:21.260571+00	2026-06-15 19:09:53.532+00	f
c2da937c-44f2-48d5-a7a2-2e950fafccb4	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Alma Hauz	\N	(402) 968-4098	\N	bBo0tfwXNQIFJMoB/TozKoQy	2026-06-14 18:30:04.605245+00	2026-06-19 19:16:18.242+00	f
e6a7d814-64ba-4119-8311-933ffd77b108	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Melissa Novotny	\N	4026796544	\N	FlyUFwPTtO+5wC6Gik2IliCQ	2026-05-26 18:57:28.608426+00	2026-06-03 06:25:33.963+00	t
fc6e555b-f918-4f29-8ffe-6479052e7429	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	BW Jos Whe Kersaint	\N	(347) 417-0691	\N	sVvYpceTVgytgcNtwIsDg3qo	2026-06-22 03:05:56.797183+00	2026-06-22 03:16:14.561+00	f
b57cc74c-8298-4f7c-9324-88f17b498626	00000000-0000-0000-0000-000000000001	c3160a24-000a-46b0-811b-ffe22e265981	Lenora Clark	\N	3144201702	\N	pFQPFhTQ9vu7eFwe0BTua9Xk	2026-06-22 10:15:04.913092+00	2026-06-27 00:53:49.224+00	f
3bba124a-7497-4a69-87b3-cbacf527f9e6	00000000-0000-0000-0000-000000000001	c3160a24-000a-46b0-811b-ffe22e265981	Robin Droz	\N	402740672	\N	Y16r4VInmp1rDU8cLdnWQGMg	2026-06-26 17:34:49.342901+00	2026-06-27 00:54:27.491+00	f
729998ad-4b8a-403d-9ab4-444f5bead9c2	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	BW Sister Rodriguez	\N	(402) 973-8878	\N	nEsyHJyI/ZXFXGa2QpqwhL2B	2026-06-21 17:25:03.119032+00	2026-06-27 00:55:04.393+00	f
46b36072-ef6e-44ae-ad13-a7f392523936	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Gussie Sorensen	\N	402-830-7297	\N	WtkaHNQQOhnrlUPts6qqlcYu	2026-06-03 00:11:08.359633+00	2026-06-03 00:29:32.916+00	f
68b0c944-4f3b-4f20-bb2d-d1285da455c5	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Corina Davis	\N	4029068910	\N	jJYqFoKpupqyKgB6RiXGoHHj	2026-06-04 09:09:40.398031+00	2026-06-04 09:10:13.478+00	f
a2f1f4e1-fc1d-4f54-b9d5-5e512d5811bb	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Carol Getzman	\N	(402) 598-3926	\N	hq8UOxUbeIR2n54HkaMj068N	2026-06-03 07:47:36.719075+00	2026-06-03 08:00:13.253+00	f
7a059a42-93dc-4db3-b09e-35ac38faa16b	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	LeAnn & Kris Bennett	\N	(402) 838-0063	\N	7jUa0yAoZhpnCGmyl+ygBcqR	2026-06-03 08:06:08.282701+00	2026-06-03 08:06:33.177+00	f
19c33e90-fbf3-4807-b72c-ec0cc490cb58	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Nona & JC Pittman	\N	402-616-2229	\N	6jE9zGB0UKFD1B3IiSV64YPA	2026-06-03 00:11:08.722298+00	2026-06-03 00:29:28.09+00	f
cb6d87a9-80c5-4a9b-89d8-18946eda068e	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Kayleen Wilwerding	\N	(402) 689-5440	\N	+qd6an8aN26XWbnYacgXTbFg	2026-06-04 09:09:39.842186+00	2026-06-04 09:10:22.054+00	f
16134594-b954-470f-b6e0-8c1ef53127bc	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Jamie Agena	\N	\N	\N	c/yaGUBnErtAQDUl+afu8Avc	2026-06-04 09:17:34.592558+00	2026-06-04 09:17:47.066+00	f
69e84f35-db1a-433d-b8ab-5e825bd9d5de	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Tina Santana	\N	+1 402-657-7364	\N	u+kUVvHmDiAhjW9PrHVbQMb8	2026-05-23 02:43:08.601714+00	2026-06-03 07:07:11.783+00	f
1294c193-e185-479a-88f0-07ccd464d0b1	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Brenda Lucas	\N	4028045102	\N	7mVdDP+KVL8QfeFE1GqTth3E	2026-05-23 02:43:08.930547+00	2026-06-03 07:07:14.964+00	f
e6e0f567-29c4-4825-a644-cc364f60f142	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Gloria J Groves	\N	4026707566	\N	LxmklyWF415zWzzw2NyGw7/e	2026-06-04 01:26:32.23236+00	2026-06-04 08:55:43.317+00	f
7d793d63-ac3b-4b57-aad7-405caf22efc5	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Donna Sopcich	\N	(402) 321-0959	\N	wExtPSGmWetFkoj8spM5fXqR	2026-05-23 02:42:34.948922+00	2026-06-03 07:06:35.084+00	f
d7430524-20af-47b8-b1e5-089840f33bf4	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Andres Gutierrez	\N	4026376187	\N	8I8lF4j9R9ZsThvx4R54EEke	2026-06-08 02:36:33.352965+00	2026-06-08 03:03:59.15+00	f
f2922705-44be-4faa-9e85-f2c659ebafe4	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Kiara Sadler	\N	402-297-6765	\N	djXHCP5jujSdi554SB+x2whe	2026-06-08 02:36:36.420233+00	2026-06-08 19:03:44.388+00	f
386ddfb3-f3f1-4acc-94ae-15fb50668d26	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Rick & Maddie Madrid	\N	5623264395	\N	JGzGFJX5G7iiyltAALewHZgW	2026-06-08 02:36:35.922036+00	2026-06-08 23:33:10.75+00	f
d608dc93-e9eb-4e6d-aa9b-9ae9cf001217	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	MarVella Gomez	\N	5312036157	\N	6T5eLUWhkTcAwCMP3GyjPOXG	2026-06-08 02:36:34.71154+00	2026-06-08 17:23:59.548+00	f
d2daac95-45b3-4339-89a3-f36b0c383f1c	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Joel Buhr	\N	(402) 639-8137	\N	JBKHQPpo6++Q343t8Zuk6bti	2026-06-14 18:30:05.068645+00	2026-06-14 18:30:39.962+00	f
f2022a82-48f8-4717-b20f-6351c01f9a04	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Valeria Gonzalez	\N	(531) 333-1773	\N	kCat+ucmOhgdxhYhCIjrzNnU	2026-06-14 23:20:08.040462+00	2026-06-15 14:20:48.154+00	f
cba27266-6184-4d67-b526-7270728511b3	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Alexa Sigala	\N	(531) 352-0753	\N	xXi9M+u50tzxG9eqQ+gPIF+M	2026-06-15 19:09:27.579146+00	\N	f
899c9fe5-6c60-4e8a-85b0-767b0420d790	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Norma Biomagnitism	\N	(402) 601-9619	\N	Jqh3qmpH2ET9186c3sqbbz6A	2026-06-04 09:13:32.832059+00	2026-06-04 09:13:43.956+00	f
6c5d709a-3ab1-41a1-a0fe-2c75d526edfa	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Sofia Barios	\N	(402) 804-6923	\N	k0iXzXEVGIE+z00JcTDFWUgM	2026-06-14 18:35:26.461234+00	2026-06-19 19:16:09.826+00	f
f55e10f3-592a-4526-bef6-00558aedeb1f	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Steven & Denise Madsen	\N	(402) 714 1491	\N	fRitcPJqZVlomIssMbLm0ZTC	2026-05-22 22:02:12.095954+00	2026-06-03 07:02:38.965+00	f
bce49578-39a8-4b6a-9be3-a70703b03350	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Deisy Baker	\N	(310) 619-3331	\N	qgLL+8TJdpkCwzJOaL7RZwWG	2026-06-22 03:16:53.899936+00	2026-06-27 00:55:25.833+00	f
094485ad-96b4-4d9d-8439-4bc504eab541	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Stace Hamon	\N	402-206-4236	\N	wTcrjgYFJDEVsOmhUlcenq1w	2026-06-03 00:11:08.858496+00	2026-06-03 00:29:26.208+00	f
c36d9e42-8279-4a45-9794-76820013c789	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Dubie and Rodger Meyer	\N	(402) 598-3244	\N	nBktcSL/XA9gQ/jr85cJUziD	2026-06-03 08:06:08.418829+00	2026-06-03 08:06:30.18+00	f
e82f513b-65db-4fdc-ac8d-1fdd02ff7dcb	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Lois Piccolo	\N	(402) 490-2204	\N	EH94A2CXYOOeDX0nH8QNuUkg	2026-06-04 09:09:39.991472+00	2026-06-04 09:10:19.661+00	f
017b51c9-d53a-42ae-bc9b-1dac3990b853	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Makayla McClellan	\N	\N	\N	0BOH2avIhgIh3ZBAQwEy31PD	2026-06-04 09:17:34.699436+00	2026-06-04 09:17:44.376+00	f
9162717e-da0f-4113-9d8a-b6c0467f409c	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Stephanie Hathaway	\N	\N	\N	UIF9Zsl6qhsHorjvyONjLyMt	2026-06-04 09:17:33.980485+00	2026-06-04 09:17:54.326+00	f
8f69da10-b12f-4c6d-9af3-5dde24445053	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Katie Calderon	\N	402-505-1526	\N	o6nAQM4/1W2JSvZ828MvznY9	2026-06-08 02:36:36.0993+00	2026-06-08 19:01:11.934+00	f
e64d3665-bae2-4081-b704-0ec4fc3fc22c	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Mark Eldridge	\N	(402) 968-4767	\N	Qi4moaFR32pRv7CUjT//BJya	2026-06-14 18:30:05.391489+00	2026-06-14 18:30:37.524+00	f
e3d2376d-1e1c-4426-8891-9cc17ebdec79	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Liza Efigenio	\N	4025157916	\N	apQ8KfYL2UVXAV1cudNSLEnQ	2026-06-14 23:17:45.291807+00	2026-06-14 23:22:21.592+00	f
53a35d77-95bf-48e4-8305-3fb5beeacd8d	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Mia Marquez	\N	531-333-9489	\N	Ed6lxZ1KAqcDtm8hcRW/KrXf	2026-06-08 02:36:34.969808+00	2026-06-15 14:24:29.409+00	f
1c1b1447-01a5-4821-90d8-282037142a8e	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Shadna Jaisaree	\N	6479079782	\N	pf23AUwNPRxphBTUDbeU8Xs2	2026-06-04 11:10:17.436667+00	2026-06-06 02:03:34.202+00	f
4b7436b1-ef27-4a96-8e4c-afa80fb1c768	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Kenda Andersen	\N	(402) 296-9922	\N	n4pt3rY2nrD++/uXBQWZOpRT	2026-06-03 12:59:42.937268+00	2026-06-03 13:44:57.505+00	t
13db7e7a-1b73-43cb-b531-6ccc0a3885c3	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Fanny Villarreal	\N	402-981-7594	\N	sIbu+ZcQfy5f90oGzktTfNf5	2026-06-08 02:36:36.569858+00	2026-06-17 13:51:05.625+00	f
e325e7a9-6c95-4be4-9aad-622e428408df	00000000-0000-0000-0000-000000000001	c3160a24-000a-46b0-811b-ffe22e265981	Shelley Monaghan	\N	4026394513	\N	LqZe6BjpuNT+T/8xj9CNMNNN	2026-06-14 21:16:27.028789+00	2026-06-19 19:16:05.058+00	f
2bf8fce4-c2d3-4152-904d-9dc2e820d412	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Adrianna Marie Gonzalez	\N	4028076980	\N	etSmUCSv+izal0ec9PHljg7Q	2026-06-08 02:36:33.958688+00	2026-06-08 13:58:52.118+00	f
d6cb152b-d5c2-4207-aa31-66ea08655620	00000000-0000-0000-0000-000000000001	c3160a24-000a-46b0-811b-ffe22e265981	Cynthia Futo	\N	3146406836	\N	eXtnNHWHPDCLuKF4AEWB0269	2026-06-16 21:24:53.31544+00	2026-06-27 00:53:38.978+00	f
7d18e116-f92e-4971-8af4-199de909e009	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Caleb Morgan	\N	(402) 618-9036	\N	i43dyzDD6e9EAw/awRQdEO/l	2026-06-03 07:47:36.85646+00	2026-06-03 07:59:22.766+00	f
e224d5be-5bd2-4022-87e0-33a8c816f6bc	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Cari Clifford	\N	(402) 681-7443	\N	byGS9giexpuIhfH27kX0yb/f	2026-06-22 03:16:54.168856+00	2026-06-27 00:55:14.118+00	f
0eb32b2d-6b36-415e-b348-c9a3e2bc7866	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	NE Teri Crohn	\N	(402) 738-0706	\N	bwK6IbKteU/utf8UHs2nsppe	2026-06-21 19:32:04.852153+00	2026-06-27 00:56:22.869+00	f
81128660-21d0-46e9-9db3-27c01ab59bfd	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Jaki Schreck	\N	402-734-4113	\N	vd5OVUu9/tLgqbXeNdo3L1eB	2026-06-03 00:11:09.006847+00	2026-06-03 00:29:19.035+00	f
e81897ee-1695-49c3-bdbb-b209e8efc249	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Jenny Fuentes	\N	402-860-2103	\N	TFlGEKo++XC8xL+A5E9XVMMT	2026-06-08 02:36:34.241149+00	2026-06-08 14:01:22.778+00	f
909f367e-52e9-4a8c-bea7-e0f1dafca821	00000000-0000-0000-0000-000000000001	c3160a24-000a-46b0-811b-ffe22e265981	Maxine Damazio	\N	13478476743	\N	bF/dbGRNWfYNbDP9/WFjfn1L	2026-06-17 13:17:06.382621+00	\N	f
552622d6-702f-4f48-95ef-0ca823dfe537	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Hortencia Jaimes	\N	531-444-8758	\N	/H0Twwt+aTn8AmFkgHHpmE5M	2026-06-08 02:36:36.736912+00	2026-06-17 13:51:06.883+00	f
168d264c-c7c1-4aee-852f-ad43e3577ac3	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Jessica Scherer	\N	402-968-2232	\N	ik+1qHLvsWDhw487CD9k1OwK	2026-06-03 00:11:08.482883+00	2026-06-03 00:29:29.641+00	f
88242dd0-f566-4140-92fa-f33a1c5f1cc9	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Celia Trisler	\N	316-213-5563	\N	p4PbQDttGvj4li1dRFSAw1a3	2026-06-03 00:11:07.560472+00	2026-06-03 00:29:43.607+00	f
93967261-e333-4a48-86bc-1d57354fdb5e	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Rosalba Martinez	\N	402-482-4990	\N	lkJ9Hum1wUXaPDgDnYxpu9Ve	2026-06-08 02:36:35.428861+00	2026-06-08 19:44:55.974+00	f
d4d1dd12-40da-4acb-8b3f-ef7c0d887c40	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Aletta Blair	\N	4029991213	\N	gnZaxAOLOvy/XwS4aMCkuO7+	2026-06-03 00:21:29.823753+00	2026-06-03 00:29:17.195+00	f
fa164673-7fcd-4cd9-b9df-a52c6ded47ba	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Teresa Drake	\N	4023213146	\N	R1PK04s87c1t+DmoV5ppRE3B	2026-05-22 22:02:12.231033+00	2026-06-03 06:27:17.017+00	t
2131586e-e938-4b39-8432-de169c4e019d	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Kenneth Moore	\N	(402) 305-8962	\N	dGq5lLdWTtfU8bbOe4uEuoLr	2026-06-14 18:30:05.521808+00	2026-06-14 18:30:44.343+00	f
72cd545e-220c-4cc1-9ff1-bb22053ad4e7	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Jamy Elker	\N	4022033905	\N	/+ZVNbd5xAgVS31fT1KbOZkF	2026-06-02 02:51:54.122145+00	2026-06-03 06:25:37.967+00	f
729d17e3-47d2-4f57-970a-930d7d714288	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Isa Miranda	\N	(402) 709-4402	\N	m58WXJc97pA8eDwD+4M1hwiR	2026-06-14 23:17:45.439871+00	2026-06-14 23:20:52.321+00	f
8093ced3-db48-41fe-87d5-b236ee7a8acc	00000000-0000-0000-0000-000000000001	e7619554-8bc3-4576-916d-2d46229702f4	Dayana Kennerson	\N	402) 415-3172	\N	VY8JRvElzEiYwYv78mgFPcAO	2026-06-15 19:08:21.056392+00	2026-06-15 21:42:14.718+00	f
f7dd9e4f-c40a-4887-9f46-cd2823e8bc15	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Phyllis Andrews	\N	402-298-1447	\N	CCpimGnjTkavCYMpj7K8yPL1	2026-06-03 00:21:30.241221+00	2026-06-03 00:29:14.69+00	f
ea74a45e-a8f3-4ee7-9c20-6bf2dcad2f99	00000000-0000-0000-0000-000000000001	c3160a24-000a-46b0-811b-ffe22e265981	MICHELLE SHAUGER	\N	989-430-1979	\N	K5ngx5vjjKVYEjTQ9AvDN9xV	2026-06-14 21:49:35.81796+00	2026-06-19 19:16:01.263+00	f
0a04ea4a-4bca-4adf-afa9-519b47c62233	00000000-0000-0000-0000-000000000001	c3160a24-000a-46b0-811b-ffe22e265981	Abraham Rodriguez	\N	7076289800	\N	6Xf6u/YcN67tmQm6TGq8LR+k	2026-06-08 16:53:11.633065+00	2026-06-19 19:16:33.95+00	f
8a30cef1-f3c0-41fd-a93a-83d73d34f09b	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Ms Dixie L. Frahm	\N	4029795214	\N	xaoSXWDvYm54iVC8I/Iiweef	2026-06-03 08:06:08.546062+00	2026-06-03 08:06:25.858+00	f
7b1cc978-2cd5-4f6b-a5ad-d5af36dc4cd4	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Sasha E From Togo	\N	(531) 772-1590	\N	lhxYH1Ey02N2IqaeFHID4/En	2026-06-03 07:22:26.757929+00	2026-06-03 07:22:49.769+00	f
b87c2782-8d91-4b8e-b09a-8416db51ccd7	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Alina Martinez	\N	(773) 820-2727	\N	aJVtF3JHrU0mszGzcSsvg371	2026-06-03 07:47:36.992022+00	2026-06-03 07:59:20.333+00	f
b52452c4-37a5-4596-9664-e32651d0657d	00000000-0000-0000-0000-000000000001	d386b116-f1ec-44fd-954b-800248f2f623	Cheri & Jim Payson	\N	303-808-4350	\N	QAa7UYd7VzpGnksPjFYKEbd1	2026-06-03 00:11:07.967254+00	2026-06-03 00:29:41.247+00	f
849b87e2-1375-4201-8c4b-038bfe60434c	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Alita Pitmam	\N	(402) 612-6204	\N	dfvlrjVIRyg+z6Eljm80x+xt	2026-06-04 09:09:40.137133+00	2026-06-04 09:10:17.016+00	f
85a47d39-d559-426f-9cfa-7bb337b69efc	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Sandy Sutton	\N	\N	\N	DDolOhT6bNwE1Gi5fOlUUvNo	2026-06-04 09:17:34.253218+00	2026-06-04 09:17:51.943+00	f
3b7252eb-41be-4ae6-adc5-992b8fbfbf4b	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	GeGe Spradling	\N	(903) 573-0947	\N	IOnBurM485nO5B+qQ+r8amNT	2026-06-22 03:16:54.315724+00	2026-06-22 03:17:40.349+00	f
e616d5f5-43ba-435a-8020-f71ec58f1bda	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Kari Gray	\N	8082787562	\N	nE9L0GE9yZqpvDQLI4seEuDK	2026-05-26 08:14:27.849843+00	2026-06-03 06:27:36.321+00	f
782f8752-1d48-4ef8-878e-e2637d65138a	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Gina Rae Filer	\N	(402) 812-7437	\N	qW2EzfOitHlh7qPgS8XYO1Kj	2026-06-03 00:33:27.753105+00	2026-06-03 07:11:14.016+00	f
b838e492-8634-440d-84fa-fec1f63ab858	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Mari Elva & Hugo Uribe	\N	+1 402-214-3570	\N	Il7aEG+twS9UuNlS/kv2AKba	2026-05-22 22:02:11.005322+00	2026-06-03 07:01:53.055+00	f
2d1f587c-26a7-4491-a2a0-cafce4556d7b	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Jay & Ronda Wilcher	\N	4028508379	\N	ushuC9myESKB6C5zFgKxcafk	2026-05-26 18:57:27.490386+00	2026-06-03 06:25:24.244+00	t
0a3a06dd-d5cd-4b3f-8252-9bb3f214967b	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Betsaida Ruiz	\N	4022539229	\N	KErGmvzZE0PUQechdPC4b7L9	2026-05-26 18:57:28.47348+00	2026-05-30 13:44:51.596+00	t
5caa4514-9306-40de-bb6e-424cfcae0e4e	00000000-0000-0000-0000-000000000001	00651c0f-c5e3-45b1-8979-960f3f752c74	Dee Sallis	\N	4022136518	\N	MtzyWjqwBxOwxujSSBipym66	2026-05-22 22:02:10.348336+00	2026-06-03 06:26:18.013+00	t
\.


--
-- Data for Name: inviters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."inviters" ("id", "name", "quota", "active", "created_at", "host_id", "email", "phone", "requested_quota", "quota_request_note", "quota_requested_at") FROM stdin;
428f6f14-e64f-47b6-826c-c51c9ab9ff7b	Dixie Frahm	20	t	2026-06-17 16:55:44.39525+00	f90abc4a-6ba0-434c-a825-e287bb6414bb	\N	14029795214	\N	\N	\N
3955977d-facd-4626-9e64-38b2153b9c97	Jamie Elker	0	t	2026-06-02 02:09:01.699204+00	\N	\N	(402) 203-3905	\N	\N	\N
9fed6a58-142a-4200-8b68-c5c8ef83a40c	Melissa Novotny	25	t	2026-06-03 00:07:04.865016+00	d386b116-f1ec-44fd-954b-800248f2f623	\N	4026796544	\N	\N	\N
57b0dfd6-df25-49b9-99a4-281327906032	Jay Wilcher	0	t	2026-06-06 01:52:48.327389+00	\N	\N	(402) 850-8379	\N	\N	\N
bcb466aa-60e0-4ae0-b03d-ca25f4a2226e	Kenda Andersen	0	t	2026-06-17 04:48:22.485042+00	\N	\N	(402) 296-9922	\N	\N	\N
262317f9-4128-4673-b6da-7cd471ce2b89	Saul Morro	0	t	2026-06-20 01:54:32.821268+00	\N	\N	+1531-484-5553	\N	\N	\N
9cb64685-bbbb-4754-bde9-ceb6d4d7625c	Dewinica Salis	0	t	2026-06-06 01:52:48.327389+00	\N	\N	+1 402-213-6518	\N	\N	\N
626e6d8e-3905-46ed-993e-a304d4f03656	Jacquelyn Spears	0	t	2026-06-06 01:52:48.327389+00	\N	\N	417.592.3238	\N	\N	\N
a33966a3-bf12-4e3b-b2e4-f0eb05101784	Jen Spears	0	t	2026-06-06 01:52:48.327389+00	\N	\N	8082504081	\N	\N	\N
d31b6df7-9483-4bec-b77f-62bd1bd27a78	Michelle Shawger	0	t	2026-06-06 01:52:48.327389+00	\N	\N	+1 989-430-1979	\N	\N	\N
aa0d37b1-444c-4394-8e31-9bd56d6bb3a4	Teresa Drake	0	t	2026-06-06 01:52:48.327389+00	\N	\N	(402) 321-3146	\N	\N	\N
744179c5-d9cd-4d96-9c60-05b5f92cfca4	Rhonda Wilcher	40	t	2026-06-06 02:51:01.244548+00	\N	\N	402-681-9826	\N	\N	\N
f3b98ecf-a2c8-47c5-b823-99ea872168d4	Kari Gray	52	t	2026-05-23 06:36:44.013972+00	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	\N	\N	\N	\N
9afdc998-343c-458b-b09d-1a6853c5d612	Andres Rosa Guiterrez	40	t	2026-06-14 22:44:38.593296+00	\N	\N	(402) 637-6187	\N	\N	\N
41e8e332-e564-442f-80bb-1f1cb661de6c	Tianna Stoddard	40	t	2026-06-14 22:48:45.172821+00	\N	\N	4022028845	\N	\N	\N
d2debe23-35dc-4c00-a56e-42568d3d749d	Rosa Gutiérrez	40	t	2026-06-14 22:54:58.675936+00	\N	\N	(402) 672-5048	\N	\N	\N
f9e0d1cf-3e98-4109-97df-2aea9fc2e9de	Betsaida Ruiz	3	t	2026-06-06 01:52:48.327389+00	\N	\N	4022539229	\N	\N	\N
cab6cc14-e06b-4ed8-961a-69bc51e07f2a	Shelley & Pat Monahan	40	t	2026-06-06 01:52:48.327389+00	\N	\N	+1 402-639-4513	\N	\N	\N
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."menu_items" ("id", "restaurant_id", "name", "description", "price", "category", "dietary_flags", "available", "created_at") FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."orders" ("id", "invitation_id", "restaurant_id", "items", "total", "notes", "created_at") FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."profiles" ("id", "email", "display_name", "avatar_url", "created_at") FROM stdin;
c3160a24-000a-46b0-811b-ffe22e265981	kgray623@gmail.com	kgray623	\N	2026-05-16 02:23:43.462556+00
e50bc6ab-4bcc-48ea-b3a4-6154c97c10b2	jesus@gmail.com	Jesus	\N	2026-05-21 04:11:06.765693+00
ee84b666-ae07-439a-ba0a-68a4053c23dc	livingprevention@gmail.com	Kari E. Gray	\N	2026-05-21 18:36:06.328937+00
e9e84923-a9bd-4cd3-ad5c-0daf7c05abb3	bust_a_move_@hotmail.com	Jacquelyn Spears	\N	2026-05-21 03:47:25.762994+00
00651c0f-c5e3-45b1-8979-960f3f752c74	\N	Kari Gray	\N	2026-05-26 20:43:26.425875+00
d321e808-0d90-4336-b0d5-baee6f158bcb	\N	Jacquelyn Spears	\N	2026-06-02 00:39:41.055367+00
c9b87cf9-b5b2-486f-a343-6fd8b3a94f05	\N	Jamy Elker	\N	2026-06-02 02:51:53.573385+00
d386b116-f1ec-44fd-954b-800248f2f623	\N	Melissa Novotne	\N	2026-06-02 03:00:31.959845+00
3ad4ed0e-1651-44da-8083-8a52554f28a0	\N	Gina Rae Filer	\N	2026-06-03 00:33:27.457245+00
e7619554-8bc3-4576-916d-2d46229702f4	\N	Betsaida Ruiz	\N	2026-06-03 01:26:58.088067+00
8eb96ee4-3243-4b73-afa1-3c7f8bc1008c	\N	Aletta Blair	\N	2026-06-03 01:51:02.432948+00
2b5fd7fc-be65-4bbd-a6a5-6f21bb32649b	\N	Kenda Andersen	\N	2026-06-03 12:59:42.412275+00
3ae2ee45-d209-44aa-9c3f-0eeccc2cec36	\N	Brenda Lucas	\N	2026-06-03 14:42:43.103483+00
f79320c6-c570-4587-ba2e-10d81c6f7320	\N	Gloria J Groves	\N	2026-06-04 01:26:31.888978+00
27e72530-ee81-4e44-86af-ed3d3eb37f7c	\N	Steven&Denise Madsen	\N	2026-06-04 02:47:08.052186+00
b16a5001-a978-4b21-bea8-9b27fe677133	\N	Shadna Jaisaree	\N	2026-06-04 11:10:16.959074+00
bca9db99-76a2-40d0-be10-fc3cec21ea4c	\N	Tiana Stoddard	\N	2026-06-04 17:02:28.691635+00
15397971-1357-45b3-9e65-5b3837146ac1	\N	Donna Sopcich	\N	2026-06-05 21:06:15.08439+00
90699da6-66f7-4f45-960c-58437e90364d	\N	S. Carmen De La Cruz	\N	2026-06-06 02:15:51.537974+00
33204d68-91a9-421e-9b1d-2b2724ef530e	\N	Corina Davis	\N	2026-06-06 12:20:24.254054+00
7e578c20-8e68-4f51-a37b-86a94c062baf	\N	Andres Gutierrez	\N	2026-06-08 02:52:47.431556+00
f90abc4a-6ba0-434c-a825-e287bb6414bb	\N	MsDixie L. Frahm	\N	2026-06-08 14:19:29.43149+00
c0ad1647-e168-48de-a681-f1eb4394b962	\N	Abraham Rodriguez	\N	2026-06-08 16:53:11.321244+00
1bb0f886-acc3-45fb-9630-3a18e2abba7f	\N	Jessica Diaz	\N	2026-06-08 20:26:45.658203+00
01f0111e-6448-4c05-8fda-612397e7d468	\N	Rick & Maddie Madrid	\N	2026-06-09 03:43:28.806035+00
dec85c95-bb02-454d-9d46-b32d7a686fc1	\N	MarVella Gomez	\N	2026-06-13 00:22:51.956158+00
2bb6d8c2-f152-442e-978a-ead28f0a281b	phone-4023213146@tasteofconventions.local	Teresa Drake	\N	2026-06-14 20:59:38.936178+00
1720962d-279d-4c1b-a2b3-456c023ec982	phone-14026394513@tasteofconventions.local	Shelley & Pat Monahan	\N	2026-06-14 21:04:54.917497+00
aa89ad74-dd21-4bf8-91a1-9ff7168feec9	\N	MICHELLE SHAUGER	\N	2026-06-14 21:49:35.436386+00
3379c93c-6524-4b81-b2cb-b751c94b64e1	phone-4026725048@tasteofconventions.local	Rosa Gutiérrez	\N	2026-06-14 23:01:42.664947+00
bcb24518-1a2f-4069-8b5f-b221b7b4756c	\N	Liza Efigenio	\N	2026-06-15 02:20:11.977872+00
17b38ad2-4ed5-4313-9313-9a3a2f80f102	\N	Lisa Espinosa	\N	2026-06-15 17:28:17.028291+00
5cbf8604-d2a3-42fe-8cc1-26df7f538019	\N	Cynthia Futo	\N	2026-06-16 21:24:52.68237+00
7ddc9cef-5e30-4246-ae91-0c633f550119	\N	Maxine Damazio	\N	2026-06-17 13:17:05.957755+00
8ea8ab67-d110-402d-94a6-6482eb08f692	\N	Tirzah Corbin	\N	2026-06-18 17:10:32.899546+00
ace15320-adf7-43f1-873c-3b86afea210e	\N	Lenora Clark	\N	2026-06-22 10:15:04.490443+00
792d7129-1efe-4617-bc48-d4a3b7d43530	\N	Jay & Ronda Wilcher	\N	2026-06-23 03:36:57.372104+00
c35729d1-326d-43bc-a66b-c0d3bde91cf0	\N	Dee Sallis	\N	2026-06-26 04:21:36.559728+00
c734fcf2-254a-4d9f-a8bd-7a6b04858af4	phone-4027406722@tasteofconventions.local	Robn Droz	\N	2026-06-26 16:22:18.561995+00
bc4566e5-a976-4c54-9fb6-9fbf32c1a273	\N	Adrianna Marie Gonzalez	\N	2026-06-26 23:57:08.533318+00
\.


--
-- Data for Name: restaurants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."restaurants" ("id", "name", "description", "cuisine", "image_url", "active", "created_at") FROM stdin;
e300d630-12bd-454b-941e-e2b03c62c129	Sakura House	Hand-rolled sushi and small plates from Tokyo.	Japanese	\N	t	2026-05-15 01:12:30.090444+00
a520c3b2-fcf7-4ddf-be8f-f6c72cb4cef7	Olive & Vine	Mediterranean shared plates and wood-fired flatbreads.	Mediterranean	\N	t	2026-05-15 01:12:30.090444+00
941a034e-47b9-4fa2-87eb-99a41fc2c1d8	Casa Verde	Modern plant-forward kitchen with bold spices.	Vegetarian	\N	t	2026-05-15 01:12:30.090444+00
1ccd27de-968d-4dae-8918-bb4bcfd43111	Again Burmese Restaurant	Burmese restaurantoffering noodles, samosas, and curries.	Myanmar	\N	t	2026-05-15 01:12:30.090444+00
\.


--
-- Data for Name: rsvps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."rsvps" ("id", "invitation_id", "status", "party_size", "dietary_notes", "message", "responded_at", "created_at", "invited_by", "attendance_mode", "ordering_food") FROM stdin;
3fd25c8d-7716-46df-a6c4-8d481d67b6d7	ab8b93be-4778-4a1d-b83b-cdc8fb116707	yes	1	\N	\N	2026-06-15 17:28:44.611+00	2026-06-15 17:28:17.917726+00	Jamie Elker	in_person	t
370b294c-94b6-4a5c-a263-269084d2420b	f2022a82-48f8-4717-b20f-6351c01f9a04	no	1	\N	\N	2026-06-15 19:34:21.356+00	2026-06-15 19:34:22.186918+00	\N	in_person	\N
9f4db587-0f48-4f1c-8d0d-689140eb5a70	1c1b1447-01a5-4821-90d8-282037142a8e	yes	1	\N	\N	2026-06-16 20:10:02.454+00	2026-06-04 11:10:18.267805+00	Kari Gray	zoom	\N
853e950b-79cb-4ced-b20b-a075a75268e0	d6cb152b-d5c2-4207-aa31-66ea08655620	yes	1	\N	\N	2026-06-16 21:24:53.796+00	2026-06-16 21:24:53.86066+00	Kari Gray	in_person	f
8c5172bf-6204-49b9-aa47-4b2f2b07f6ba	e616d5f5-43ba-435a-8020-f71ec58f1bda	yes	1		\N	2026-05-27 02:47:07.459+00	2026-05-26 08:14:28.884794+00	Kari Gray	in_person	t
c184affb-6c0e-45b7-9e06-10e131342c7f	d6228d2f-7dbd-44cc-bb4e-11b9078ae229	yes	1	\N	\N	2026-06-02 00:39:41.809+00	2026-06-02 00:39:41.852681+00	Kari Gray	zoom	\N
4692d274-e153-46ce-979f-2681ea011302	58fd842a-ab6f-43d2-8bd2-a553bebdef49	no	1	\N	\N	2026-06-17 04:44:24.765+00	2026-06-17 04:44:26.487573+00	\N	in_person	\N
d88ab826-27f9-40c9-baab-06f2333b37aa	e6a7d814-64ba-4119-8311-933ffd77b108	yes	1	\N	\N	2026-06-02 03:00:32.57+00	2026-06-02 03:00:32.620688+00	Kari Gray	in_person	t
6954ec4f-3386-4895-99d7-dcbeda0c7edc	909f367e-52e9-4a8c-bea7-e0f1dafca821	yes	1	\N	\N	2026-06-17 13:17:06.778+00	2026-06-17 13:17:06.809032+00	Jacquelyn Spears	zoom	\N
d7601c52-4d50-4919-be19-f38f5f244e1e	38d7a42f-6da9-4458-9e33-5de51ea9022d	yes	2	\N	\N	2026-06-18 17:10:33.531+00	2026-06-18 17:10:33.601449+00	Betsaida Ruiz	in_person	t
1588aea6-f1cf-4bb5-9487-274d2e1c382e	782f8752-1d48-4ef8-878e-e2637d65138a	yes	1	\N	\N	2026-06-03 00:33:28.049+00	2026-06-03 00:33:28.090832+00	Melissa Novotne	in_person	t
85c65964-e338-4096-9580-fcc8af4c5ae4	0a3a06dd-d5cd-4b3f-8252-9bb3f214967b	yes	2	\N	\N	2026-06-03 01:26:59.487+00	2026-06-03 01:26:59.560921+00	Kari Gray	in_person	t
2e2106af-f9e3-4317-87ee-10fa8acf418a	2c6f69b0-ce65-483c-9d72-2b817ead263b	no	1	\N	\N	2026-06-03 14:18:26.027+00	2026-06-03 14:18:26.75722+00	\N	in_person	\N
8974e40c-0a19-4c9c-819c-b8101af45b46	b57bf811-0321-4417-8ff7-892b0a753fcd	no	1	\N	\N	2026-06-03 14:18:38.02+00	2026-06-03 14:18:38.398346+00	\N	in_person	\N
0a8340c6-a830-48d3-8294-382ba576bebd	1294c193-e185-479a-88f0-07ccd464d0b1	yes	2	\N	\N	2026-06-03 14:42:44.512+00	2026-06-03 14:42:44.623669+00	Kari Gray	in_person	t
a22a30bb-23cd-4967-a440-a5e3c16cb0ba	f55e10f3-592a-4526-bef6-00558aedeb1f	yes	2	\N	\N	2026-06-04 02:47:09.128+00	2026-06-04 02:47:09.175946+00	Kari Gray	in_person	t
5a8ede71-18a3-440d-9323-339078ad683d	e64d3665-bae2-4081-b704-0ec4fc3fc22c	no	1	\N	\N	2026-06-18 17:28:05.947+00	2026-06-18 17:28:06.407681+00	\N	in_person	\N
2b901481-ee91-47a7-9d09-4069c933e907	4b7436b1-ef27-4a96-8e4c-afa80fb1c768	yes	1	\N	\N	2026-06-04 08:56:19.679+00	2026-06-03 12:59:43.568277+00	Kari Gray	in_person	t
61dfba19-337d-41d1-b0b7-09145ebc5e88	b87c2782-8d91-4b8e-b09a-8416db51ccd7	no	1	\N	\N	2026-06-04 09:10:44.635+00	2026-06-03 17:02:55.080236+00	\N	in_person	\N
3192248b-0ef5-41f8-bd7c-16245d107191	7d793d63-ac3b-4b57-aad7-405caf22efc5	yes	1	\N	\N	2026-06-05 21:06:16.002+00	2026-06-05 21:06:16.05267+00	Kari Gray	in_person	f
5a35e521-f842-487f-b532-192c6a372c2b	fa164673-7fcd-4cd9-b9df-a52c6ded47ba	yes	1	\N	\N	2026-06-19 02:02:20.513+00	2026-06-19 02:02:20.577425+00	Kari Gray	in_person	f
b59b4099-f0ec-4783-a620-b49ae095b8ee	5a73b19b-305b-4d23-87cb-2e64e64b5b86	no	1	\N	\N	2026-06-19 19:17:47.066+00	2026-06-19 19:17:49.123236+00	\N	in_person	\N
41e43fb0-4449-4aa4-a11f-0af99fd2e616	569ed7ad-2c9f-4d4a-883a-6501b4ae6e35	yes	1	\N	\N	2026-06-06 02:15:52.666+00	2026-06-06 02:15:52.728645+00	Jacquelyn Spears	in_person	t
2391eaca-76a5-4eaa-b036-f440f8c702c4	12fbbc43-8bb9-4479-9180-98650229e369	yes	1	\N	\N	2026-06-06 02:30:17.01+00	2026-06-04 17:02:29.528655+00	Kari Gray	in_person	f
d16102b8-b862-41dc-b198-b9894dbbd0f0	e6e0f567-29c4-4825-a644-cc364f60f142	yes	2	\N	\N	2026-06-06 02:30:25.802+00	2026-06-04 01:26:32.688837+00	Kari Gray	in_person	t
4f3aeaa5-0359-4cb4-af4c-2f60b404a47b	68b0c944-4f3b-4f20-bb2d-d1285da455c5	yes	1	\N	\N	2026-06-06 12:20:25.25+00	2026-06-06 12:20:25.274388+00	Kari Gray	zoom	\N
0ce31db2-af36-4e7f-b8c2-3c64e621fa57	d7430524-20af-47b8-b1e5-089840f33bf4	yes	3	\N	\N	2026-06-08 02:52:48.584+00	2026-06-08 02:52:48.667828+00	Betsaida Ruiz	in_person	f
564a5805-86ec-4ecc-b079-e79996d49c41	8a30cef1-f3c0-41fd-a93a-83d73d34f09b	yes	1	\N	\N	2026-06-08 14:20:05.435+00	2026-06-08 14:19:30.529259+00	Kari Gray	in_person	t
16e34418-40f3-48cd-996a-d8123867d423	0a04ea4a-4bca-4adf-afa9-519b47c62233	yes	2	\N	\N	2026-06-08 16:53:29.787+00	2026-06-08 16:53:12.012381+00	Jennifer Fuentes	in_person	f
87aac43b-26a3-4f60-b67c-87f23fd39975	91ae52bb-13bb-45da-9828-e62fa56a6ce3	yes	1	\N	\N	2026-06-08 20:26:46.287+00	2026-06-08 20:26:46.335498+00	Betsaida Ruiz	zoom	\N
0f44988a-68ba-43d6-a825-405238e84be4	f7dd9e4f-c40a-4887-9f46-cd2823e8bc15	no	1	\N	\N	2026-06-08 21:57:03.999+00	2026-06-08 21:57:04.269454+00	\N	in_person	\N
3f20f1d7-a990-4e11-9bda-45113e0f1537	d4d1dd12-40da-4acb-8b3f-ef7c0d887c40	yes	1	\N	\N	2026-06-08 21:58:47.28+00	2026-06-08 21:58:47.323883+00	Melissa Novotne	in_person	t
45a232bb-8ad6-41e3-9e2b-9cc26f094060	386ddfb3-f3f1-4acc-94ae-15fb50668d26	yes	2	\N	\N	2026-06-09 03:48:04.56+00	2026-06-09 03:43:29.657484+00	Betsaida Ruiz	in_person	t
b1d167c7-9cd8-49bc-8063-5d89b603b061	d608dc93-e9eb-4e6d-aa9b-9ae9cf001217	yes	3	\N	\N	2026-06-13 00:22:52.612+00	2026-06-13 00:22:52.652244+00	Betsaida Ruiz	in_person	f
e154e20c-466f-43a7-9c9b-6f8d4b1fdf4b	d2daac95-45b3-4339-89a3-f36b0c383f1c	no	1	\N	\N	2026-06-14 18:31:17.306+00	2026-06-14 18:31:17.534337+00	\N	in_person	\N
f9528d75-6b86-47f2-adc6-4e7d79989f53	85a47d39-d559-426f-9cfa-7bb337b69efc	no	1	\N	\N	2026-06-14 18:31:58.51+00	2026-06-14 18:31:58.718299+00	\N	in_person	\N
37d17da6-b283-46ad-810d-461a7ae151f3	a14af6c5-8ba6-45f8-9684-3b107b4d93f4	no	1	\N	\N	2026-06-14 18:33:29.27+00	2026-06-14 18:33:29.83733+00	\N	in_person	\N
a1d9038b-e758-45c4-b7b2-b870187d0f7b	fa86baf9-06a9-4b9f-acac-049b7572c7f6	no	1	\N	\N	2026-06-14 18:33:33.379+00	2026-06-14 18:33:33.625509+00	\N	in_person	\N
07e39d60-d650-4ba2-a032-d7787de73d14	2131586e-e938-4b39-8432-de169c4e019d	no	1	\N	\N	2026-06-14 20:42:56.679+00	2026-06-14 20:42:57.089001+00	\N	in_person	\N
04accb63-6d8a-4a47-b0ee-c502c5a8ded7	e325e7a9-6c95-4be4-9aad-622e428408df	yes	2	\N	\N	2026-06-14 21:16:27.414+00	2026-06-14 21:16:27.442639+00	Kari Gray	in_person	f
7e680c9d-25eb-4d44-9874-ac42dac18f87	72cd545e-220c-4cc1-9ff1-bb22053ad4e7	yes	2	\N	\N	2026-06-14 21:25:07.884+00	2026-06-02 02:51:54.96984+00	Kari Gray	in_person	f
30fccfa7-5609-404d-8339-89813ea220b8	ea74a45e-a8f3-4ee7-9c20-6bf2dcad2f99	yes	1	\N	\N	2026-06-14 21:49:36.165+00	2026-06-14 21:49:36.211909+00	Kari Gray	in_person	f
fa2dbca2-e96d-43e5-93cf-2924f677d25f	e3d2376d-1e1c-4426-8891-9cc17ebdec79	yes	3	\N	\N	2026-06-15 02:20:12.586+00	2026-06-15 02:20:12.61719+00	Betsaida Ruiz	in_person	t
3724ef19-afeb-4a27-9511-90c673e90c46	b57cc74c-8298-4f7c-9324-88f17b498626	yes	1	\N	\N	2026-06-22 10:15:18.204+00	2026-06-22 10:15:05.311914+00	Jacquelyn Spears	zoom	\N
42e60333-e354-4949-b5a7-0be39f74872d	2d1f587c-26a7-4491-a2a0-cafce4556d7b	yes	2	\N	\N	2026-06-23 03:36:58.892+00	2026-06-23 03:36:58.916295+00	Jay Wilcher	in_person	f
26cbe26b-8e5a-497c-b6cf-b13cec58a104	5caa4514-9306-40de-bb6e-424cfcae0e4e	yes	1	\N	\N	2026-06-26 04:21:37.596+00	2026-06-26 04:21:37.618174+00	Kari Gray	in_person	t
b07d054a-fe9c-47f7-9a57-2f1f57fd21dc	3bba124a-7497-4a69-87b3-cbacf527f9e6	no	2	\N	\N	2026-06-26 17:34:49.704+00	2026-06-26 17:34:49.771317+00	Kari Gray	in_person	\N
e3708336-2f79-4c5f-a982-a66015647ca4	2bf8fce4-c2d3-4152-904d-9dc2e820d412	yes	2	\N	\N	2026-06-26 23:57:09.158+00	2026-06-26 23:57:09.194132+00	Betsaida Ruiz	in_person	t
\.


--
-- Data for Name: suppressed_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."suppressed_emails" ("id", "email", "reason", "metadata", "created_at") FROM stdin;
\.


--
-- Data for Name: team_invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."team_invites" ("id", "email", "role", "invited_by", "accepted_at", "created_at", "name", "phone", "phone_normalized") FROM stdin;
48f79d7b-a16e-41e7-83eb-a8941d0de0f8	\N	team	00651c0f-c5e3-45b1-8979-960f3f752c74	2026-06-02 02:51:53.573385+00	2026-06-02 02:09:04.0191+00	Jamie Elker	(402) 203-3905	4022033905
18687c18-a898-4d13-acb4-b8e1c68b8ce6	\N	team	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	2026-06-02 03:52:03.086165+00	Jen Spears	8082504081	8082504081
87839e53-19c7-49e6-8665-c065dfb9edc0	\N	team	00651c0f-c5e3-45b1-8979-960f3f752c74	2026-06-02 03:57:41.023+00	2026-06-02 03:53:19.583506+00	Jacquelyn Spears	417.592.3238	4175923238
22d96d90-2894-42fd-bcf7-8841e1b8b468	\N	team	00651c0f-c5e3-45b1-8979-960f3f752c74	\N	2026-06-06 02:51:01.244548+00	Rhonda Wilcher	402-681-9826	4026819826
1046cd3e-e73a-43ee-a8d1-fe5320bef642	\N	team	00651c0f-c5e3-45b1-8979-960f3f752c74	2026-06-14 22:55:54.021+00	2026-06-14 22:44:38.424373+00	Andres Rosa Guiterrez	(402) 637-6187	4026376187
fe911f8c-bbc8-4d30-a892-91b907573730	\N	team	00651c0f-c5e3-45b1-8979-960f3f752c74	2026-06-14 23:01:42.664947+00	2026-06-14 22:54:58.436406+00	Rosa Gutiérrez	(402) 672-5048	4026725048
8b5589dc-081d-4eb3-bd34-520ba644c575	\N	team	00651c0f-c5e3-45b1-8979-960f3f752c74	2026-06-15 22:56:14.561361+00	2026-06-14 22:48:45.014418+00	Tianna Stoddard	4022028845	4022028845
\.


--
-- Data for Name: team_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."team_messages" ("id", "user_id", "body", "created_at") FROM stdin;
6f98b3ed-cc41-4286-82e7-58300e104764	ee84b666-ae07-439a-ba0a-68a4053c23dc	Hi	2026-05-24 05:50:50.580097+00
ed04c3a6-2556-4e00-9fd7-09f04f006eca	00651c0f-c5e3-45b1-8979-960f3f752c74	Thank you for being here!	2026-05-27 17:51:24.442223+00
cca20bfb-8217-4884-8792-433e1ed4d9f1	d321e808-0d90-4336-b0d5-baee6f158bcb	Thank you!	2026-06-02 04:18:32.043026+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."user_roles" ("id", "user_id", "role") FROM stdin;
64ca2f94-906f-44bc-a068-7231e9adffb0	c3160a24-000a-46b0-811b-ffe22e265981	host
69fb1f4b-e3e9-40ef-8e2e-4d9ead12a48c	e9e84923-a9bd-4cd3-ad5c-0daf7c05abb3	host
40572844-3da6-4af2-88bc-32af89ea9758	e50bc6ab-4bcc-48ea-b3a4-6154c97c10b2	host
8caef9ad-41ac-4ae5-aeee-3d9b090ec109	ee84b666-ae07-439a-ba0a-68a4053c23dc	host
33c635ed-6119-4bcd-a72d-83bf99b7d2a9	00651c0f-c5e3-45b1-8979-960f3f752c74	host
f38601d9-387f-4241-b12b-3157e6909e33	00651c0f-c5e3-45b1-8979-960f3f752c74	admin
5e8a45a0-ecee-4212-9943-be05739d182f	00651c0f-c5e3-45b1-8979-960f3f752c74	team
ac716d6c-7f8a-494b-8fcf-cf0bb95e5052	d321e808-0d90-4336-b0d5-baee6f158bcb	host
da31398c-6d56-4b01-bc4a-3ece8f35b92d	c9b87cf9-b5b2-486f-a343-6fd8b3a94f05	team
77324839-b838-4c8a-af26-cbc9cc1d9db6	c9b87cf9-b5b2-486f-a343-6fd8b3a94f05	host
3e45009d-59a5-4225-915d-eceb4d597aaf	d386b116-f1ec-44fd-954b-800248f2f623	host
7e9fe9de-d7d1-4dd4-a3dc-ba5be4cc0cb4	d386b116-f1ec-44fd-954b-800248f2f623	team
db9473b5-0671-4bcf-b1f3-54561a11ebec	d321e808-0d90-4336-b0d5-baee6f158bcb	team
19c91105-2946-4839-8375-7e3253e141b3	3ad4ed0e-1651-44da-8083-8a52554f28a0	host
f13b6b0b-a5e5-427e-9456-bb6f73d05d1f	e7619554-8bc3-4576-916d-2d46229702f4	host
17d65a9e-d26e-49fd-8dba-f38b56ccde39	e7619554-8bc3-4576-916d-2d46229702f4	team
bee3fe3a-13aa-4e2a-b585-3e44b9d8cb00	8eb96ee4-3243-4b73-afa1-3c7f8bc1008c	host
21df3805-aa1d-4313-8d73-ba026a207427	2b5fd7fc-be65-4bbd-a6a5-6f21bb32649b	host
0ebf0178-02f6-418a-be2a-2ecc1d518cf6	3ae2ee45-d209-44aa-9c3f-0eeccc2cec36	host
48d515be-e3ec-43ac-ab2e-2509b9283f91	f79320c6-c570-4587-ba2e-10d81c6f7320	host
c7463a5a-9868-42a6-be9f-91986aa3adf7	27e72530-ee81-4e44-86af-ed3d3eb37f7c	host
4d212a5f-bc74-45f3-baa3-94251283573b	b16a5001-a978-4b21-bea8-9b27fe677133	host
60ca037c-4b64-4759-8579-8d930d0ba480	bca9db99-76a2-40d0-be10-fc3cec21ea4c	host
4b20a39b-2892-46e4-8caa-8993d6a986cc	15397971-1357-45b3-9e65-5b3837146ac1	host
a7352ed8-5d2a-467b-9600-bf4a03f97af6	90699da6-66f7-4f45-960c-58437e90364d	host
f65ee9d4-0075-4e59-9085-bac5a8d27e73	33204d68-91a9-421e-9b1d-2b2724ef530e	host
ec4a713b-e950-4db0-ad15-ab497f7ff910	7e578c20-8e68-4f51-a37b-86a94c062baf	host
146ce655-ff4a-4afd-a8c7-eb069814a3a5	f90abc4a-6ba0-434c-a825-e287bb6414bb	host
e4c2d4f3-b5ab-47e0-abd4-c55a3ae1b643	c0ad1647-e168-48de-a681-f1eb4394b962	host
70f2c069-e88f-4ead-bb51-48961d251315	1bb0f886-acc3-45fb-9630-3a18e2abba7f	host
e5b12512-7a03-4f7d-9ac0-a75593382dbf	01f0111e-6448-4c05-8fda-612397e7d468	host
7a8e04b1-49b0-48ca-a010-a1b423907f1f	dec85c95-bb02-454d-9d46-b32d7a686fc1	host
c58d3f03-be93-47f8-bc32-a23257d12d35	2bb6d8c2-f152-442e-978a-ead28f0a281b	host
48bb1a6a-3a3c-477c-9752-914bef39259d	2bb6d8c2-f152-442e-978a-ead28f0a281b	team
c7530c2d-5acc-4f67-8de7-95d2bbf848fa	1720962d-279d-4c1b-a2b3-456c023ec982	host
d9519475-78d3-4cee-ac53-4572cba38304	1720962d-279d-4c1b-a2b3-456c023ec982	team
659cff42-9b68-4258-a106-fe682cd12905	aa89ad74-dd21-4bf8-91a1-9ff7168feec9	host
40440102-c4b9-49d3-a691-71029936f14e	7e578c20-8e68-4f51-a37b-86a94c062baf	team
c2d943aa-d3ca-4707-b504-2044d74c7117	3379c93c-6524-4b81-b2cb-b751c94b64e1	team
4030d4b1-6681-4dd7-a941-db3a533d492c	3379c93c-6524-4b81-b2cb-b751c94b64e1	host
0b331aa7-5afe-43d0-8876-1936a7e2c8a9	bcb24518-1a2f-4069-8b5f-b221b7b4756c	host
00785be6-d2ac-4125-b1cd-d3abffb2e27f	17b38ad2-4ed5-4313-9313-9a3a2f80f102	host
9788d81e-9f87-4aea-ba64-1d4f268fa930	bca9db99-76a2-40d0-be10-fc3cec21ea4c	team
be44daf6-05a7-4fda-8b4d-710c3dfb353f	aa89ad74-dd21-4bf8-91a1-9ff7168feec9	team
8eff1899-43d4-4a13-acbc-7ddf1acb7e49	5cbf8604-d2a3-42fe-8cc1-26df7f538019	host
db47ab9d-ae99-4877-b3cc-8347430b3aca	7ddc9cef-5e30-4246-ae91-0c633f550119	host
f05d39fb-df92-484b-bcf0-4888dffed4e3	f90abc4a-6ba0-434c-a825-e287bb6414bb	team
686ed5e8-b387-4c9d-9cc0-cdd5d3fc0c3f	8ea8ab67-d110-402d-94a6-6482eb08f692	host
9eac0c4f-0f04-4385-b538-d1b9c1f00ecb	ace15320-adf7-43f1-873c-3b86afea210e	host
ce05934f-8347-45f0-9494-73c4f1efe21b	792d7129-1efe-4617-bc48-d4a3b7d43530	host
3dcbda6a-080f-4712-9f3a-cd0e545e2b16	c35729d1-326d-43bc-a66b-c0d3bde91cf0	host
2ec4066e-de39-4239-b480-d8579b8eec2c	c35729d1-326d-43bc-a66b-c0d3bde91cf0	team
6552b927-91cd-4520-bd7e-47638a48c143	c734fcf2-254a-4d9f-a8bd-7a6b04858af4	host
a4237517-d761-4435-92e5-006e12f21334	bc4566e5-a976-4c54-9fb6-9fbf32c1a273	host
\.


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."audit_log"
    ADD CONSTRAINT "audit_log_pkey" PRIMARY KEY ("id");


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."categories"
    ADD CONSTRAINT "categories_name_key" UNIQUE ("name");


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."categories"
    ADD CONSTRAINT "categories_pkey" PRIMARY KEY ("id");


--
-- Name: category_assignments category_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."category_assignments"
    ADD CONSTRAINT "category_assignments_pkey" PRIMARY KEY ("id");


--
-- Name: category_messages category_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."category_messages"
    ADD CONSTRAINT "category_messages_pkey" PRIMARY KEY ("id");


--
-- Name: chat_last_seen chat_last_seen_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."chat_last_seen"
    ADD CONSTRAINT "chat_last_seen_pkey" PRIMARY KEY ("user_id", "chat_kind", "chat_id");


--
-- Name: cuisine_preorders cuisine_preorders_invitation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cuisine_preorders"
    ADD CONSTRAINT "cuisine_preorders_invitation_id_key" UNIQUE ("invitation_id");


--
-- Name: cuisine_preorders cuisine_preorders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cuisine_preorders"
    ADD CONSTRAINT "cuisine_preorders_pkey" PRIMARY KEY ("id");


--
-- Name: deleted_rows_archive deleted_rows_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."deleted_rows_archive"
    ADD CONSTRAINT "deleted_rows_archive_pkey" PRIMARY KEY ("id");


--
-- Name: donations_summary donations_summary_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."donations_summary"
    ADD CONSTRAINT "donations_summary_pkey" PRIMARY KEY ("id");


--
-- Name: duplicate_flags duplicate_flags_invitation_a_invitation_b_match_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."duplicate_flags"
    ADD CONSTRAINT "duplicate_flags_invitation_a_invitation_b_match_type_key" UNIQUE ("invitation_a", "invitation_b", "match_type");


--
-- Name: duplicate_flags duplicate_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."duplicate_flags"
    ADD CONSTRAINT "duplicate_flags_pkey" PRIMARY KEY ("id");


--
-- Name: email_send_log email_send_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."email_send_log"
    ADD CONSTRAINT "email_send_log_pkey" PRIMARY KEY ("id");


--
-- Name: email_send_state email_send_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."email_send_state"
    ADD CONSTRAINT "email_send_state_pkey" PRIMARY KEY ("id");


--
-- Name: email_unsubscribe_tokens email_unsubscribe_tokens_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."email_unsubscribe_tokens"
    ADD CONSTRAINT "email_unsubscribe_tokens_email_key" UNIQUE ("email");


--
-- Name: email_unsubscribe_tokens email_unsubscribe_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."email_unsubscribe_tokens"
    ADD CONSTRAINT "email_unsubscribe_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: email_unsubscribe_tokens email_unsubscribe_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."email_unsubscribe_tokens"
    ADD CONSTRAINT "email_unsubscribe_tokens_token_key" UNIQUE ("token");


--
-- Name: entertainment_submissions entertainment_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."entertainment_submissions"
    ADD CONSTRAINT "entertainment_submissions_pkey" PRIMARY KEY ("id");


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."events"
    ADD CONSTRAINT "events_pkey" PRIMARY KEY ("id");


--
-- Name: guest_messages guest_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."guest_messages"
    ADD CONSTRAINT "guest_messages_pkey" PRIMARY KEY ("id");


--
-- Name: invitation_content invitation_content_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."invitation_content"
    ADD CONSTRAINT "invitation_content_pkey" PRIMARY KEY ("id");


--
-- Name: invitation_content invitation_content_singleton_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."invitation_content"
    ADD CONSTRAINT "invitation_content_singleton_key" UNIQUE ("singleton");


--
-- Name: invitations invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."invitations"
    ADD CONSTRAINT "invitations_pkey" PRIMARY KEY ("id");


--
-- Name: invitations invitations_rsvp_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."invitations"
    ADD CONSTRAINT "invitations_rsvp_token_key" UNIQUE ("rsvp_token");


--
-- Name: inviters inviters_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."inviters"
    ADD CONSTRAINT "inviters_name_key" UNIQUE ("name");


--
-- Name: inviters inviters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."inviters"
    ADD CONSTRAINT "inviters_pkey" PRIMARY KEY ("id");


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."menu_items"
    ADD CONSTRAINT "menu_items_pkey" PRIMARY KEY ("id");


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("id");


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");


--
-- Name: restaurants restaurants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."restaurants"
    ADD CONSTRAINT "restaurants_pkey" PRIMARY KEY ("id");


--
-- Name: rsvps rsvps_invitation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."rsvps"
    ADD CONSTRAINT "rsvps_invitation_id_key" UNIQUE ("invitation_id");


--
-- Name: rsvps rsvps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."rsvps"
    ADD CONSTRAINT "rsvps_pkey" PRIMARY KEY ("id");


--
-- Name: suppressed_emails suppressed_emails_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."suppressed_emails"
    ADD CONSTRAINT "suppressed_emails_email_key" UNIQUE ("email");


--
-- Name: suppressed_emails suppressed_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."suppressed_emails"
    ADD CONSTRAINT "suppressed_emails_pkey" PRIMARY KEY ("id");


--
-- Name: team_invites team_invites_email_normalized_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."team_invites"
    ADD CONSTRAINT "team_invites_email_normalized_key" UNIQUE ("email_normalized");


--
-- Name: team_invites team_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."team_invites"
    ADD CONSTRAINT "team_invites_pkey" PRIMARY KEY ("id");


--
-- Name: team_messages team_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."team_messages"
    ADD CONSTRAINT "team_messages_pkey" PRIMARY KEY ("id");


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."user_roles"
    ADD CONSTRAINT "user_roles_pkey" PRIMARY KEY ("id");


--
-- Name: user_roles user_roles_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."user_roles"
    ADD CONSTRAINT "user_roles_user_id_role_key" UNIQUE ("user_id", "role");


--
-- Name: audit_log_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_log_action_idx" ON "public"."audit_log" USING "btree" ("action");


--
-- Name: audit_log_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_log_created_at_idx" ON "public"."audit_log" USING "btree" ("created_at" DESC);


--
-- Name: audit_log_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_log_phone_idx" ON "public"."audit_log" USING "btree" ("phone_normalized");


--
-- Name: audit_log_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_log_user_id_idx" ON "public"."audit_log" USING "btree" ("user_id");


--
-- Name: deleted_rows_archive_table_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "deleted_rows_archive_table_idx" ON "public"."deleted_rows_archive" USING "btree" ("table_name", "deleted_at" DESC);


--
-- Name: idx_category_messages_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_category_messages_category" ON "public"."category_messages" USING "btree" ("category_id", "created_at");


--
-- Name: idx_cuisine_preorders_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_cuisine_preorders_created_at" ON "public"."cuisine_preorders" USING "btree" ("created_at" DESC);


--
-- Name: idx_cuisine_preorders_invitation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_cuisine_preorders_invitation_id" ON "public"."cuisine_preorders" USING "btree" ("invitation_id");


--
-- Name: idx_email_send_log_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_email_send_log_created" ON "public"."email_send_log" USING "btree" ("created_at" DESC);


--
-- Name: idx_email_send_log_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_email_send_log_message" ON "public"."email_send_log" USING "btree" ("message_id");


--
-- Name: idx_email_send_log_message_sent_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "idx_email_send_log_message_sent_unique" ON "public"."email_send_log" USING "btree" ("message_id") WHERE ("status" = 'sent'::"text");


--
-- Name: idx_email_send_log_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_email_send_log_recipient" ON "public"."email_send_log" USING "btree" ("recipient_email");


--
-- Name: idx_guest_messages_invitation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_guest_messages_invitation" ON "public"."guest_messages" USING "btree" ("invitation_id", "created_at");


--
-- Name: idx_invitations_is_committee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_invitations_is_committee" ON "public"."invitations" USING "btree" ("is_committee") WHERE ("is_committee" = true);


--
-- Name: idx_rsvps_invited_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_rsvps_invited_by" ON "public"."rsvps" USING "btree" ("invited_by") WHERE ("invited_by" IS NOT NULL);


--
-- Name: idx_suppressed_emails_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_suppressed_emails_email" ON "public"."suppressed_emails" USING "btree" ("email");


--
-- Name: idx_unsubscribe_tokens_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_unsubscribe_tokens_token" ON "public"."email_unsubscribe_tokens" USING "btree" ("token");


--
-- Name: invitations_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invitations_email_idx" ON "public"."invitations" USING "btree" ("event_id", "guest_email_normalized");


--
-- Name: invitations_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invitations_phone_idx" ON "public"."invitations" USING "btree" ("event_id", "guest_phone_normalized");


--
-- Name: inviters_host_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "inviters_host_id_idx" ON "public"."inviters" USING "btree" ("host_id");


--
-- Name: team_invites_phone_normalized_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "team_invites_phone_normalized_idx" ON "public"."team_invites" USING "btree" ("phone_normalized") WHERE ("accepted_at" IS NULL);


--
-- Name: category_assignments audit_category_assignments; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_category_assignments" AFTER INSERT OR DELETE OR UPDATE ON "public"."category_assignments" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: category_messages audit_category_messages; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_category_messages" AFTER INSERT OR DELETE OR UPDATE ON "public"."category_messages" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: cuisine_preorders audit_cuisine_preorders; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_cuisine_preorders" AFTER INSERT OR DELETE OR UPDATE ON "public"."cuisine_preorders" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: entertainment_submissions audit_entertainment_submissions; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_entertainment_submissions" AFTER INSERT OR DELETE OR UPDATE ON "public"."entertainment_submissions" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: guest_messages audit_guest_messages; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_guest_messages" AFTER INSERT OR DELETE OR UPDATE ON "public"."guest_messages" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: invitations audit_invitations; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_invitations" AFTER INSERT OR DELETE OR UPDATE ON "public"."invitations" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: inviters audit_inviters; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_inviters" AFTER INSERT OR DELETE OR UPDATE ON "public"."inviters" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: rsvps audit_rsvps; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_rsvps" AFTER INSERT OR DELETE OR UPDATE ON "public"."rsvps" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: team_invites audit_team_invites; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_team_invites" AFTER INSERT OR DELETE OR UPDATE ON "public"."team_invites" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: team_messages audit_team_messages; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_team_messages" AFTER INSERT OR DELETE OR UPDATE ON "public"."team_messages" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: user_roles audit_user_roles; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "audit_user_roles" AFTER INSERT OR DELETE OR UPDATE ON "public"."user_roles" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: invitations invitations_dupe_check; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "invitations_dupe_check" AFTER INSERT OR UPDATE ON "public"."invitations" FOR EACH ROW EXECUTE FUNCTION "public"."detect_duplicate_invitations"();


--
-- Name: cuisine_preorders set_cuisine_preorders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "set_cuisine_preorders_updated_at" BEFORE UPDATE ON "public"."cuisine_preorders" FOR EACH ROW EXECUTE FUNCTION "public"."set_cuisine_preorders_updated_at"();


--
-- Name: team_invites team_invites_set_phone_normalized; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "team_invites_set_phone_normalized" BEFORE INSERT OR UPDATE OF "phone" ON "public"."team_invites" FOR EACH ROW EXECUTE FUNCTION "public"."set_team_invite_phone_normalized"();


--
-- Name: cuisine_preorders trg_archive_cuisine_preorders_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_archive_cuisine_preorders_delete" BEFORE DELETE ON "public"."cuisine_preorders" FOR EACH ROW EXECUTE FUNCTION "public"."archive_deleted_row"();


--
-- Name: invitations trg_archive_invitations_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_archive_invitations_delete" BEFORE DELETE ON "public"."invitations" FOR EACH ROW EXECUTE FUNCTION "public"."archive_deleted_row"();


--
-- Name: inviters trg_archive_inviters_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_archive_inviters_delete" BEFORE DELETE ON "public"."inviters" FOR EACH ROW EXECUTE FUNCTION "public"."archive_deleted_row"();


--
-- Name: rsvps trg_archive_rsvps_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_archive_rsvps_delete" BEFORE DELETE ON "public"."rsvps" FOR EACH ROW EXECUTE FUNCTION "public"."archive_deleted_row"();


--
-- Name: team_invites trg_archive_team_invites_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_archive_team_invites_delete" BEFORE DELETE ON "public"."team_invites" FOR EACH ROW EXECUTE FUNCTION "public"."archive_deleted_row"();


--
-- Name: cuisine_preorders trg_audit_cuisine_preorders_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_cuisine_preorders_change" AFTER INSERT OR DELETE OR UPDATE ON "public"."cuisine_preorders" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: invitations trg_audit_invitations_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_invitations_change" AFTER INSERT OR DELETE OR UPDATE ON "public"."invitations" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: inviters trg_audit_inviters_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_inviters_change" AFTER INSERT OR DELETE OR UPDATE ON "public"."inviters" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: rsvps trg_audit_rsvps_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_rsvps_change" AFTER INSERT OR DELETE OR UPDATE ON "public"."rsvps" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: team_invites trg_audit_team_invites_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "trg_audit_team_invites_change" AFTER INSERT OR DELETE OR UPDATE ON "public"."team_invites" FOR EACH ROW EXECUTE FUNCTION "public"."audit_row_change"();


--
-- Name: category_assignments category_assignments_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."category_assignments"
    ADD CONSTRAINT "category_assignments_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id") ON DELETE CASCADE;


--
-- Name: category_messages category_messages_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."category_messages"
    ADD CONSTRAINT "category_messages_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "public"."categories"("id") ON DELETE CASCADE;


--
-- Name: chat_last_seen chat_last_seen_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."chat_last_seen"
    ADD CONSTRAINT "chat_last_seen_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: cuisine_preorders cuisine_preorders_invitation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."cuisine_preorders"
    ADD CONSTRAINT "cuisine_preorders_invitation_id_fkey" FOREIGN KEY ("invitation_id") REFERENCES "public"."invitations"("id") ON DELETE CASCADE;


--
-- Name: duplicate_flags duplicate_flags_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."duplicate_flags"
    ADD CONSTRAINT "duplicate_flags_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE CASCADE;


--
-- Name: duplicate_flags duplicate_flags_invitation_a_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."duplicate_flags"
    ADD CONSTRAINT "duplicate_flags_invitation_a_fkey" FOREIGN KEY ("invitation_a") REFERENCES "public"."invitations"("id") ON DELETE CASCADE;


--
-- Name: duplicate_flags duplicate_flags_invitation_b_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."duplicate_flags"
    ADD CONSTRAINT "duplicate_flags_invitation_b_fkey" FOREIGN KEY ("invitation_b") REFERENCES "public"."invitations"("id") ON DELETE CASCADE;


--
-- Name: events events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."events"
    ADD CONSTRAINT "events_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id") ON DELETE SET NULL;


--
-- Name: invitations invitations_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."invitations"
    ADD CONSTRAINT "invitations_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE CASCADE;


--
-- Name: invitations invitations_host_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."invitations"
    ADD CONSTRAINT "invitations_host_id_fkey" FOREIGN KEY ("host_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: menu_items menu_items_restaurant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."menu_items"
    ADD CONSTRAINT "menu_items_restaurant_id_fkey" FOREIGN KEY ("restaurant_id") REFERENCES "public"."restaurants"("id") ON DELETE CASCADE;


--
-- Name: orders orders_invitation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_invitation_id_fkey" FOREIGN KEY ("invitation_id") REFERENCES "public"."invitations"("id") ON DELETE CASCADE;


--
-- Name: orders orders_restaurant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_restaurant_id_fkey" FOREIGN KEY ("restaurant_id") REFERENCES "public"."restaurants"("id");


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: rsvps rsvps_invitation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."rsvps"
    ADD CONSTRAINT "rsvps_invitation_id_fkey" FOREIGN KEY ("invitation_id") REFERENCES "public"."invitations"("id") ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."user_roles"
    ADD CONSTRAINT "user_roles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: email_send_log Service role can insert send log; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can insert send log" ON "public"."email_send_log" FOR INSERT WITH CHECK (("auth"."role"() = 'service_role'::"text"));


--
-- Name: suppressed_emails Service role can insert suppressed emails; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can insert suppressed emails" ON "public"."suppressed_emails" FOR INSERT WITH CHECK (("auth"."role"() = 'service_role'::"text"));


--
-- Name: email_unsubscribe_tokens Service role can insert tokens; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can insert tokens" ON "public"."email_unsubscribe_tokens" FOR INSERT WITH CHECK (("auth"."role"() = 'service_role'::"text"));


--
-- Name: email_send_state Service role can manage send state; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can manage send state" ON "public"."email_send_state" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));


--
-- Name: email_unsubscribe_tokens Service role can mark tokens as used; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can mark tokens as used" ON "public"."email_unsubscribe_tokens" FOR UPDATE USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));


--
-- Name: email_send_log Service role can read send log; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can read send log" ON "public"."email_send_log" FOR SELECT USING (("auth"."role"() = 'service_role'::"text"));


--
-- Name: suppressed_emails Service role can read suppressed emails; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can read suppressed emails" ON "public"."suppressed_emails" FOR SELECT USING (("auth"."role"() = 'service_role'::"text"));


--
-- Name: email_unsubscribe_tokens Service role can read tokens; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can read tokens" ON "public"."email_unsubscribe_tokens" FOR SELECT USING (("auth"."role"() = 'service_role'::"text"));


--
-- Name: email_send_log Service role can update send log; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role can update send log" ON "public"."email_send_log" FOR UPDATE USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));


--
-- Name: cuisine_preorders admin or team delete cuisine preorders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admin or team delete cuisine preorders" ON "public"."cuisine_preorders" FOR DELETE TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: inviters admin or team manage inviters; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admin or team manage inviters" ON "public"."inviters" TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role"))) WITH CHECK (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: entertainment_submissions admin or team reads entertainment; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admin or team reads entertainment" ON "public"."entertainment_submissions" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: guest_messages admins create host replies; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins create host replies" ON "public"."guest_messages" FOR INSERT TO "authenticated" WITH CHECK ((("sender" = 'admin'::"text") AND ("user_id" = "auth"."uid"()) AND "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: deleted_rows_archive admins delete archive; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins delete archive" ON "public"."deleted_rows_archive" FOR DELETE TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: category_assignments admins manage assignments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage assignments" ON "public"."category_assignments" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: categories admins manage categories; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage categories" ON "public"."categories" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: donations_summary admins manage donations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage donations" ON "public"."donations_summary" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: invitation_content admins manage invitation_content; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage invitation_content" ON "public"."invitation_content" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: team_invites admins manage invites; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage invites" ON "public"."team_invites" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: menu_items admins manage menu; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage menu" ON "public"."menu_items" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: orders admins manage orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage orders" ON "public"."orders" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: restaurants admins manage restaurants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage restaurants" ON "public"."restaurants" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: user_roles admins manage roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage roles" ON "public"."user_roles" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: rsvps admins manage rsvps; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins manage rsvps" ON "public"."rsvps" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: deleted_rows_archive admins read archive; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins read archive" ON "public"."deleted_rows_archive" FOR SELECT TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: audit_log admins read audit_log; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins read audit_log" ON "public"."audit_log" FOR SELECT TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: cuisine_preorders admins read cuisine preorders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins read cuisine preorders" ON "public"."cuisine_preorders" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: guest_messages admins read guest messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins read guest messages" ON "public"."guest_messages" FOR SELECT TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: guest_messages admins update read flags; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admins update read flags" ON "public"."guest_messages" FOR UPDATE TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role"));


--
-- Name: cuisine_preorders anyone can submit cuisine preorder; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "anyone can submit cuisine preorder" ON "public"."cuisine_preorders" FOR INSERT TO "authenticated", "anon" WITH CHECK (((("char_length"("name") >= 1) AND ("char_length"("name") <= 120)) AND (("char_length"("phone") >= 1) AND ("char_length"("phone") <= 40)) AND ("jsonb_typeof"("selections") = 'array'::"text")));


--
-- Name: entertainment_submissions anyone can submit entertainment; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "anyone can submit entertainment" ON "public"."entertainment_submissions" FOR INSERT TO "authenticated", "anon" WITH CHECK ((("video_path" ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\.[A-Za-z0-9]+$'::"text") AND (("char_length"("name") >= 1) AND ("char_length"("name") <= 120)) AND (("email" IS NULL) OR ("char_length"("email") <= 200)) AND (("phone" IS NULL) OR ("char_length"("phone") <= 40)) AND (("talent" IS NULL) OR ("char_length"("talent") <= 200)) AND (("notes" IS NULL) OR ("char_length"("notes") <= 2000))));


--
-- Name: category_assignments assignments readable by admin or team; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "assignments readable by admin or team" ON "public"."category_assignments" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."audit_log" ENABLE ROW LEVEL SECURITY;

--
-- Name: events authenticated create events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "authenticated create events" ON "public"."events" FOR INSERT TO "authenticated" WITH CHECK (("auth"."uid"() = "created_by"));


--
-- Name: team_messages author or admin deletes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "author or admin deletes" ON "public"."team_messages" FOR DELETE TO "authenticated" USING ((("auth"."uid"() = "user_id") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: category_messages author or admin deletes category messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "author or admin deletes category messages" ON "public"."category_messages" FOR DELETE TO "authenticated" USING ((("auth"."uid"() = "user_id") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."categories" ENABLE ROW LEVEL SECURITY;

--
-- Name: categories categories readable by all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "categories readable by all" ON "public"."categories" FOR SELECT TO "authenticated", "anon" USING (true);


--
-- Name: categories categories readable by authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "categories readable by authenticated" ON "public"."categories" FOR SELECT TO "authenticated" USING (true);


--
-- Name: category_messages category chat readable by volunteers admin or team; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "category chat readable by volunteers admin or team" ON "public"."category_messages" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role") OR (EXISTS ( SELECT 1
   FROM "public"."category_assignments" "a"
  WHERE (("a"."category_id" = "category_messages"."category_id") AND ("a"."user_id" = "auth"."uid"()))))));


--
-- Name: category_assignments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."category_assignments" ENABLE ROW LEVEL SECURITY;

--
-- Name: category_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."category_messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_last_seen; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."chat_last_seen" ENABLE ROW LEVEL SECURITY;

--
-- Name: events creators or admins delete events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "creators or admins delete events" ON "public"."events" FOR DELETE TO "authenticated" USING ((("auth"."uid"() = "created_by") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: events creators or admins update events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "creators or admins update events" ON "public"."events" FOR UPDATE TO "authenticated" USING ((("auth"."uid"() = "created_by") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: cuisine_preorders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."cuisine_preorders" ENABLE ROW LEVEL SECURITY;

--
-- Name: deleted_rows_archive; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."deleted_rows_archive" ENABLE ROW LEVEL SECURITY;

--
-- Name: donations_summary donations readable by admin or team; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "donations readable by admin or team" ON "public"."donations_summary" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: donations_summary; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."donations_summary" ENABLE ROW LEVEL SECURITY;

--
-- Name: duplicate_flags; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."duplicate_flags" ENABLE ROW LEVEL SECURITY;

--
-- Name: email_send_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."email_send_log" ENABLE ROW LEVEL SECURITY;

--
-- Name: email_send_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."email_send_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: email_unsubscribe_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."email_unsubscribe_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: entertainment_submissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."entertainment_submissions" ENABLE ROW LEVEL SECURITY;

--
-- Name: events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."events" ENABLE ROW LEVEL SECURITY;

--
-- Name: events events readable by all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "events readable by all" ON "public"."events" FOR SELECT USING (true);


--
-- Name: guest_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."guest_messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: invitations host creates invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "host creates invitations" ON "public"."invitations" FOR INSERT TO "authenticated" WITH CHECK (("auth"."uid"() = "host_id"));


--
-- Name: invitations host or admin deletes invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "host or admin deletes invitations" ON "public"."invitations" FOR DELETE TO "authenticated" USING ((("auth"."uid"() = "host_id") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: duplicate_flags host or admin reads flags; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "host or admin reads flags" ON "public"."duplicate_flags" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR (EXISTS ( SELECT 1
   FROM "public"."invitations" "i"
  WHERE ((("i"."id" = "duplicate_flags"."invitation_a") OR ("i"."id" = "duplicate_flags"."invitation_b")) AND ("i"."host_id" = "auth"."uid"()))))));


--
-- Name: invitations host or admin reads invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "host or admin reads invitations" ON "public"."invitations" FOR SELECT TO "authenticated" USING ((("auth"."uid"() = "host_id") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: orders host or admin reads orders; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "host or admin reads orders" ON "public"."orders" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR (EXISTS ( SELECT 1
   FROM "public"."invitations" "i"
  WHERE (("i"."id" = "orders"."invitation_id") AND ("i"."host_id" = "auth"."uid"()))))));


--
-- Name: rsvps host or admin reads rsvps; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "host or admin reads rsvps" ON "public"."rsvps" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR (EXISTS ( SELECT 1
   FROM "public"."invitations" "i"
  WHERE (("i"."id" = "rsvps"."invitation_id") AND ("i"."host_id" = "auth"."uid"()))))));


--
-- Name: invitations host or admin updates invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "host or admin updates invitations" ON "public"."invitations" FOR UPDATE TO "authenticated" USING ((("auth"."uid"() = "host_id") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: invitation_content; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."invitation_content" ENABLE ROW LEVEL SECURITY;

--
-- Name: invitation_content invitation_content readable by all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "invitation_content readable by all" ON "public"."invitation_content" FOR SELECT USING (true);


--
-- Name: invitations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."invitations" ENABLE ROW LEVEL SECURITY;

--
-- Name: inviters; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."inviters" ENABLE ROW LEVEL SECURITY;

--
-- Name: menu_items menu readable by all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "menu readable by all" ON "public"."menu_items" FOR SELECT USING (true);


--
-- Name: menu_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."menu_items" ENABLE ROW LEVEL SECURITY;

--
-- Name: orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."orders" ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles readable by self admin or team; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "profiles readable by self admin or team" ON "public"."profiles" FOR SELECT TO "authenticated" USING ((("auth"."uid"() = "id") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: restaurants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."restaurants" ENABLE ROW LEVEL SECURITY;

--
-- Name: restaurants restaurants readable by all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "restaurants readable by all" ON "public"."restaurants" FOR SELECT USING (true);


--
-- Name: rsvps; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."rsvps" ENABLE ROW LEVEL SECURITY;

--
-- Name: suppressed_emails; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."suppressed_emails" ENABLE ROW LEVEL SECURITY;

--
-- Name: rsvps team manages rsvps; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "team manages rsvps" ON "public"."rsvps" TO "authenticated" USING ("public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")) WITH CHECK ("public"."has_role"("auth"."uid"(), 'team'::"public"."app_role"));


--
-- Name: team_messages team posts chat; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "team posts chat" ON "public"."team_messages" FOR INSERT TO "authenticated" WITH CHECK ((("auth"."uid"() = "user_id") AND ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role"))));


--
-- Name: invitations team reads all invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "team reads all invitations" ON "public"."invitations" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: rsvps team reads all rsvps; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "team reads all rsvps" ON "public"."rsvps" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: team_messages team reads chat; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "team reads chat" ON "public"."team_messages" FOR SELECT TO "authenticated" USING (("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: invitations team reads committee invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "team reads committee invitations" ON "public"."invitations" FOR SELECT TO "authenticated" USING ((("is_committee" = true) AND ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role"))));


--
-- Name: team_invites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."team_invites" ENABLE ROW LEVEL SECURITY;

--
-- Name: team_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."team_messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles user roles readable by self or admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "user roles readable by self or admin" ON "public"."user_roles" FOR SELECT TO "authenticated" USING ((("auth"."uid"() = "user_id") OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role")));


--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE "public"."user_roles" ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_last_seen users manage own last seen; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users manage own last seen" ON "public"."chat_last_seen" TO "authenticated" USING (("user_id" = "auth"."uid"())) WITH CHECK (("user_id" = "auth"."uid"()));


--
-- Name: category_assignments users remove own assignment; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users remove own assignment" ON "public"."category_assignments" FOR DELETE TO "authenticated" USING ((("user_id" = "auth"."uid"()) OR "public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role")));


--
-- Name: category_assignments users self-assign volunteer; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users self-assign volunteer" ON "public"."category_assignments" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));


--
-- Name: profiles users update own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users update own profile" ON "public"."profiles" FOR UPDATE TO "authenticated" USING (("auth"."uid"() = "id"));


--
-- Name: category_messages volunteers admin or team post in category chat; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "volunteers admin or team post in category chat" ON "public"."category_messages" FOR INSERT TO "authenticated" WITH CHECK ((("user_id" = "auth"."uid"()) AND ("public"."has_role"("auth"."uid"(), 'admin'::"public"."app_role") OR "public"."has_role"("auth"."uid"(), 'team'::"public"."app_role") OR (EXISTS ( SELECT 1
   FROM "public"."category_assignments" "a"
  WHERE (("a"."category_id" = "category_messages"."category_id") AND ("a"."user_id" = "auth"."uid"())))))));


--
-- PostgreSQL database dump complete
--

\unrestrict G8lvMuo7bsbO7UxdPmokVzcrODJihajwyBusZMvFQIbbdmEtqJZ1UOyZ2H0eRdv

